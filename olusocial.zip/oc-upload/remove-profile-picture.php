<?php  require '../oc-includes/bootstrap.php';
 
 if( !verifyToken() ){
  die('{"error":"Token not valid."}');
 }

 require '../oc-includes/chat_functions.php';

$username=test_input(strtolower( $_POST['username']) );

if( empty($_POST['username'] ) ){
 die('{"error":"Missing parameters."}');
}

$dir=getUserDir($username);

$file=$dir.'/profile_picture_full.jpg';
$thumb=$dir.'/profile_picture_small.jpg';

if(!is_file( $file) && !is_file( $thumb ) ){

 die('{"status":"success","result":"Photo removed."}');

}
  if( file_exists( $file) ){
  unlink(   $file);
}

if( file_exists($thumb) ){
  unlink($thumb);
}

die('{"status":"success","result":"Photo removed."}');
