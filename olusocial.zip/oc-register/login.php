<?php if (!isset($_SESSION)) {
   session_start();
}
 header('Content-type:application/json;charset=utf-8');
 require('../oc-includes/bootstrap.php');

$settings__=getSettings();

$login_status=isset( $settings__["enable_login"])?$settings__["enable_login"]:'YES';

$captcha_status= isset( $settings__["enable_login_captcha"])?$settings__["enable_login_captcha"]:'NO';

$manual_activation=isset($settings__["enable_manual_activation"] )? $settings__["enable_manual_activation"]:'NO';


if( $login_status!='YES'){

 die('{"error":"Login temporarily unavailable. '.$login_status.'"}');

}
else if( empty( $_POST['username'] )
 ||empty( $_POST['password'] ) 
|| empty($_POST['version'])  ){

 die('{"error":"One or more fields are empty."}');

}

$captcha_check=true;

if( $captcha_status=='NO'){
  $captcha_check=false;

}


if ( $captcha_check && ( empty($_POST['captcha']) 
|| empty($_SESSION['login_captcha']) ) ){
$captcha=randomString( 5);
 
 $_SESSION['login_captcha']=$captcha;

 die('{"captcha":"' .strtoupper($captcha). '"}');

}
  $username=test_input( strtolower($_POST['username']) );

   $password=$_POST['password'];
   $capt=test_input($_POST['captcha']);
  $version=test_input( $_POST['version']);

  if( !validUsername( $username ,true) 
 && !filter_var( $username, FILTER_VALIDATE_EMAIL) ){

 die('{"error":"Invalid pin or password"}');

  }
else
if( strlen($password )<6 ){

 die('{"error":"Invalid pin or password."}');

 }

else if( $captcha_check && strtolower($capt)!=strtolower($_SESSION['login_captcha'])) {

$captcha=randomString(5); $_SESSION['login_captcha']=$captcha;

  die('{"captcha_retry":"' . strtoupper($captcha ). '"}' );

 }

require "../oc-includes/server.php";

 $status='1';
 $table=_TABLE_USERS_;

$stmt= $conn->prepare("SELECT username, email, fullname, phone , password, user_status FROM $table WHERE username=? OR email =? LIMIT 1");

if(!$stmt || !$stmt->bind_param('ss',$username, $username) || !$stmt->execute() ){

$conn->close();

die('{"error":"Login failed. Try again."}');

}

$res=$stmt->get_result();

 $stmt->close();
 $conn->close();

 if ( $res->num_rows <1 ) { 

 die('{"error":"Invalid pin or password. Err01"}');
}

 //fetch DB results

 $row=$res->fetch_assoc();
 $username_=$row["username"];
 $email=$row["email"];
 $fullname=$row["fullname"];
 $phone=$row["phone"];
 $pwrd=$row["password"];
 $user_status=$row["user_status"];

 if ( !password_verify( $password, $pwrd ) ) {
  die('{"error":"Invalid pin or password. Err02"}');
}
 else if( $user_status=='0' ){

if( $manual_activation=='YES'){

 die('{"require_mverification":"Your account is awaiting activation. Kindly be patient.","email":"'.$email.'"}');
  }else{

die('{"require_verification":"Check your email address inbox or spam for your activation code.","email":"'.$email.'"}');

 }
}
else if( $user_status=='-1'){

  die('{"error":"This account is not accessible at the moment."}');

}

 session_destroy();

$dir=getUserDir($username_);

//Create a hash and save on server in a file and client browser. Which is to be verified on each call to the server from client

$data=array();
$data["username"]=$username_;
$data["email"]=$email;
$data["fullname"]=$fullname;
$data["phone"]=$phone;
$data["version"]=$version;

$udir=getUserDir( $username_);
 
 if( makeUserDir( $username ) ){

$token=password_hash( $username.'-'.$password, PASSWORD_DEFAULT, ['cost' =>'7'] );

$secureFile= $udir . "/secure__.php";

 if( file_put_contents( $secureFile, "<?php die('Life is sweet!');?>". $token )===FALSE ){

   die('{"error":"Unable to generate token."}');

}

$currenttime=microtime(true)*10000; //In microseconds

//Get official group last message id

  $lastmtime="" . ( $currenttime-1 ); //Useful for first time logger

 $sync_contacts='';

if(!empty( $_POST['fresh_login'] ) ){
  //Fetch users contacts if exist when logged in on a new phone
$contactFile=$udir . "/contacts.txt";

 if( file_exists( $contactFile) ){ 
 if( $contacts=file_get_contents( $contactFile) ){

 $sync_contacts=trim( $contacts );

   }

}

 sendWelcomeMessage( $username );

}

$result=array();
$result["status"]="success";
$result["data"]=$data;
$result["contacts"]=$sync_contacts;
$result["token"]=$token;
$result["email"]=$email;
$result["official_lmtime"]=$lastmtime;
$result["login_time_micro"]=$currenttime;

die( json_encode( $result ) );
 }else{

die('{"error":"Could not log you in at the moment."}');

}

die('{"error":"An error occured."}');
