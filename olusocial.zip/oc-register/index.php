<?php if (!isset($_SESSION)) {
   session_start();
}

header('Content-type:application/json;charset=utf-8');

require('../oc-includes/bootstrap.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$settings__=getSettings();

$reg_status=isset($settings__["enable_registration"] )?$settings__["enable_registration"]:'YES';
$everify_status=isset( $settings__["enable_email_verification"])?$settings__["enable_email_verification"]:'NO';
$captcha_status=isset( $settings__["enable_registration_captcha"] )?$settings__["enable_registration_captcha"]:'NO';
$manual_activation=isset( $settings__["enable_manual_activation"] )?$settings__["enable_manual_activation"]:'NO';

$send_as=isset( $settings__["app_name"] )?strtolower( $settings__["app_name"]):"vf_oluchat";

if( $reg_status=='NO' ){
 die('{"error":"Registration temporarily unavailable."}');
}
else if(empty($_POST['username'] )||empty( $_POST['email'] ) ||empty($_POST['fullname'] )|| empty($_POST['phone'] ) ||empty($_POST['password'] ) ){
 die('{"error":"One or more fields are empty."}');
}

$captcha_check=true;
 
if( $captcha_status=='NO' ){
  $captcha_check=false;
 }

if ( $captcha_check && (empty($_POST['captcha'] ) || empty( $_SESSION['register_captcha']) ) ){
$captcha=randomString( 5);

 $_SESSION['register_captcha']=$captcha;  die('{"captcha":"'.strtoupper( $captcha).'"}');
}
   $username=test_input( strtolower($_POST['username']) );  

$email=test_input( strtolower($_POST['email']) );


$fullname=test_input( strtolower($_POST['fullname']) );  
 $phone=test_input($_POST['phone'] );
 $password=test_input($_POST['password']);
 $capt=$_POST['captcha'];

if( !validUsername( $username) ||strpos( $username, '_' ) !== false ){
 
  die('{"error":"Username should start with an alphabet. Alphanumerics supported only. Min: 4 characters."}');
  }
else if( is_forbidden( $username) ){
die('{"error":"Username is already taken."}');
}
else if( !filter_var($email, FILTER_VALIDATE_EMAIL) ) {
  die('{"error":"Enter a valid email address."}');
}
 else if( !validName( $fullname) ){
 die('{"error":"Enter a good name."}');
  }
else if( !preg_match("/^[0-9+() -]{4,50}$/i", $phone) ){
 die('{"error":"Enter a valid phone number."}');
  }
else if( strlen($password)<6|| strlen($password )>50 ){
 die('{"error":"Password too short or long. Min: 6, Max: 50"}');
 }
else if(!validPassword($password ) ){
  die('{"error":"Password can only contain alphanumerics ~@#%_+*?-"}');
}
else if( $captcha_check && strtolower( $capt )!=strtolower($_SESSION['register_captcha']) ) {
 $captcha=randomString(5); $_SESSION['register_captcha']=$captcha;
  die('{"captcha_retry":"' . strtoupper($captcha). '"}' );
}

$userstatus=0;

 if( $manual_activation=='YES'){
   $userstatus=0;
 } 
  else if( $everify_status!='YES' ){
 $userstatus=1; //Auto activate
}

require "../oc-includes/server.php";

$table=_TABLE_USERS_;

 $stmt=$conn->prepare("SELECT username, email FROM $table WHERE  ( username=? OR email=? ) LIMIT 1");

 if( !$stmt ||!$stmt->bind_param('ss', $username, $email) || !$stmt->execute() ){

 $conn->close();

 die('{"error":"Temporarily unavailable. Try again."}');

}

 $res=$stmt->get_result();
  $stmt->close();

if( $res->num_rows>0){

 $row = $res->fetch_assoc();

 if ( $username==$row['username'] ){

 $conn->close();

 die('{"error":"Username is already in use. Use another one."}');

   }
   else if( $email==$row['email'] ) {

 $conn->close();

 die('{"error":"Email address is already in use."}');

   }
 }

$reg_on=date('Y-m-d H:i:s');

$hashed_password = password_hash( $password, PASSWORD_DEFAULT );

$stmt=$conn->prepare("INSERT INTO $table(username, email, fullname, phone, password, user_status, added_on) VALUES (?,?,?,?,?,?, NOW() )");

if( !$stmt || !$stmt->bind_param('sssssi', $username, $email, $fullname,$phone, $hashed_password, $userstatus) ||!$stmt->execute() ){

    $conn->close();

 die('{"error":"Failed to register. Try again. Err01"}');

  }

 $stmt->close();
  session_destroy();

  $udir=getUserDir($username);

if(  !makeUserDir( $username) ){

  $stmt=$conn->prepare("DELETE FROM $table WHERE username=? LIMIT 1");

if( !$stmt ||!$stmt->bind_param('s',$username) ||!$stmt->execute() ){

logIt("register/index.php- Make user dir failed, delete user inserted data also  failed. User={$username}");
 
}


 if( $stmt) $stmt->close();
 $conn->close();

 die('{"error":"Failed to register. Try again. Err03"}');

}

 $lsfile=$udir . "/lastseen.txt";

 file_put_contents( $lsfile, time() );

if( $manual_activation=='YES'){

  $conn->close();

 die('{"require_mverification":"Your account is awaiting activation. Kindly be patient.","email":"'.$email.'"}');

}else if( $userstatus<1 ){
   //sleep(1);

 if( $token=createToken($conn, $email,( 60*24) ) ){
  sendEmailVerificationCode( $email, $token );

}
  $conn->close();

 die('{"require_verification":"Check your email address inbox or spam for your activation code.","email":"'.$email.'"}');

}
else{

 try{

$table=_TABLE_GROUPS_;

 $stmt=$conn->prepare("UPDATE $table SET total_members=total_members+1 WHERE group_pin='gp_pofficials' LIMIT 1");

 if( $stmt && $stmt->execute() ){
   $stmt->close();
 }

}catch(Exception $e){

  logIt( $e->getMessage());

}

  $conn->close();

  die('{"status":"success","result":"You may login now."}');
}
