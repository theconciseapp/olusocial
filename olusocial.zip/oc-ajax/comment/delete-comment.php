<?php header('Content-type:application/json;charset=utf-8');
 require('../../oc-includes/bootstrap.php');

 if( !verifyToken() ){
  die('{"error":"Invalid security token."}');
 }
else if( empty( $_POST['username'] ) 
||empty( $_POST['comment_id'] ) 
||empty($_POST['group_pin'] )
|| empty( $_POST['version'] ) 
){ 
 die('{"error":"Missing parameters."}');
 }

$author=test_input( strtolower($_POST['username']) );

//$post_id=test_input( $_POST['post_id'] );

$cid=test_input( $_POST['comment_id'] );

$gpin=test_input( strtolower( $_POST['group_pin'] ) );

$version=test_input($_POST['version']);

require('../../oc-includes/server.php');

require('comment-functions.php');
  
 if(delete_comment($conn, $gpin, $cid,  $author ) ){
 $conn->close();
 die('{"status":"success","result":"Succesful."}');
}

$conn->close();

die('{"error":"Please try again."}');
