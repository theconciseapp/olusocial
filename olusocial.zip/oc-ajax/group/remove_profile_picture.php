<?php require('../../oc-includes/bootstrap.php');

if( !verifyToken() ){
  die('{"error":"Token not valid."}');
 }

 require '../../oc-includes/chat_functions.php';

if( empty($_POST['group_pin'] ) ){
 die('{"error":"Missing parameters."}');
}

$gpin=test_input( strtolower($_POST['group_pin']) );

$dir=getGroupDir( $gpin);

$file=$dir.'/profile_picture_full.jpg';
$thumb=$dir.'/profile_picture_small.jpg';

if( !file_exists( $file) && !file_exists($thumb) ){
 die('{"status":"success","result":"Deleted successfully."}');
}
  if( file_exists($file ) )  unlink( $file);
 if( file_exists( $thumb) )  unlink($thumb);

die('{"status":"success","result":"Photo removed."}');
