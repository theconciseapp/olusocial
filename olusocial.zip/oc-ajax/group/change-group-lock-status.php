<?php
/**
* Class and Function List:
* Function list:
* Classes list:
*/
header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');

if (!verifyToken()) {
    die('{"error":"Invalid token."}');
}

if (empty($_POST['username']) || empty($_POST['group_pin']) || empty($_POST['version']) || empty($_POST['lock_status'])) {
    die('{"error":"Parameters missing."}');
}

$username    = test_input(strtolower($_POST['username']));

$gpin        = test_input(strtolower($_POST['group_pin']));

$lock        = test_input(strtolower($_POST['lock_status']));

$app_version = test_input($_POST['version']);

if ($username == $gpin) {
    die('{"error":"Sorry, not allowed."}');
}

$meta = array();

require "../../oc-includes/server.php";
require "group-functions.php";

$table = _TABLE_GROUPS_;

$stmt  = $conn->prepare("SELECT group_admins FROM $table WHERE group_pin=? LIMIT 1");

if (!$stmt || !$stmt->bind_param('s', $gpin) || !$stmt->execute()) {

    die('{"error":"Please try again."}');
}

$res = $stmt->get_result();
$stmt->close();

if ($res->num_rows < 1) {
    die('{"error":"Group pin not found."}');
}

$row    = $res->fetch_assoc();

$admins = $row['group_admins'];

if (!preg_match("/\b{$username}\b,/", $admins)) {
    die('{"error":"Permission denied."}');
}

$glockdir = getGroupDir($gpin);

if ($lock == 'lock') {

    if (!is_dir($glockdir)) {
        die('{"error":"Unable to alter."}');
    }
    if (file_put_contents($glockdir . "/lock.md", "locked")) {

        $message = "lock-group|$gpin";

        $meta["hl"]         = "";

        customGroupMessage($conn, $gpin, $message, $meta, "", "act");

        $message2 = "_Group's settings changed to allow only admins to send messages to this group._";

        $meta["hl"]          = str_replace('_', '', $message2);

        customGroupMessage($conn, $gpin, $message2, $meta, "", $username."~");

        $conn->close();
        die('{"status":"success","result":"1"}');
    }

    die('{"error":"Unable to alter."}');
}

else {
    if (!is_dir($glockdir)) {

        die('{"error":"Failed to change group status."}');

    }

    if (!file_exists($glockdir . '/lock.md') || unlink($glockdir . '/lock.md')) {

        $message = "unlock-group|$gpin";

        $meta["hl"]         = "";

        customGroupMessage($conn, $gpin, $message, $meta, "", "act");

        $message2 = "_Group's settings to allow all members to send messages to this group_";

        $meta["hl"]          = str_replace('_', '', $message2);

        customGroupMessage($conn, $gpin, $message2, $meta, "", $username."~");

        $conn->close();
        die('{"status":"success","result":"2"}');
    }

    die('{"error":"Could not change."}');
}
