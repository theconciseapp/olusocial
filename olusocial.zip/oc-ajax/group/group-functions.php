<?php
/**
* Class and Function List:
* Function list:
* - sendGroupMessage()
* - groupMessage()
* - fetch_group_message()
* - getGroupInfos()
* - groupLockStatus()
* - get_group_data()
* - add_group_admin()
* - remove_group_admin()
* - remove_group_member()
* - customGroupMessage()
* Classes list:
*/
function sendGroupMessage($conn, $msgdata, $chat_id, $chat_to, $chat_from) {

    $result    = array(
        "status"           => "",
        "group"           => $chat_to,
        "result"           => "",
        "invalid_groups"           => "",
        "lock_status"           => ""
    );

    $gdir      = getGroupDir($chat_to);

    $REZ       = "{$chat_id}|{$chat_to} ";

    $is_locked = false;

    if (!is_dir($gdir)) {

        //If group doesn't exist, remove from app
        //to prevent user from sending again.
        //Fake message sent
        // $result["invalid_groups"]=$chat_to;
        $result["result"]           = $REZ;
        return $result;
    }
    else if (file_exists($gdir . '/lock.md')) {
        //Only admin can send message
        $result["result"]           = $REZ;
        $result["lock_status"]           = $chat_to;
        $is_locked = true;
    }

    $table     = _TABLE_GROUPS_ . '_messages';

    $mtime     = (microtime(true) * 10000);

    if ($is_locked) {

        $result["result"]           = $REZ;
        return $result;
    }

    $stmt = $conn->prepare("INSERT INTO $table ( message_id, message_date,group_pin, message_by, message, date_time)  VALUES(?,?,?,?,?, NOW() )");

    if ($stmt && $stmt->bind_param('iisss', $chat_id, $mtime, $chat_to, $chat_from, $msgdata) && $stmt->execute()) {
        $stmt->close();
        $result["result"] = $REZ;

    }

    return $result;
}

function groupMessage($chat_to) {
    $result = array(
        "gmessage" => "",
        "last_gmsg_times" => array() ,
        "invalid_groups" => "",
        "members_typing" => "",
        "glock_status" => array()
    );

    if (empty($_POST['groups_pins'])) {
        return $result;
    }
    $gpins  = test_input($_POST['groups_pins']);

    $server = require_once "oc-includes/server.php";

    if ($server != "success") {
        return $result;
    }

    $gmessage       = $invalid_groups = $members_typing = $lock_status    = "";

    $gpins          = explode(" ", $gpins);

    $total_gpins    = count($gpins);

    $conditions     = "";
    $cnt            = 0;

    $glocks         = $invalid_groups = array();

    foreach ($gpins AS $gdata_) {
        $gdata          = explode("|", $gdata_);
        $gpin           = mysqli_real_escape_string($conn, trim($gdata[0]));

        $glasttime      = preg_replace('/[^0-9]/', '', $gdata[1]); //Group's last message time
        $gdir           = getGroupDir($gpin);

        /*
        Update group's lastseen...i.e last group message check by a member
        $lsfile="{$gdir}/lastseen.txt";
        file_put_content( $lsfile, time() );
        */

        /*
        if( !is_dir( $gdir ) ) {
        $invalid_groups[$gpin]="invalid";
        }
        else{
        */

        $cnt++;

        if ($cnt > 1) {
            $conditions .= " OR ";
        }

        $conditions .= "( message_date>$glasttime AND group_pin='$gpin' ) ";

        //}
        if (is_file($gdir . '/lock.md')) {
            //Group lock status-Only admin can send message
            $glock[$gpin]      = "locked";
        }
        else {
            $glock[$gpin]      = "unlocked";
        }

        // $members_typing.=friendTyping( $gdir ) . "\n";
        
    }

    $data = fetch_group_message($conn, $conditions, $chat_to);

    $gmessage .= $data["msg"] . "\n";
    $gmessage = trim($gmessage);

    if (!empty($gmessage)) {
        $gmessage = "\n" . $gmessage;
    }

    $result["gmessage"]          = $gmessage;
    $result["last_gmsg_times"]          = $data["ltimes"]; //groups last message times
    $result["invalid_groups"]          = $invalid_groups;
    $result["glock_status"]          = $glock;
    $result["members_typing"]          = trim($members_typing);

    return $result;

}

function fetch_group_message($conn, $conditions, $fetcher) {

    $iresult = array(
        "msg" => "",
        "ltimes" => array()
    );

    if (empty($conditions)) {
        return $iresult;
    }

    $table = _TABLE_GROUPS_ . '_messages';

    $sql   = "SELECT message, message_date ,group_pin FROM {$table} WHERE ( {$conditions} ) AND ( message_by!='$fetcher') ORDER BY id ASC LIMIT 50";

    try {
        $query = mysqli_query($conn, $sql);
    }
    catch(Exception $e) {

        logIt($e->getMessage());

        return $iresult;
    }

    if (mysqli_num_rows($query) < 1) {
        return $iresult;
    }

    $idata     = "";
    $ltimes    = array();

    while ($row       = mysqli_fetch_array($query)) {
        $idata .= $row["message"] . "\n";
        $group_pin = $row["group_pin"];
        $ltime     = $row["message_date"];
        $ltimes[$group_pin]           = $ltime; //each last group message time
        
    }

    $iresult["msg"]           = "\n" . trim($idata);
    $iresult["ltimes"]           = $ltimes;

    return $iresult;
}

function getGroupInfos($conn, $gpin, $username) {

    $app_version = test_input(strtolower($_POST['version']));

    $gdir        = getGroupDir($gpin);

    $file        = getGroupDir($username) . "/groups.txt";

    $table       = _TABLE_GROUPS_;

    $stmt        = $conn->prepare("SELECT*FROM $table WHERE group_pin=? LIMIT 1");

    if (!$stmt || !$stmt->bind_param('s', $gpin) || !$stmt->execute()) {

        $conn->close();

        return '{"error":"Failed. Try again."}';
    }

    $res = $stmt->get_result();

    if ($res->num_rows < 1) {
        $stmt->close();
        $conn->close();

        return '{"error":"Group not found."}';
    }

    $result    = array();
    $info      = array();
    $full_info = array();

    $stmt->close();
    $conn->close();

    $row      = $res->fetch_assoc();

    $cby      = strtolower($row["created_by"]);
    $gmembers = $row["group_members"];

    if (!empty($gmembers)) {
        $toarray  = explode(",", $gmembers);
        sort($toarray);
        $gmembers    = implode(" ", $toarray);
    }

    $info["fuser"]             = $gpin;
    $info["fullname"]             = $row["group_title"];
    $info["total_members"]             = $row["total_members"];
    $info["created_on"]             = $row["created_on"];
    $info["created_by"]             = $cby;
    $info["group_admins"]             = $row["group_admins"];

    $lock_status = "unlocked";
    if (is_file($gdir . '/lock.md')) {
        $lock_status = "locked";
    }
    $info["group_lock"]             = $lock_status;

    if ($cby == $username) {
        $info["owner"]             = $cby;
    }
    $info["app_version"]             = $app_version;
    $info["group_info"]             = "";
    $info["group_members"]             = "";

    $full_info   = $info;
    $full_info["group_info"]             = $row["group_info"];
    $full_info["group_members"]             = trim($gmembers);

    $fresult["status"]             = "success";
    $fresult["info"]             = $info;
    $fresult["full_info"]             = $full_info;
    return json_encode($fresult);
}

function groupLockStatus($gpin, $status) {
    //lock or unlock
    if ($status == "unlocked") {
        $lfile = getGroupDir($gpin) . "/lock.md";
        if (file_exists($lfile)) {
            unlink($lfile);
        }
    }
    else {
        file_put_contents($lfile, 'locked');
    }
}

function get_group_data($conn, $gpin, $username) {
    $table = _TABLE_GROUPS_;

    $stmt  = $conn->prepare("SELECT group_admins, group_members, created_by, group_title FROM $table WHERE group_pin=? LIMIT 1");

    if (!$stmt || !$stmt->bind_param('s', $gpin) || !$stmt->execute()) {
        return "-1";
    }

    $res = $stmt->get_result();
    $stmt->close();

    if ($res->num_rows < 1) {
        return "0";
    }

    $row    = $res->fetch_assoc();

    $admins = $row['group_admins'];

    if (!preg_match("/\b{$username}\b,/", $admins)) {

        return "00";
    }

    return $row;

}

function add_group_admin($conn, $gpin, $fuser, $username) {

    $table = _TABLE_GROUPS_;

    /*
    $fdir= getGroupDir($fuser);
    
    if( !is_dir( $fdir) ){
    return ('{"error":"Member not found."}');
    }
    */

    $row   = get_group_data( $conn, $gpin, $username);

    if ($row ==="-1") {
        return ('{"error":"Please try again."}');
    }
    else if ($row ==="0") {
        return ('{"error":"Group pin not found."}');
    }
    else if ($row ==="00") {
        return ('{"error":"Permission denied."}');

    }

    $gtitle       = $row['group_title'];
    $cby          = $row['created_by'];
    $gmembers     = $row["group_members"];
    $admins       = $row['group_admins'];

    $meta         = array();
    $check        = $fuser . ',';

    if (!empty($admins)) {
        $total_admins = count(explode(',', $admins));

        if ($total_admins > 4) {
            return ('{"error":"Maximum admins reached."}');
        }

    }

    if (preg_match("/\b{$fuser}\b,/", $admins)) {

        return ('{"status":"success","type":"added","result":"Successful."}');

    }

    $upd  = $admins . $fuser . ","; //e.g admin1,newadmin,
    $stmt = $conn->prepare("UPDATE $table SET group_admins=? WHERE group_pin=? LIMIT 1");

    if (!$stmt || !$stmt->bind_param('ss', $upd, $gpin) || !$stmt->execute()) {
        return ('{"error":"Failed to add"}');
    }

    $stmt->close();
    require_once ('../../oc-third-party/SleekDB/Store.php');

    $message = "add-as-group-admin|{$gpin}";

    $meta["hl"]         = "";

    inboxUser($fuser, $message, $meta, "act");

    return ('{"status":"success","type":"added","result":"Successful."}');

}

function remove_group_admin($conn, $gpin, $fuser, $username) {

    $table = _TABLE_GROUPS_;

    $row   = get_group_data($conn, $gpin, $username);

    if ($row == "-1") {
        return ('{"error":"Please try again."}');
    }
    else if ($row =="0") {
        return ('{"error":"Group pin not found."}');
    }
    else if ($row == "00") {
        return ('{"error":"Permission denied."}');

    }

    $gtitle   = $row['group_title'];
    $cby      = $row['created_by'];
    $gmembers = $row["group_members"];
    $admins   = $row['group_admins'];

    if ($fuser == $cby) {
        return ('{"error":"Sorry, you cannot remove group creator."}');
    }

    $rep  = preg_replace("/\b{$fuser}\b,/", "", $admins);

    $stmt = $conn->prepare("UPDATE $table SET group_admins =? WHERE group_pin=? LIMIT 1");

    if (!$stmt || !$stmt->bind_param('ss', $rep, $gpin) || !$stmt->execute()) {

        return ('{"error":"Failed to remove."}');
    }

    $stmt->close();

    require_once ('../../oc-third-party/SleekDB/Store.php');

    $message = "remove-from-group-admin|{$gpin}";

    $meta["hl"]         = "";

    inboxUser($fuser, $message, $meta, "act");

    return ('{"status":"success","type":"removed","result":"Successful."}');

}

function remove_group_member($conn, $gpin, $fuser, $username) {

    $table = _TABLE_GROUPS_;

    $row   = get_group_data($conn, $gpin, $username);

    if ($row ==="-1") {
        return ('{"error":"Please try again."}');

    }
    else if ($row ==="0") {
        return ('{"error":"Group pin not found."}');

    }
    else if ($row ==="00") {
        return ('{"error":"Permission denied."}');

    }

    $gtitle   = $row['group_title'];
    $cby      = $row['created_by'];
    $gmembers = $row["group_members"];
    $admins   = $row["group_admins"];

    if ($fuser == $cby) {

        return ('{"error":"Sorry, you cannot remove group creator."}');

    }

    $repl_admins  = preg_replace("/\b{$fuser}\b,/", "", $admins);

    $repl_members = preg_replace("/\b{$fuser}\b,/", "", $gmembers);

    $stmt         = $conn->prepare("UPDATE $table SET group_admins =?, group_members=?, total_members=total_members-1 WHERE group_pin=? LIMIT 1");

    if (!$stmt || !$stmt->bind_param('sss', $repl_admins, $repl_members, $gpin) || !$stmt->execute()) {

        return ('{"error":"Please try again."}');

    }
    require_once ('../../oc-third-party/SleekDB/Store.php');

    $message = "remove-from-group|{$gpin}";

    $meta["hl"]         = "";

    inboxUser($fuser, $message, $meta, "act");

    return ('{"status":"success","type":"removedm","result":"Successful."}');

}

function customGroupMessage($conn, $gpin, $message, $meta           = "", $can_comment    = "", $msg_from       = "vf_admin") {

    $table_messages = _TABLE_GROUPS_ . '_messages';

    $time           = time();
    $mtime          = microtime(true) * 10000;
    $cid            = randomNumbers(15);

    $mdata          = array();

    $mdata["cid"]                = $cid;
    $mdata["cf"]                = $msg_from;
    $mdata["ct"]                = $gpin;
    $mdata["msg"]                = $message;
    $mdata["can_comment"]                = $can_comment;

    if (!empty($meta)) {
        $mdata          = array_merge($mdata, $meta);
    }

    $mdata["time"]                = $time;
    $mdata["ver"]                = "0";
    $mdata["sver"]                = _SITE_VERSION_;
    $mdata["is_admin"]                = "1";

    $messageData    = json_encode($mdata);

    try {

        $stmt           = $conn->prepare("INSERT INTO {$table_messages}( message_date, message_id, group_pin, message_by,message,date_time) VALUES (?,?,?,?,?, NOW() )");

        if ($stmt && $stmt->bind_param('iisss', $mtime, $cid, $gpin, $msg_from, $messageData) && $stmt->execute()) {
            //Do not close connection here
            //Connection should be closed by script
            //that called this function
            return 1;
        }

    }
    catch(Exception $e) {
        logIt($e->getMessage());
        return 0;
    }

    return 0;
}
