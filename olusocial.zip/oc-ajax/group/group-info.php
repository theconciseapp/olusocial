<?php
/**
* Class and Function List:
* Function list:
* Classes list:
*/
header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');

if (!verifyToken()) {
    die('{"error":"Invalid security token."}');
}
else if (empty($_POST['username']) || empty($_POST['group_pin']) || empty($_POST['version'])) {
    die('{"error":"Missing parameters."}');
}

$username = test_input(strtolower($_POST['username']));
$gpin     = test_input(strtolower($_POST['group_pin']));

require ('../../oc-includes/server.php');

require ('group-functions.php');

//massMessageTest("Yes and yesit isgood for","monday");

die(getGroupInfos($conn, $gpin, $username));
