<?php header('Content-type:application/json;charset=utf-8');
require('../../oc-includes/bootstrap.php');

if( !verifyToken() ){
  die('{"error":"Invalid token."}');
 }

 if( empty($_POST['username'] ) ||empty($_POST['group_pin']) || empty($_POST['version']) ){ 
   die('{"error":"Parameters missing."}');
 }

$settings__=getSettings();

$enable_joingroup=isset( $settings__["enable_join_group"] )?$settings__["enable_join_group"]:'YES';

if( $enable_joingroup!='YES' ){
  die('{"error":"Joining group is currently not allowed."}');
}

$users_pgroup=isset( $settings__["users_per_group"] )?(int)$settings__["users_per_group"]:100;

$username=test_input( strtolower($_POST['username']) );
$gpin=test_input( strtolower($_POST['group_pin'] ) );

$app_version=test_input( strtolower($_POST['version'] ) );

 if( $username==$gpin){
  die('{"error":"Sorry, not allowed."}');
 }
  else if( !validUsername( $gpin ) ){
 die('{"error":"Sorry, not allowed."}');
}

$gdir=getGroupDir($gpin);

require "../../oc-includes/server.php";
require "group-functions.php";

 $table=_TABLE_GROUPS_;
 $gpin="gp_".$gpin;

$stmt=$conn->prepare("SELECT*FROM $table WHERE group_pin=? LIMIT 1");

 $stmt->bind_param('s', $gpin);
 $stmt->execute();
 $res=$stmt->get_result();

   $stmt->close();
   
if ( $res->num_rows<1 ) {
 $conn->close();
   die('{"error":"Pin not found."}');
 }

$row=$res->fetch_assoc();

$total_members=(int)$row['total_members']+1;
$members=$row['group_members'];

if( is_group( $gpin) && $total_members >$users_pgroup){
  $conn->close();
 die('{"error":"This group is full."}');
 }

$is_member="false";

 if( preg_match("/\b{$username}\b,/", $members) ){
$is_member="true";
 }

$table_messages=$table.'_messages';
 
 $lastmtime="". ( ( microtime(true) * 10000)-1);

$data=array();

$title=$row["group_title"];
$info=$row['group_info'];
$cby=$row["created_by"];
$con=$row["created_on"];
$time_=time();

$data["fuser"]=$gpin; //group_pin
 $data["fullname"]=$title; //group title
$data["group_info"]=$info;
$data["last_message_time"]=$lastmtime;
$data["created_by"]=$cby;
$data["created_on"]=$con;
$data["app_version"]=$app_version;
$data["joined"]= $time_;
$data["group_admins"]=$row["group_admins"];
$data["total_members"]=($total_members-1);
$data["group_members"]="";
$mem=$username.",";

$meta=array();

if( $is_member=='true') {
   $query=true;
}
else{

if( is_group( $gpin)  ){

$query=mysqli_query($conn, "UPDATE $table SET total_members=total_members+1, group_members=CONCAT( group_members, '$mem' ) WHERE group_pin='$gpin' LIMIT 1");

}
 else{
$query=mysqli_query( $conn, "UPDATE $table SET total_members=total_members+1 WHERE group_pin='$gpin' LIMIT 1");

 }

}

  if( $query){

if( is_group($gpin) ){

$msg='_'. ucfirst(str_replace('vf_','', $username) ) . ' joined_';

$meta["hl"]=str_replace('_','', $msg);

customGroupMessage($conn, $gpin, $msg, $meta);

}else{

$message="_You followed page:_ *".ucfirst( $title) ."*.:nl::*About page*:nl::" .$info;

$meta["hl"]=str_replace('_','', $message);

require_once('../../oc-third-party/SleekDB/Store.php');

 inboxUser( $username, $message, $meta, "vf_private");


 }
   $data["status"]="success";
  die( json_encode( $data) );
 }

 die('{"error":"Failed to join group."}');
