<?php
/**
* Class and Function List:
* Function list:
* Classes list:
*/
header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');

if (!verifyToken()) {
    die('{"error":"Invalid token."}');
}

if (empty($_POST['username']) || empty($_POST['group_pin']) || empty($_POST['version']) || empty($_POST['member_user']) || empty($_POST['type'])) {
    die('{"error":"Parameters missing."}');
}

$username    = test_input(strtolower($_POST['username']));
$gpin        = test_input(strtolower($_POST['group_pin']));
$fuser       = test_input(strtolower($_POST['member_user']));
$type        = test_input(strtolower($_POST['type']));

$app_version = test_input(strtolower($_POST['version']));

if ($username == $gpin) {
    die('{"error":"Sorry, not allowed."}');
}
else if (!validUsername($gpin, true)) {
    die('{"error":"Sorry, not allowed."}');
}

$pin = "gp_" . $gpin;

require "../../oc-includes/server.php";
require "group-functions.php";

if ($type == "add-admin") {

    $result = add_group_admin($conn, $gpin, $fuser, $username);

    $conn->close();
    die($result);

}
else if ($type == "remove-admin") {

    $result = remove_group_admin($conn, $gpin, $fuser, $username);
    $conn->close();
    die($result);

}
else if ($type == "remove-member") {

    $result = remove_group_member($conn, $gpin, $fuser, $username);

    $conn->close();

    die($result);
}

$conn->close();
die('{"error":"Not successful."}');
