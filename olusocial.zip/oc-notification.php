<?php header('Content-type:application/json;charset=utf-8');

 if( empty($_GET['username']) ){
  die(json_encode(json_decode ("{}")) );
//return null
}

 require('oc-includes/bootstrap.php');
 
if( !verifyToken() ){
  die(json_encode(json_decode ("{}")) );
}

$username=test_input( strtolower( $_GET['username'] ) );

$udir=getUserDir($username);

if( !is_dir( $udir) ){
   die(json_encode(json_decode ("{}")) );
 }


$settings__=getSettings();

$app_name=isset( $settings__["app_name"])? $settings__["app_name"]:"OluSocial";

$app_name=ucfirst( str_replace('vf_','',$app_name) );


 $message="";

//CHECK FOR MESSAGE FROM ONE OF GROUPS THE USER BELONGS TO


if( !empty($_GET['groups'] ) && strlen( trim( $_GET['groups']) )>7 ){

try{

$groups=test_input( $_GET['groups']);
$groups=explode(' ', $groups);

if( count($groups )>0){
  $key = array_rand($groups);
$group = $groups[$key];
 
$group=explode('|', $group);
$gpin=$group[0];
$gtime=$group[1];

require('oc-includes/server.php');
$table=_TABLE_GROUPS_.'_messages';

$stmt=$conn->prepare("SELECT COUNT(1) FROM {$table} WHERE group_pin=? AND message_date>? ORDER BY id ASC LIMIT 1");

if( $stmt && $stmt->bind_param('si', $gpin, $gtime) && $stmt->execute() ){

 $res=$stmt->get_result();

 $stmt->close();
$total_messages= $res->fetch_row()[0];

 if( $total_messages > 0){
   
 $message="You have {$total_messages} message(s)";

  }
    }

$conn->close();

  }

}catch(Exception $e){
 logIt($e->getMessage() );
 $conn->close();
  }
}

require_once('oc-third-party/SleekDB/Store.php');

$flat_table="messages";

$msgStore = new \SleekDB\Store($flat_table, $udir , ["timeout"=>false] );

  $datas=$msgStore->findAll(null,1);

if( $datas) {
   $message="You have a new message. Click to view.";
}


if( empty( $message) ){
 die(json_encode(json_decode ("{}")) );
}

$last_modified=filectime( $udir );

$data =["title"=>"Click to read", "text"=>$message,"time"=>"$last_modified"]; 

die(json_encode( $data ) );
