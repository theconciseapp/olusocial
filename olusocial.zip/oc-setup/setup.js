function buttonSpinner(node,done){
  node.find('.button-spinner').remove();
if(done ) return;
node.append(' <span class="button-spinner"><span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>'
+ '<span class="visually-hidden">...</span></span>');
}

$(function(){
 $('body').on('click','.setup-now-btn',function(){
var this_=$(this);
var serror=$('#error-report');
var input=$('input,button');

serror.empty();
 var dbhost=$.trim($('#database-host').val());
 var dbname=$.trim( $('#database-name').val());
 var dbuname=$.trim( $('#database-username').val() );
 var dbpass=$.trim( $('#database-password').val() );
  var tp=$.trim( $('#table-prefix').val() );

if( !dbhost||!dbname||!dbuname||!tp){
 serror.html('<span class="text-danger">One or more important fields* are empty.</span>');
 return false;
 }

else if(!tp.match(/^[a-z]+[a-zA-Z0-9_-]{0,19}$/i) ){
 serror.html('<span class="text-danger">Table prefix should start with an alphabet. a-z, 0-9, _ and dash(-) supported. Max: 20 chars</span>');
return;
}


input.prop('disabled' , true);
buttonSpinner( this_);

 $.ajax({
  url: 'ajax/setup.php',
  type: 'POST',
  dataType:'json',
  data: {
  'database_host': dbhost,
  'database_name': dbname,
  'database_username': dbuname,
  'database_password':dbpass,
  'table_prefix': tp,
  }
}).done(function(result){
input.prop('disabled' , false);
buttonSpinner( this_,true);

if(result.error){
 return toast(result.error);
}
else if(result.result){
displayData( result.result );
}

 /*
 if( result.match(/__SUCCESS__/) ){
  serror.html('<span class="text-success">Successful! Please Wait.</span>');
setTimeout(function(){
 location.href=_ADMIN_URL_ + '/login.php?fresh=1';
},3000);

  }
*/



}).fail(function(e){
input.prop('disabled' , false);
buttonSpinner( this_,true);

 serror.html('<span class="text-danger">An error occured. Check your network connection.</span>' + JSON.stringify(e) );
});

 });
});






