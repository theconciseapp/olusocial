<?php if(!defined('setup')){
die('Setup not found.');
}

$time=time();
$date_=date('Y-m-d H:i:s');

$table_users="{$table_prefix}users";
$table_admins="{$table_prefix}admins";
$table_groups="{$table_prefix}groups";
$table_gmessages="{$table_groups}_messages";
$table_comments="{$table_prefix}comments";

$table_official="{$table_groups}_gp_official";

$table_pr="{$table_prefix}tokens";

 /*CREATE TABLE ADMINS*/

 $sql_admins="CREATE TABLE IF NOT EXISTS {$table_admins}(
  `id` int(11) NOT NULL AUTO_INCREMENT, `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL, `fullname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL, `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL, `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, `role` smallint(6) NOT NULL DEFAULT '3', `added_on` datetime NOT NULL, PRIMARY KEY (`id`), UNIQUE KEY `email` (`email`,`username`) ) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

/*INSERT INTO TABLE ADMINS*/

$sql_admins2="INSERT INTO $table_admins (`id`, `username`, `email`, `fullname`, `phone`, `password`, `role`, `added_on`) VALUES
(1,	'vf_superadmin',	'superadmin@site.com',	'Super Admin',	'123456789',	'$2y$10$3QMFOm46obSII42yIUBd1en5.uDZzEAOaN/XZlB3b60z0EfJeIAUK',	1,	'$date_')";

/*TABLE TOKENS*/

$sql_pr="CREATE TABLE IF NOT EXISTS {$table_pr} (
  `id` int(11) NOT NULL AUTO_INCREMENT, `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL, `token` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL, `expiry_time` int(11) NOT NULL, PRIMARY KEY (`id`), KEY `token_email_expiry_time` (`token`,`email`,`expiry_time`) ) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

/*CREATE TABLE USERS*/

$sql_users="CREATE TABLE IF NOT EXISTS {$table_users} (
  `id` int(11) NOT NULL AUTO_INCREMENT, `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL, `fullname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL, `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,`gender` varchar(10) COLLATE utf8mb4_unicode_ci NULL, `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, `role` smallint(6) NOT NULL DEFAULT '3', `user_status` smallint(6) NOT NULL DEFAULT '0', `last_online` int(11) NOT NULL, `added_on` datetime NOT NULL, PRIMARY KEY (`id`), UNIQUE KEY `email` (`email`,`username`) ) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

/*INSERT INTO TABLE USERS*/

$sql_users2="INSERT INTO {$table_users} (`id`, `username`, `email`, `fullname`, `phone`, `password`, `role`, `user_status`, `last_online`, `added_on`) VALUES
(1,	'vf_superadmin',	'Admin@noreply.com',	'Super Admin',	'+234123456789',	'$2y$10$3QMFOm46obSII42yIUBd1en5.uDZzEAOaN/XZlB3b60z0EfJeIAUK',	3,	1,	'$time',	NOW() )";


/* CREATE GROUPS TABLE */

$sql_groups="CREATE TABLE IF NOT EXISTS {$table_groups} (
  `id` int(11) NOT NULL AUTO_INCREMENT, `group_type` tinyint(4) NOT NULL DEFAULT '1', `group_pin` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `group_title` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL, `group_info` varchar(600) COLLATE utf8mb4_unicode_ci NOT NULL, `group_admins` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, `group_members` text COLLATE utf8mb4_unicode_ci NOT NULL, `total_members` smallint(5) unsigned NOT NULL DEFAULT '1', `created_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `created_on` int(11) NOT NULL, PRIMARY KEY (`id`), UNIQUE KEY `group_pin` (`group_pin`), KEY `group_title_group_type` (`group_title`,`group_type`) ) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

/*INSERT INTO GROUP*/

$sql_groups2="INSERT INTO {$table_groups} (`id`, `group_type`,`group_pin`, `group_title`, `group_info`,`group_admins`, `group_members`, `total_members`, `created_by`, `created_on`) VALUES
(1,	2, 'gp_pofficials',	'Official',	'Official','vf_superadmin,',	'vf_superadmin,',	1,	'vf_superadmin',	'$time')";


/*TABLE GROUP MESSAGES*/

$sql_gmessages="CREATE TABLE IF NOT EXISTS {$table_gmessages} (
`id` bigint(20) NOT NULL AUTO_INCREMENT, `message_date` bigint(20) NOT NULL, `message_id` bigint(20) NOT NULL, `group_pin` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL, `message_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `message` text COLLATE utf8mb4_unicode_ci NOT NULL, `date_time` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP, PRIMARY KEY (`id`), KEY `message_date_group_pin_message_by` (`message_date`,`group_pin`,`message_by`) ) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";


$sql_comments="CREATE TABLE IF NOT EXISTS {$table_comments} (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) NOT NULL DEFAULT '0',
  `group_pin` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
`likes` smallint(6) NOT NULL DEFAULT '0',
  `status` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `date_time` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `group_pin_post_id_status` (`group_pin`,`post_id`,`status`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";


 try{
 if ( $query=mysqli_query( $conn, $sql_admins ) ){
  $success.='<div><i class=\"fa fa-lg fa-check\"></i> Table '.$table_admins.' was created successfully.</div>';
}
 
 }catch(mysqli_sql_exception $e) { 
   $error.='<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage().'</div>';
} 

try{
 if ( $query=mysqli_query( $conn, $sql_groups ) ){
  $success.='<div><i class=\"fa fa-lg fa-check\"></i> Table '.$table_groups.' was created successfully.</div>';
}
 
 }catch(mysqli_sql_exception $e) { 
   $error.='<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage().'</div>';
}

try{
 if ( $query=mysqli_query( $conn, $sql_gmessages ) ){
  $success.='<div><i class=\"fa fa-lg fa-check\"></i> Table '.$table_gmessages.' was created successfully.</div>';
}
 
 }catch(mysqli_sql_exception $e) { 
   $error.='<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage().'</div>';
} 

try{
 if ( $query=mysqli_query( $conn, $sql_comments ) ){
  $success.='<div><i class=\"fa fa-lg fa-check\"></i> Table '.$table_comments.' was created successfully.</div>';
}
 
 }catch(mysqli_sql_exception $e) { 
   $error.='<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage().'</div>';
}



try{
 if( mysqli_query($conn, $sql_users) ){
 $success.='<div><i class=\"fa fa-lg fa-check\"></i> Table '. $table_users.' was created successfully.</div>';
 }

}catch(mysqli_sql_exception $e) { 
  $error.='<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage().'</div>';
} 

try{
 if( mysqli_query($conn, $sql_pr) ){
   $success.='<div><i class=\"fa fa-lg fa-check\"></i> Table '.$table_pr.' was created successfully.</div>';
 }
}catch(mysqli_sql_exception $e) { 
  $error.='<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage().'</div>';
} 

try{
 if( $query=mysqli_query($conn, $sql_admins2) ){

  $success.='<div><i class=\"fa fa-lg fa-check\"></i> Data inserts in ' . $table_admins.' was created successfully.</div>';
}

}catch(mysqli_sql_exception $e) { 
   $error.='<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage().'</div>';
} 

try{
 if( mysqli_query($conn, $sql_groups2) ){
  $success.='<div><i class=\"fa fa-lg fa-check\"></i> Data inserts in '.$table_groups.' was created successfully.</div>';
 }
}catch(mysqli_sql_exception $e) { 
 $error.='<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage().'</div>';
}

try{
 if( mysqli_query($conn, $sql_users2) ){
  $success.='<div><i class=\"fa fa-lg fa-check\"></i> Data inserts in '.$table_users.' was created successfully.</div>';
 }
}catch(mysqli_sql_exception $e) { 
 $error.='<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage().'</div>';
}
