<?php
/**
* Class and Function List:
* Function list:
* Classes list:
*/
$die_ = true;
if (defined('_NO_CONNECT_ERROR_EXIT_')) $die_ = false;

if (!defined('_DEFINED_')) {
    logIt('Danger: Server.php called directly.');
    if ($die_) die('{"error":"Error occured."}');
    else return "Error occured.";

}

if (!is_file(_CHAT_DIR_ . '/oc-includes/config.php') && !is_file(_ROOT_DIR_ . '/oc-local-config.php')) {

    if ($die_) {

        die('{"error":"<h3>Site requires setup! <a href=\'' . _SITE_URL_ . '/oc-setup/index.php\'>Setup now>></a></h3>"}');
    }
    else {
        return "Required setup.";
    }
}

if ( file_exists(_ROOT_DIR_ . '/oc-local-config.php')) {

    require (_ROOT_DIR_ . '/oc-local-config.php');
}
else {
    require (_CHAT_DIR_ . '/oc-includes/config.php');
}

try {

    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

    $conn = new mysqli($CONFIG___->host, $CONFIG___->username, $CONFIG___->password, $CONFIG___->database);
    $conn->set_charset('utf8mb4');
    return "success";

}
catch(mysqli_sql_exception $e) {

    if ($die_) {

        $user = isset($_REQUEST['username']) ? ' Queried by: ' . htmlspecialchars($_REQUEST['username']) : "";

        logIt('Connect failed: ' . $e->getMessage() . $user);
        die('{"error":"Connect failed."}');
    }
    else {
        return "Connect failed.";
    }
}
