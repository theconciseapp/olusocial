<?php
/**
* Class and Function List:
* Function list:
* - liveSite()
* - localHost()
* - TCA()
* - DIE__()
* - randomString()
* - randomGroupPin()
* - randomAlpha()
* - randomNumber()
* - randomNumbers()
* - escapeJsonString()
* - startsWith()
* - validAjaxRequest()
* - validChatId()
* - getSettings()
* - appUpgradeData()
* - verifyToken()
* - adminLoggedIn()
* - makeUserDir()
* - getUserDir()
* - makeGroupDir()
* - getGroupDir()
* - userUrl()
* - groupUrl()
* - getAdminInfo()
* - adminCanActivateUser()
* - adminCanMessageUser()
* - adminCanAddUser()
* - adminCanDeleteUser()
* - adminCanBlockUser()
* - adminCanChangeSettings()
* - adminCanManageSpace()
* - logIt()
* - deleteTree()
* - deleteAll()
* - make_dir()
* - table_exist()
* - usernameCheck()
* - emailCheck()
* - is_forbidden()
* - is_profane()
* - validUsername()
* - validPassword()
* - validName()
* - test_input()
* - user_photo_icon()
* - inboxUser()
* - sendWelcomeMessage()
* - members_can_interact()
* - is_page()
* - is_group()
* - allowedImages()
* - allowedVideos()
* - allowedAudios()
* - bannedDocuments()
* - allowedDocuments()
* - createConfigFile()
* - Emailer()
* - createToken()
* - sendEmailVerificationCode()
* - sendPasswordResetCode()
* - paginate()
* - pagination()
* - formatBytes()
* - checkPerms()
* Classes list:
*/
if (!defined('_DEFINED_')) {
    die('BLOCKED');
}

function liveSite() {
    if (preg_match("/localhost/i", $_SERVER['HTTP_HOST'])) return false;
    else return true;

}

function localHost() {
    if (preg_match("/localhost/i", $_SERVER['HTTP_HOST'])) return true;
    else return false;
}

function TCA() {
    if (preg_match("/TCA/i", $_SERVER['HTTP_HOST'])) return true;
    else return false;
}

function DIE__($text = '') {
    global $conn;

    if (isset($conn) && mysqli_ping($conn)) {
        mysqli_close($conn);
    }
    die($text);
}

function randomString($num = 10) {
    $s   = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz", $num)) , 0, $num);
    return 'a' . $s;
}

function randomGroupPin($num   = 10, $begin = "u") {
    $s     = substr(str_shuffle(str_repeat("0123456789abdefghijklmnopqrstuvwxyz", $num)) , 0, $num);
    return $begin . $s;
}

function randomAlpha($num = 10) {
    $s   = substr(str_shuffle(str_repeat("abcdefghjklmnpqrstuvwxyz", $num)) , 0, $num);
    return $s;
}

function randomNumber($limit = 1) {
    $code  = '';
    for ($i     = 0;$i < $limit;$i++) {
        $code .= mt_rand(0, 9);
    }
    return $code;
}

function randomNumbers($lim  = 1) {
    $code = '';
    for ($i    = 0;$i < $lim;$i++) {
        $code .= mt_rand(0, 9);
    }
    return $code;
}

function escapeJsonString($value) {
    # list from www.json.org: (\b backspace, \f formfeed)
    $escapers     = array(
        "\\",
        "/",
        "\"",
        "\n",
        "\r",
        "\t",
        "\x08",
        "\x0c"
    );
    $replacements = array(
        "\\\\",
        "\\/",
        "\\\"",
        "\\n",
        "\\r",
        "\\t",
        "\\f",
        "\\b"
    );
    $result       = str_replace($escapers, $replacements, $value);
    return $result;
}

function startsWith($str, $query) {
    return substr($str, 0, strlen($query)) === $query;
}

function validAjaxRequest($token_name = 'stoken') {
    if (empty($_SESSION[$token_name]) || empty($_POST['csrf']) || $_SESSION[$token_name] != $_POST['csrf']) return false;
    else return true;
}

function validChatId($id) {
    if (!empty($id) && preg_match("/^[0-9]{15,30}$/", $id)) return true;
}

function getSettings() {
    $file = _ADMIN_DIR_ . '/settings-files/settings.txt';

    if (file_exists(_ROOT_DIR_ . '/oc-local-settings.txt')) {
        $file = _ROOT_DIR_ . '/oc-local-settings.txt';
    }
    else if (!file_exists($file)) {
        return array();
    }
    $data = file_get_contents($file);
    return json_decode($data, true);
}

function appUpgradeData() {
    $file = _ADMIN_DIR_ . '/settings-files/app-upgrade-data.txt';
    if (!file_exists($file)) {
        return array();
    }
    $data = file_get_contents($file);
    return json_decode($data, true);
}

function verifyToken() {
    if (defined('__NO_TOKEN__')) return true;

    if (empty($_REQUEST['token']) || empty($_REQUEST['username'])) return false;

    $username    = $_REQUEST['username'];
    $user_token  = $_REQUEST['token'];

    $secure_file = getUserDir($username) . "/secure__.php";

    if (!file_exists($secure_file)) return false;

    $token = file_get_contents($secure_file);
    if ($token && substr($token, 30) == $user_token) return true;
    else return false;
}

function adminLoggedIn($set  = false, $d    = false, $json = false) {
    if ($set) {
        $_SESSION['ADMIN___LOGGED_IN']      = true;
        return true;
    }
    else if (!isset($_SESSION['ADMIN___LOGGED_IN'])) {
        if (!$d) {
            header("location:login.php");
            exit;
        }
        else {
            if ($json) die('{"error":"Login required."}');
            else die('Login required.');

        }
    }
}

function makeUserDir($u, $perm = "755") {
    $dir  = _CHAT_USER_DIR_ . "/" . $u[0] . "/" . $u[1] . "/" . $u[2] . "/" . $u;
    return make_dir($dir, $perm);
}

function getUserDir($u) {

    return _CHAT_USER_DIR_ . "/" . $u[0] . "/" . $u[1] . "/" . $u[2] . "/" . $u;

}

function makeGroupDir($g, $perm = "755") {
    $dir  = _CHAT_USER_DIR_ . "/" . $g[0] . "/" . $g[1] . "/" . $g[2] . "/" . $g;
    return make_dir($dir, $perm);
}

function getGroupDir($g) {
    return _CHAT_USER_DIR_ . "/" . $g[0] . "/" . $g[1] . "/" . $g[2] . "/" . $g;

}

function userUrl($u) {
    return _SITE_URL_ . "/oc-users/" . $u[0] . "/" . $u[1] . "/" . $u[2] . "/" . $u;

}

function groupUrl($g) {
    return _SITE_URL_ . "/oc-users/" . $g[0] . "/" . $g[1] . "/" . $g[2] . "/" . $g;
}

function getAdminInfo($info) {
    if (empty($info)) return "";
    $arr = array(
        "username" => "ADMIN___USERNAME",
        "fullname" => "ADMIN__FULLNAME",
        "email" => "ADMIN___EMAIL",
        "phone" => "ADMIN___PHONE",
        "role" => "ADMIN___ROLE"
    );

    if (empty($arr[$info])) return "";
    return $_SESSION[$arr[$info]];
}


function adminCanAddAdmin() {
    $admin_role = getAdminInfo('role');
    if ($admin_role =="1") {
        return true;
    }
    else {
        return false;
    }
}

function adminCanActivateUser() {
    $admin_role = getAdminInfo('role');
    if ($admin_role > 0 && $admin_role < 3) {
        return true;
    }
    else {
        return false;
    }
}

function adminCanMessageUser() {
    $admin_role = getAdminInfo('role');
    if ($admin_role > 0 && $admin_role < 5) {
        return true;
    }
    else {
        return false;
    }
}

function adminCanAddUser() {
    $admin_role = getAdminInfo('role');
    if ($admin_role > 0 && $admin_role < 3) {
        return true;
    }
    else {
        return false;
    }
}

function adminCanDeleteUser() {
    $admin_role = getAdminInfo('role');
    if ($admin_role > 0 && $admin_role < 3) {
        return true;
    }
    else {
        return false;
    }
}

function adminCanBlockUser() {
    $admin_role = getAdminInfo('role');
    if ($admin_role > 0 && $admin_role < 3) {
        return true;
    }
    else {
        return false;
    }
}

function adminCanChangeSettings() {
    $admin_role = getAdminInfo('role');
    if ($admin_role > 0 && $admin_role < 3) {
        return true;
    }
    else {
        return false;
    }
}

function adminCanManageSpace() {
    $admin_role = getAdminInfo('role');
    if ($admin_role > 0 && $admin_role < 4) {
        return true;
    }
    else {
        return false;
    }
}

function logIt($error) {
    $url  = _ERROR_DIR_ . '/log.php';
    $path = htmlspecialchars($_SERVER['SCRIPT_FILENAME']);

    file_put_contents($url, date('F jS, Y H:i:s') . "- {$error} in " . $path . "\n<!break>", FILE_APPEND | LOCK_EX);

}

function deleteTree($dir) {
    if (is_dir($dir)) {
        @chmod($dir, 0755);
        $objects = scandir($dir);

        foreach ($objects as $object) {
            if ($object != "." && $object != "..") {
                if (is_dir($dir . "/" . $object) && !is_link($dir . "/" . $object)) deleteTree($dir . "/" . $object);
                else unlink($dir . "/" . $object);
            }
        }
        rmdir($dir);
    }
    return true;
}

// delete all files and sub-folders from a folder
function deleteAll($dir) {
    foreach (glob($dir . '/*') as $file) {

        if (is_dir($file)) {
            deleteAll($file);
        }
        else {
            unlink($file);
        }
        usleep(1000);
    }
    return rmdir($dir);
}

function make_dir($path, $permissions = 0755) {
    if (is_dir($path)) {
        return true;
    }
    else {
        return mkdir($path, $permissions, true);
    }
}

function table_exist($conn, $table) {
    $table = $conn->real_escape_string($table);
    $sql   = "SHOW TABLES LIKE '" . $table . "'";
    $res   = $conn->query($sql);
    return ($res->num_rows > 0);
}

function usernameCheck($username, $table) {
    global $conn;
    if (!validUsername($username)) {
        return '__TAKEN__';
    }
    $u       = mysqli_real_escape_string($conn, $username);

    $sql     = "SELECT username FROM $table WHERE username='$u' LIMIT 1";

    $results = $conn->query($sql);
    if (mysqli_num_rows($results) > 0) {
        return "__TAKEN__";
    }
    return '__NOT_TAKEN__';
}

function emailCheck($email, $table) {
    global $conn;

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return "__TAKEN__";
    }
    $e       = mysqli_real_escape_string($conn, $email);

    $sql     = "SELECT email FROM $table WHERE email='$e'";

    $results = $conn->query($sql);
    if (mysqli_num_rows($results) > 0) {
        return "__TAKEN__";
    }
    return '__NOT_TAKEN__';
}

function is_forbidden($name) {
    $forbidden = array(
        'admin',
        'vf_admin',
        'member',
  'oc-includes',
        'images',
        'video',
        'audio',
        'htaccess',
        'username',
        'password',
        'website',
        'document',
        'facebook',
        'twitter',
        'whatsapp',
        'oluchat',
  'olusocial',
  'oluschool',
        'superadmin',
        'vf_private',
        'private',
        'pofficials',
        'gp_pofficials',
        'private',
        'google',
        'hack',
    'act',
   'act_act'
    );

    if (in_array($name, $forbidden)) {
        return true;
    }
    return false;
}

function is_profane($word) {
    $profanities = array(
        'fuck',
        'bastard'
    );

    foreach ($profanities as $profanity) {
        if (preg_match('/' . preg_quote($profanity, '/') . '/i', $word)) {
            return true;
        }
    }
}

function validUsername($username, $admin = false) {

    if (empty($username)) {
        return false;
    }
    else if (!$admin && (startsWith($username, 'gp_') || startsWith($username, 'vf_'))) return false;
    else if (preg_match("/^([a-z]+)_?[a-z0-9]{3,29}$/i", $username)) return true;
    else return false;

}

function validPassword($password) {
    if (empty($password)) return false;
    else if (preg_match("/^[a-z0-9~@#%_+*?-]{6,50}$/i", $password)) return true;
    else return false;

}

function validName($fullname) {
    if (empty($fullname)) return false;
    else if (preg_match("/^[a-zàáèöïÿŕëäśĺžźżçćčñńôêėřûîéìíòóùú]([.'-]?[a-z àáèöïÿŕëäśĺžźżçćčñńôêėřûîéìíòóùú]+)*$/iu", $fullname)) {
        return true;
    }
    else {
        return false;
    }
}

function test_input($data) {
    if (empty($data)) return "";
    $data = trim(preg_replace("/\s+/", " ", $data));
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function user_photo_icon($user, $g = "") {
    if ($g) return groupUrl($user) . "/profile_picture_small.jpg";
    else return userUrl($user) . "/profile_picture_small.jpg";

}

function inboxUser($user        = "", $message     = "", $meta        = "", $send_as     = "", $group       = "") {
    //$user i.e $chat_to
    if (empty($user)) {
        return "";
    }

    $chat_from   = 'vf_private';

    if (!empty($send_as)) {
        $chat_from   = $send_as;
    }

    $chat_id     = randomNumber(15);
    $chat_time   = time();
    $version     = _SITE_VERSION_;

    $mdata       = array();

    $mdata["cid"]             = $chat_id;
    $mdata["cf"]             = $chat_from;
    $mdata["ct"]             = $user;
    $mdata["msg"]             = $message;
    $mdata["can_comment"]             = "";

    if (!empty($meta)) {
        $mdata       = array_merge($mdata, $meta);
    }

    $mdata["time"]             = $chat_time;
    $mdata["ver"]             = "0";
    $mdata["sver"]             = $version;
    $mdata["is_admin"]             = "1";

    $messageData = json_encode($mdata);

    $udir        = getUserDir($user);

    if (!is_dir($udir)) {

        return false;

    }

    $msgStore = new \SleekDB\Store("messages", $udir, ["timeout" => false, "auto_cache" => false]);

    if ($msgStore->insert(['message' => $messageData, 'chat_to' => $user, 'chat_from' => $chat_from, 'chat_id' => $chat_id, 'version' => $version, 'admin' => 1])) {
        return true;

    }
    else {
        return false;
    }
}

function sendWelcomeMessage($to) {

    $message  = "";
    $meta     = array();

    $wmessage = _CHAT_FILES_DIR_ . '/welcome/welcome.txt';

    if (file_exists($wmessage)) {
        $message  = file_get_contents($wmessage);

        if (!empty($message)) {

            $message  = preg_replace('~[\r\n]+~', ':nl::', $message);

            $message  = str_ireplace('[user::]', str_ireplace('vf_', '', $to) , $message);

            $meta["hl"]          = substr($message, 0, 100);

        }
    }

    $wvideo   = _CHAT_FILES_DIR_ . '/welcome/0123456789.mp4';

    if (file_exists($wvideo)) {

        $sfpath   = _CHAT_FILES_PATH_ . '/welcome/0123456789.mp4';

        $meta["hl"]          = "Watch video";
        $meta["file"]          = "video";
        $meta["pt"]          = "Video File";
        $meta["size"]          = "";
        $meta["fol"]          = "welcome";
        $meta["lfpath"]          = "";
        $meta["sfpath"]          = $sfpath;
        $meta["fx"]          = "mp4";

        if (!empty($message)) {
            $message .= ':nl::';
        }
        $message .= "[file=::0123456789.mp4::]";
    }

    if (!empty($message) ) {

        require_once ('../oc-third-party/SleekDB/Store.php');

        inboxUser($to, $message, $meta, "vf_private");

    }

}

function massMessageTest( $message="", $to, $total=10){

 if( empty($to) ) {
   die('{"error":"Recipient empty"}');
}
else if( empty( $message) ) {
   die('{"error":"Message empty"}');
}

$message=test_input( $message);

require('../../oc-third-party/SleekDB/Store.php');

$nmeta=array();
 $success=0;
for($i=0; $i<$total;$i++){

$send_as= randomString(7);

$meta["hl"]=substr( $message,0,100);

 if( inboxUser( $to, $message, $meta,$send_as) ) {  
  $success++;
  }
}
 die('{"status":"success","result":"Total successful: '.$success.'"}');
}



function members_can_interact($gpin) {
    if (is_group($gpin)) return true;
    else return false;
}

function is_page($gpin) {
    $str = substr(strtolower($gpin) , 0, 4);
    $arr = array(
        'gp_p',
        'gp_v'
    );
    if (in_array($str, $arr)) return true;
    else return false;
}

function is_group($gpin) {
    $str = substr(strtolower($gpin) , 0, 4);;
    $arr = array(
        'gp_g',
        'gp_u'
    );
    if (in_array($str, $arr)) return true;
    else return false;
}

function allowedImages() {
    return ['image/gif', 'image/jpeg', 'image/jpg', 'image/png', 'image/bmp', 'image/pjpeg'];
}

function allowedVideos() {
    return ['video/mp4', 'application/octet-stream', 'video/3gpp', 'video/webm', 'video/mpeg'];
}

function allowedAudios() {
    return ['audio/mp4', 'audio/mpeg', 'audio/ogg', 'audio/mp3', 'audio/wav', 'audio/aac', 'application/octet-stream', 'video/webm', 'video/mp4', 'audio/webm', 'audio/webm;codecs=opus', 'audio/pcm', 'audio/mid', 'audio/x-m4a', 'audio/midi', 'audio/aiff', 'audio/x-mpeg-3', 'video/x-mpeg', 'audio/mpeg3', 'audio/x-mpeg'];

}

function bannedDocuments() {
    return [];
}

function allowedDocuments() {
    return ['application/pdf', 'application/zip', 'text/plain', 'video/mp4', 'video/3gpp', 'audio/mp4', 'audio/mpeg', 'audio/mpeg3', 'application/octet-stream', 'image/jpg', 'image/jpeg', 'image/gif', 'image/png', 'application/x-httpd-php', 'text/html', 'text/x-php', 'application/x-php', 'application/apk', 'application/msword', 'application/x-compressed', 'application/x-gzip', 'multipart/x-gzip', 'image/x-icon', 'application/base64', 'application/mspowerpoint', 'application/vnd.ms-powerpoint', 'application/x-mspowerpoint', 'application/x-shockwave-flash', 'multipart/x-zip', 'application/x-compress', 'application/excel', 'application/vnd.ms-excel', 'application/x-excel', 'application/x-zip-compressed', 'application/xml', 'application/x-msexcel', 'application/plain', 'application/x-tar', 'audio/midi', 'video/mpeg', 'text/css', 'video/avi', 'video/msvideo', 'video/x-msvideo', 'text/x-java-source', 'image/pjpeg', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.openxmlformats-officedocument.wordprocessingml.template', 'application/vnd.ms-word.document.macroEnabled.12', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.openxmlformats-officedocument.spreadsheetml.template', 'application/vnd.ms-powerpoint', 'application/vnd.ms-powerpoint.presentation.macroEnabled.12', 'application/vnd.ms-access'];
}

function createConfigFile($dbhost, $dbname, $dbuname, $dbpass      = "", $tp          = "") {
    $cf___       = '$CONFIG___';

    $data        = "<?php if( !defined('_DEFINED_') ){  
  die('{\"error\":\"Error occured. CONFF::NF\"}'); 
} 
 
 define('_TABLE_PREFIX_','{$tp}');
 define('_TABLE_ADMINS_','{$tp}admins');
 define('_TABLE_USERS_','{$tp}users');
 define('_TABLE_GROUPS_','{$tp}groups');
 define('_TABLE_GROUPS_MESSAGES_','{$tp}groups_messages');
 define('_TABLE_TOKENS_','{$tp}tokens');
 define('_TABLE_COMMENTS_','{$tp}comments');

$cf___=(object) array(
 'host' =>  '{$dbhost}',
 'username' => '{$dbuname}',
 'password' => '{$dbpass}', 
 'database' => '{$dbname}'
); ";

    $config_file = _CHAT_DIR_ . '/oc-includes/config.php';

    return file_put_contents($config_file, $data);
}

function Emailer($email, $subject, $body, $reply_to     = "noreply@noreply.com") {

    $emailer_file = _ADMIN_DIR_ . '/settings-files/emailer-config.txt';

    if (localHost()) {
        $emailer_file = _ROOT_DIR_ . '/oc-emailer-config.txt';

    }

    if (!file_exists($emailer_file)) {
        return false;
    }

    $emailer_info     = file_get_contents($emailer_file);

    $ei               = json_decode($emailer_info);

    $email_channel    = isset($ei->email_channel) ? $ei->email_channel : "default";
    $email_host       = isset($ei->email_host) ? $ei->email_host : "";
    $email_auth       = isset($ei->email_authentication) ? $ei->email_authentication : "";
    $email_username   = isset($ei->email_username) ? $ei->email_username : "";
    $email_password   = isset($ei->email_password) ? $ei->email_password : "";
    $email_port       = isset($ei->email_port) ? $ei->email_port : "465";
    $email_encryption = isset($ei->email_encryption) ? $ei->email_encryption : "ssl";
    $email_from       = isset($ei->email_from) ? $ei->email_from : "";
    $email_alias      = isset($ei->email_alias) ? $ei->email_alias : "";

    if ($email_channel == 'default') {

        $headers          = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=utf8' . "\r\n";

        // Additional headers
        $headers .= "To: <$email>\r\n";
        $headers .= 'From:' . $email_from . "\r\n";
        $headers .= "Cc: $email\r\n";
        $headers .= "Bcc: $email\r\n";

        if (@mail($email, $subject, $body, $headers)) {
            return true;
        }
        else {
            return false;
        }

    }

    require _PROJECT_DIR_ . '/oc-third-party/PHPMAILER/Exception.php';
    require _PROJECT_DIR_ . '/oc-third-party/PHPMAILER/PHPMailer.php';
    require _PROJECT_DIR_ . '/oc-third-party/PHPMAILER/SMTP.php';

    $mail = new PHPMailer\PHPMailer\PHPMailer;
    $mail->IsSMTP();
    $mail->Mailer     = "smtp";
    $mail->SMTPDebug  = 0;
    $mail->SMTPAuth   = (!empty($email_auth) ? true : false);
    $mail->SMTPSecure = $email_encryption;

    $mail->Host       = $email_host; // Enter your host here
    $mail->Username   = $email_username;
    $mail->Password   = $email_password;
    $mail->Port       = $email_port;

    //$mail->SMTPSecure=PHPMailer::ENCRYPTION_STARTTLS;
    /*
    Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
    */

    $mail->IsHTML(true);
    $mail->setFrom($email_from, $email_alias);
    $mail->addReplyTo($reply_to, 'message');
    $mail->Subject = $subject;
    $mail->Body    = $body;
    $mail->AddAddress($email);

    if ($mail->Send()) return true;
    else return false;

}

function createToken($conn, $email, $expiryTime_   = 15, $token_length_ = 6) {

    $curTime       = time();
    $expiryTime    = $curTime + (60 * $expiryTime_);
    $table         = _TABLE_TOKENS_;
    $token         = randomNumber($token_length_);

    $stmt          = $conn->prepare("DELETE FROM $table WHERE expiry_time<'$curTime'");

    if (!$stmt || !$stmt->execute()) {
        logIt('Could not delete old tokens: createToken() function ');
    }

    $stmt = $conn->prepare("INSERT INTO $table ( email, token, expiry_time)
VALUES (?,?,?)");

    if ($stmt && $stmt->bind_param('ssi', $email, $token, $expiryTime) && $stmt->execute()) {

        $stmt->close();

        return $token;
    }
    else {
        return "";
    }
}

function sendEmailVerificationCode($email, $code) {

    $body = "Thank you for registering! <br>Your verification code is:<br><br><h2>{$code}</h2>";

    return Emailer($email, 'Verification code', $body);

}

function sendPasswordResetCode($email, $code) {

    $body = "Your password reset code is:<br><br><h2>{$code}</h2><br><i>Code expires within 15 minutes.</i><br><br>Kindly, ignore this email if you didn't request for this.";

    return Emailer($email, 'Password reset code', $body);
}

function paginate($item_per_page, $current_page, $total_records, $total_pages, $page_url, $type) {

    $pagination = '';
    if ($total_pages > 0 && $total_pages != 1 && $current_page <= $total_pages) { //verify total pages and current page number
        $pagination .= '<ul class="pagination">';

        $right_links   = $current_page + 3;
        $previous      = $current_page - 3; //previous link
        $next          = $current_page + 1; //next link
        $first_link    = true; //boolean var to decide our first link
        if ($current_page > 1) {
            $previous_link = $current_page - 1;
            $pagination .= '<li class="first"><a href="' . $page_url . '?page=1" title="First" class="' . $type . '_page_link">«</a></li>'; //first link
            $pagination .= '<li><a href="' . $page_url . '?page=' . $previous_link . '" title="Previous" class="' . $type . '_page_link"><</a></li>'; //previous link
            for ($i = ($current_page - 2);$i < $current_page;$i++) { //Create left-hand side links
                if ($i > 0) {
                    $pagination .= '<li><a href="' . $page_url . '?page=' . $i . '" class="' . $type . '_page_link">' . $i . '</a></li>';
                }
            }
            $first_link = false; //set first link to false
            
        }

        if ($first_link) { //if current active page is first link
            $pagination .= '<li class="active"><a>' . $current_page . '</a></li>';
        }
        elseif ($current_page == $total_pages) { //if it's the last active link
            $pagination .= '<li class="active"><a>' . $current_page . '</a></li>';
        }
        else { //regular current link
            $pagination .= '<li class="active"><a>' . $current_page . '</a></li>';
        }

        for ($i = $current_page + 1;$i < $right_links;$i++) { //create right-hand side links
            if ($i <= $total_pages) {
                $pagination .= '<li><a href="' . $page_url . '?page=' . $i . '" class="' . $type . '_page_link">' . $i . '</a></li>';
            }
        }
        if ($current_page < $total_pages) {
            $next_link = $current_page + 1;
            $pagination .= '<li><a href="' . $page_url . '?page=' . $next_link . '" class="' . $type . '_page_link">></a></li>'; //next link
            $pagination .= '<li class="last"><a href="' . $page_url . '?page=' . $total_pages . '" title="Last" class="' . $type . '_page_link">»</a></li>'; //last link
            
        }

        $pagination .= '</ul>';
    }
    return $pagination; //return pagination links
    
}

//PAGINATION 2
function pagination($obj) {

    $item_count    = $obj["total_items"];
    $limit         = $obj["limit"];
    $cur_page      = $obj["page_number"];
    $link          = $obj["link"];
    $link_class    = isset($obj["link_class"]) ? $obj["link_class"] : "";

    $page_count    = ceil($item_count / $limit);
    $current_range = array(
        ($cur_page - 2 < 1 ? 1 : $cur_page - 2) ,
        ($cur_page + 2 > $page_count ? $page_count : $cur_page + 2)
    );

    // First and Last pages
    $first_page    = $cur_page > 3 ? '<a href="' . sprintf($link, '1') . '" class="' . $link_class . '">1</a>' . ($cur_page < 5 ? ', ' : ' ... ') : null;
    $last_page     = $cur_page < $page_count - 2 ? ($cur_page > $page_count - 4 ? ', ' : ' ... ') . '<a href="' . sprintf($link, $page_count) . '" class="' . $link_class . '">' . $page_count . '</a>' : null;

    // Previous and next page
    $previous_page = $cur_page > 1 ? '<a href="' . sprintf($link, ($cur_page - 1)) . '" class="' . $link_class . '">Previous</a> | ' : null;
    $next_page     = $cur_page < $page_count ? ' | <a href="' . sprintf($link, ($cur_page + 1)) . '" class="' . $link_class . '">Next</a>' : null;

    // Display pages that are in range
    for ($x             = $current_range[0];$x <= $current_range[1];++$x) $pages[] = '<a href="' . sprintf($link, $x) . '" class="' . $link_class . '">' . ($x == $cur_page ? '<strong>' . $x . '</strong>' : $x) . '</a>';

    if ($page_count > 1) return '<p class="pagination-container text-center">' . $previous_page . $first_page . implode(' ', $pages) . $last_page . $next_page . '</p>';

    /*
    Usage: $obj=["total_items"=>100,"limit"=>20,"page_number"=>1,"link"=>"?page=%d","link_class"=>"btn btn-sm btn-secondary"];
    echo '<div class="mt-5"></div>'.pagination($obj);
    */

}

function formatBytes($bytes, $precision = 2) {
    $units     = array(
        "b",
        "k",
        "m",
        "g",
        "t"
    );
    $bytes     = max($bytes, 0);
    $pow       = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow       = min($pow, count($units) - 1);
    $bytes /= (1 << (10 * $pow));
    return round($bytes, $precision) . " " . $units[$pow];
}

function checkPerms($path) {
    clearstatcache(null, $path);
    return decoct(fileperms($path) & 0777);
}
