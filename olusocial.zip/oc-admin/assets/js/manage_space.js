$(function(){
 $('body').on('click','.load-dir',function(){
var this_=$(this);
var level=this_.data('level');
var ml=this_.data('margin-left');
var load_to=this_.data('load-to');
 buttonSpinner(this_);
 $('.load-dir').prop('disabled',true);

 var resultDiv=$('.load-to-'+ load_to);
$.ajax({
  url: 'ajax/manage_space.php',
  type:'post',
 data:{
   level: level,
   margin_left: ml,
   load: 'load',
  }
}).done(function(result){
  buttonSpinner(this_,true);
 $('.load-dir').prop('disabled',false);
   resultDiv.html(result);
}).fail(function(e){
  buttonSpinner(this_,true);
$('.load-dir').prop('disabled', false);
  toast( JSON.stringify(e) );
  });

});


$('body').on('click','.delete-fd',function(){

var this_=$(this);
var path=this_.data('path');
var filename=this_.data('name');
var type=this_.data('type');
var cls=this_.data('class');

if(!confirm('Delete ' + type + ' ' + filename + '?')) return;

 buttonSpinner(this_);
 $('.delete-fd').prop('disabled',true);

$.ajax({
  url: 'ajax/manage_space.php',
  type:'post',
 data:{
   path: path,
   delete: 'delete',
  }
}).done(function(result){
 
  buttonSpinner(this_,true);
 $('.delete-fd').prop('disabled',false);
  if(result.match(/__SUCCESS__/)){
 $('.' + cls).remove();
 }else if(result.match(/__PERMISSION_DENIED__/) ){
 return toast('Permission denied.');
}else{
  toast('Failed to delete.');
}
}).fail(function(e,txt,xhr){
  buttonSpinner( this_,true);
$('.delete-fd').prop('disabled', false);
  toast("Check your connection. " + xhr);
    });
  });

$('body').on('click','#delete-db-messages',function(){
var this_=$(this);
var age=+$('#age').val();
var limit_=+$('#limit').val();

rdiv=$('#db-result');
 rdiv.empty();

if(!confirm("Delete?\nIt's not reversible.")) return;

 buttonSpinner(this_);
 this_.prop('disabled',true);

$.ajax({
  url: 'ajax/manage_space.php',
  type:'post',
 data:{
   'delete_db_messages': 'true',
 'age': age,
'limit': limit_
  }
}).done(function(result){
  buttonSpinner(this_,true);
 this_.prop('disabled',false);

if(result.match(/SUCCESS/)){
   rdiv.html(result);
 }else if( result.match(/__PERMISSION_DENIED__/) ){
 return toast('Permission denied.');
}else{
  toast('Failed to delete. ' + result);
}
}).fail(function(e,txt,xhr){
  buttonSpinner( this_,true);
 this_.prop('disabled', false);
  toast( JSON.stringify(e));
    });

  });



$('body').on('click','#del-comment-btn',function(){
var this_=$(this);
var age=+$('#del-comment-age').val();
var limit_=+$('#del-comment-limit').val();

rdiv=$('#del-comment-result');
 rdiv.empty();

if(!confirm("Delete?\nIt's not reversible.")) return;

 buttonSpinner(this_);
 this_.prop('disabled',true);

$.ajax({
  url: 'ajax/manage_space.php',
  type:'post',
 data:{
   'delete_comments': 'true',
 'age': age,
'limit': limit_
  }
}).done(function(result){
  buttonSpinner(this_,true);
 this_.prop('disabled',false);

if(result.match(/SUCCESS/)){
   rdiv.html(result);
 }else if( result.match(/__PERMISSION_DENIED__/) ){
 return toast('Permission denied.');
}else{
  toast('Failed to delete. ' + result);
}
}).fail(function(e,txt,xhr){
  buttonSpinner( this_,true);
 this_.prop('disabled', false);
  toast( JSON.stringify(e));
    });

  });

});
