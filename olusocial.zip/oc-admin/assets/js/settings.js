$(function(){

$('body').on('click','#change-email-btn',function(e){
e.preventDefault();
 var resultDiv=$('#change-email-result');
 resultDiv.empty();
 var ebox=$('#change-email-box');
 var oebox=$('#old-email');

 var oemail=$.trim(oebox.val());
var email=$.trim( ebox.val() );

 if( !email||email.length<6||email.length>100){
 resultDiv.html('<span class="text-danger">Enter a vaild email address.</span>');
 return;
}
else if( oemail.toLowerCase()==email.toLowerCase() ){
 resultDiv.html('<span class="text-success">Email changed successfully</span>');
 return;
}


  var this_=$(this);
 resultDiv.html('');

  buttonSpinner( this_);
 this_.prop('disabled',true);

$.ajax({
  url: _ADMIN_URL_ + '/ajax/change_email.php',
  type:'POST',
dataType:'json',
  data: {
  new_email: email,
 }
}).done(function( result ){
this_.prop('disabled', false);
  buttonSpinner( this_,true);
  if( result.status && result.status=='success' ){
  resultDiv.html('<span class="text-success">' + result.result + '</span>');
oebox.val(email);
   pbox.val('');
  }else if(result.error){
  resultDiv.html('<span class="text-danger">' + result.error + '.</span>');
  }
else{
 toast('Unknown error occured.');
}
}).fail(function(e,txt,xhr){
  buttonSpinner( this_,true);
this_.prop('disabled', false);
  resultDiv.html('<span class="text-danger">Error occured: ' + xhr + '</span>');
  });

});

$('body').on('click','#welcome-message-btn',function(e){
e.preventDefault();
  var this_=$(this);

var resultDiv=$('#save-welcome-message-result');

 var tbox=$('#welcome-message-box');
 var msg=$.trim( tbox.val() );

if(!msg){
  if( !confirm("Please confirm") ){
 return;
 }
}

 var words=msg.replace(/\s+/g,' ');
 words=words.split(' ').length;
 if(words>500) {
   resultDiv.html('<span class="text-danger">Welcome message should not be more than 500 words. ' + words + ' written.</span>');
  return;
}
 
  buttonSpinner( this_);
  resultDiv.empty();
  //var totalWords=
this_.prop('disabled',true);
$.ajax({
  url: _ADMIN_URL_ + '/ajax/save_welcome_message.php',
  type:'POST',
  dataType:'json',
  data: {
   message: msg,
 }
}).done(function( result ){
  buttonSpinner( this_,true);
this_.prop('disabled', false);
  if( result.status ){
 toast(result.result,{type:'success'});
}else if(result.error){
  toast(result.error);
  }
else{
  toast('Failed to alter.');
}

}).fail(function(e){
buttonSpinner( this_,true);
this_.prop('disabled', false);
 toast('Check your network connection.');
});

});

$('body').on('click','#delete-welcome-video',function(e){
   e.preventDefault();
 var this_=$(this);
if(!confirm('Delete welcome video?')){
 return;
}
buttonSpinner( this_);
 this_.prop('disabled',true);
 $.ajax({
  url: _ADMIN_URL_ + '/ajax/delete_welcome_video.php',
}).done(function(result){
buttonSpinner( this_,true);
 this_.prop('disabled', false);
if(result.match(/__SUCCESS__/)){
  this_.remove();
}else{
 toast('Unable to delete at the moment. Try again.');
}
}).fail( function(e){
  buttonSpinner( this_,true);
 this_.prop('disabled', false);
toast('Unable to delete. Try again.');
 });
});


$('body').on('click','#save-settings-btn',function(e){
e.preventDefault();
  var this_=$(this);

 buttonSpinner( this_);
this_.prop('disabled',true);

$.ajax({
 url: _ADMIN_URL_ + '/ajax/save_settings.php',
  type:'POST',
  dataType:'json',
  data: $('#settings-form').serialize()
}).done(function( result ){
 buttonSpinner( this_,true);
this_.prop('disabled', false);
 if( result.status ){
 toast(result.result,{type:'success'});
 }else if(result.error){
  toast(result.error);
  }
else{
  toast('Failed to alter.');
}

}).fail(function(e,txt,xhr){
buttonSpinner( this_,true);
this_.prop('disabled', false);
//alert( JSON.stringify(e))
 toast('Check your network connection. '+ xhr );
});

});



$('body').on('click','#save-emailer-config-btn',function(e){
e.preventDefault();
  var this_=$(this);

var epass=$.trim( $('#email-password').val());

var echannel=$.trim($('#email-channel').val());

if(echannel!='default' && epass.length<3){
 return toast('Enter SMTP password.');
}


 buttonSpinner( this_);
this_.prop('disabled',true);
$.ajax({

  url: _ADMIN_URL_ + '/ajax/save_emailer_config.php',
  type:'POST',
  dataType:'json',
  data: $('#stmp-setup-form').serialize()
}).done(function( result ){
  buttonSpinner( this_,true);
this_.prop('disabled', false);
  if( result.status ){
 toast(result.result,{type:'success'});
}else if(result.error){
  toast(result.error);
  }
else{
  toast('Failed to alter.');
}

}).fail(function(e){
buttonSpinner( this_,true);
this_.prop('disabled', false);
//alert( JSON.stringify(e))
 toast('Check your network connection.');
});

});


$('body').on('click','#change-password-btn',function(e){
e.preventDefault();

var resultDiv=$('#change-password-result');
 resultDiv.empty();

 var opbox=$('#old-password-box');
 var pbox=$('#change-password-box');
 var opw=$.trim(opbox.val());
 var pw=$.trim( pbox.val() );

if( !opw||opw.length<6||opw.length>50){
  resultDiv.html('<span class="text-danger">Old password should contain at least 6 characters. Max: 50.</span>');
 return;
}
else
if( !pw||pw.length<6||pw.length>50){
 resultDiv.html(' <span class="text-danger">Password should contain at least 6 characters. Max: 50.</span>');
 return;
}
 else if( !pw.match( /^[a-z0-9~@#%_+*?-]+$/i ) ){
 resultDiv.html('<span class="text-danger">Passwords can only contain these characters: a-z 0-9 ~@#%_+*?-</span>');
 return;
}

var this_=$(this);
  this_.prop('disabled',true);
  buttonSpinner( this_);

$.ajax({
  url: _ADMIN_URL_ + '/ajax/change_password.php',
  type:'POST',
dataType:'json',
  data: {
  old_password: opw,
  new_password: pw,
 }
}).done(function( result ){
  buttonSpinner( this_,true);
 this_.prop('disabled',false);
  
  if( result.status){
  resultDiv.html('<span class="text-success">Password changed successfully.</span>');
   pbox.val('');
   opbox.val('');
  }else if(result.error){
resultDiv.html('<span class="text-danger">' + result.error + ' </span>');
}else{
resultDiv.html('<span class="text-danger">Password could not be changed.</span>');
  }
}).fail(function(e, txt, xhr){
  buttonSpinner( this_,true);
this_.prop('disabled',false);
  toast('Check your internet connection. ' + xhr);
 //alert(JSON.stringify(e) );
  });
});



$('body').on('click','#upgrade-version-btn',function(e){
e.preventDefault();

 var vcode=$('#upgrade-version-code').val();
 var vinfo=$('#upgrade-version-info').val();
 var vurl=$('#upgrade-version-location').val();

 if(!vcode.match(/^[0-9.]+$/) ){
   return toast('Version code not a number');
}

var this_=$(this);
  this_.prop('disabled',true);
  buttonSpinner( this_);

$.ajax({
  url: _ADMIN_URL_ + '/ajax/set-app-upgrade.php',
  type:'POST',
dataType:'json',
  data: {
  version_code: vcode,
  version_info: vinfo,
  version_url: vurl,
 }
}).done(function( result ){
  buttonSpinner( this_,true);
 this_.prop('disabled',false);
  
  if( result.status){
  toast(result.result,{type:'success'});
  }else if(result.error){
  toast(result.error);
}else{
  toast('Unknown error');
  }
}).fail(function(e, txt, xhr){
  buttonSpinner( this_,true);
this_.prop('disabled',false);
  toast('Check your internet connection. ' + xhr);
 //alert(JSON.stringify(e) );
  });

});


});
