<?php
/**
* Class and Function List:
* Function list:
* Classes list:
*/
if (!isset($_SESSION))
  {
    session_start();
  }
require ('../../oc-includes/bootstrap.php');
adminLoggedIn(false, 'die', 'json');

if (!adminCanMessageUser())
  {
    die('{"error":"Permission denied."}');
  }

if (empty($_POST['send_to'])
//||empty($_POST['send_as'] )
 || !isset($_POST['message']) || !isset($_POST['file_message']))
  {

    die('{"error":"One or more fields are empty."}');

  }

$admin_username = getAdminInfo('username');

$send_to        = test_input(strtolower($_POST['send_to']));

$send_to        = "gp_" . $send_to;

$send_as        = $admin_username . "~"; 

if( !empty($_POST["send_as"] ) && validUsername($_POST['send_as'] ) ){
 $send_as=test_input( strtolower( $_POST['send_as'] ) );

$userdir=getUserDir( $send_as );

if( strpos( $send_as, '_' ) === false && is_dir( $userdir) ){

  die('{"error":"Please use another &quot;send as&quot;"}');
 }
}

if (!validUsername($send_to, true))
  {
    die('{"error":"Enter a valid group or page pin."}');
  }

require '../../oc-includes/server.php';

$message      = $can_comment  = $file_message = "";

$meta         = array();
$file_size    = "";

if (!empty($_POST['ext_file_url']))
  {

    if (!empty($_POST['file_size']))
      {
        $file_size    = (int)$_POST["file_size"] * (1024 * 1024);

      }

    $sfpath       = test_input($_POST['ext_file_url']);

    if (!preg_match("@^https?://@", $sfpath))
      {
        die('{"error":"Enter a valid URL. Https or Http"}');
      }
    else if (filter_var($sfpath, FILTER_VALIDATE_URL) === false)
      {
        die('{"error":"Enter a valid URL."}');
      }

    $hl = str_replace(array(
        '_',
        '-'
    ) , ' ', basename($sfpath)); // file highlight
    

    if (empty($_POST["file_type"]))
      {
        die('{"error":"Please select type of file you are sending."}');

      }

    $ftype = test_input(strtolower($_POST["file_type"]));

    $ext   = "null";

    switch ($ftype)
      {

    case "image":
        $ext   = 'gif';
    break;
    case "video":
        $ext = 'mp4';
    break;
    case "audio":
        $ext = 'mp3';
    break;
    case "text":
        $ext = 'txt';
    break;
      }

    if (!empty($_POST['file_caption']))
      {
        $hl = test_input(preg_replace("/[^0-9a-zA-Z _-]/", "", $_POST['file_caption']));

        $hl = substr($hl, 0, 60);
      }

    $meta["hl"]    = $hl;
    $meta["file"]    = "video";
    $ftype;
    $meta["pt"] = $hl;
    $meta["fx"] = "";
    $ext;
    $meta["size"]              = $file_size;
    $meta["fol"]              = "";
    $meta["lfpath"]              = "";
    $meta["sfpath"]              = $sfpath;

    $cid          = randomNumbers(15);
    $message      = "[file=::{$cid}.{$ext}::]";

  }
else if (!empty($_POST['meta']))
  {

    $meta         = json_decode(base64_decode(trim($_POST['meta'])) , true);
  }

if (empty($message) && !empty($_POST['file_message']))
  {
    $file_message = test_input($_POST['file_message']);
    $message      = $file_message;
  }

if (!empty($_POST['message']))
  {
    if (!empty($message))
      {

        $message .= ":nl::";
      }

    $plain_message = htmlentities(trim($_POST['message']) , ENT_QUOTES);

    if (empty($meta))
      {
        $meta["hl"]               = substr($plain_message, 0, 100);

        // die('{"error":"'.$plain_message.'"}');
        
      }

    $message .= $plain_message;

  }

require '../../oc-ajax/group/group-functions.php';

if (!empty($_POST['can_comment']))
  {
    $can_comment = "1";
  }

if (customGroupMessage($conn, $send_to, $message, $meta, $can_comment, $send_as) === 1)
  {
    die('{"status":"success","result":"Sent successfully."}');
  }

die('{"error":"Message not sent."}');
