<?php
/**
* Class and Function List:
* Function list:
* Classes list:
*/
if (!isset($_SESSION))
    {
    session_start();
    }
require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (empty($_POST['version_code']) || empty($_POST['version_info']) || empty($_POST['version_url']))
    {
    die('{"error":"Fill all data."}');

    }
else if (!adminCanChangeSettings())
    {
    die('{"error":"Permission denied."}');
    }

$result = array();

$result["version_code"]        = test_input($_POST["version_code"]);
$result["version_info"]        = test_input(str_replace(array(
    "\r\n",
    "\r",
    "\n",
    "\\r",
    "\\n",
    "\\r\\n"
) , ":nl::", $_POST["version_info"]));
$result["version_url"]        = test_input($_POST["version_url"]);

$data   = json_encode($result);

$file   = _ADMIN_DIR_ . '/settings-files/app-upgrade-data.txt';

if (file_put_contents($file, $data) !== false)
    {

    die('{"status":"success","result":"Saved successfully"}');
    }
else
    {

    die('{"error":"Could not save."}');
    }
