<?php
/**
* Class and Function List:
* Function list:
* - blockUser()
* Classes list:
*/
if (!isset($_SESSION))
  {
    session_start();
  }

header('Content-type:application/json;charset=utf-8');

require ('../../oc-includes/bootstrap.php');
adminLoggedIn(false, 'die', 'json');

if (!adminCanBlockUser())
  {
    die('{"error":"Permission denied."}');
  }

if (empty($_POST['username']))
  {
    die('{"error":"Empty parameters."}');
  }

require '../../oc-includes/server.php';

$username = test_input(strtolower($_POST['username']));

if ($username == 'vf_superadmin')
  {
    die('{"error":"You cannot block this Official account."}');
  }

function blockUser($con, $username, $user_dir)
  {
$secure_file = $user_dir . "/secure__.php";

    $table       = _TABLE_USERS_;

    $new_ustatus = '-1';

    if (!$query       = mysqli_query($con, "SELECT user_status FROM $table WHERE username='$username' LIMIT 1"))
      {
        die('{"error":"Unable to alter now."}');
      }
    else if (mysqli_num_rows($query) < 1)
      {
        die('{"error":"User not found."}');
      }

    $row         = mysqli_fetch_assoc( $query);
    $ustatus     = $row['user_status'];

    if ($ustatus == '-1')
      {
        $new_ustatus = '1';
      }

    if (!mysqli_query($con, "UPDATE $table SET user_status='$new_ustatus' WHERE username='$username' LIMIT 1"))
      {
        die('{"error":"Unable to alter at the moment. Err02."}');
      }

    if ($new_ustatus == '-1')
      {
        if (file_exists( $secure_file))
          {

            unlink($secure_file);
          }
        die('{"status":"success","result":"Successfully blocked."}');

      }
    else if ($new_ustatus == '1')
      {
   
   if (is_dir( $user_dir ) ){
  
 file_put_contents($secure_file, 'xxxx', FILE_APPEND);
       } die('{"status":"success","result":"Successfully unblocked."}');

      }
  }

$userDir = getUserDir($username);

blockUser($conn, $username, $userDir );
