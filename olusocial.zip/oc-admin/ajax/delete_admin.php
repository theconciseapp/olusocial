<?php
/**
* Class and Function List:
* Function list:
* Classes list:
*/
if (!isset($_SESSION))
  {
    session_start();
  }
header('Content-type:application/json;charset=utf-8');

if (empty($_POST['username']) )
  {
    die('{"error":"Admin username not found."}');
  }

require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if( !validUsername( $_POST['username'], true) )
  {
    die('{"error":"Admin username not valid."}');
  }


$admin_username = getAdminInfo('username');

$username = test_input( strtolower( $_POST['username']) );

if ($username == "vf_superadmin")
  {
    die('{"error":"Sorry! You cannot delete super."}');

  }
else if (!adminCanAddAdmin() )
  {
    die('{"error":"Sorry, you are not permitted to perform this task."}');
  }

require "../../oc-includes/server.php";

$table    = _TABLE_ADMINS_;

$stmt     = $conn->prepare("DELETE FROM $table WHERE username=? LIMIT 1");

  if( $stmt && $stmt->bind_param('s', $username) && $stmt->execute() )
      {
        if ($stmt->affected_rows > 0)
          {           
   $stmt->close();

//Delete from users table.
//Whenever an admin is created, an account is also created in users table to enable admins access app

 $table=_TABLE_USERS_;

try{

$stmt = $conn->prepare("DELETE FROM $table WHERE username=? LIMIT 1");

 $stmt->bind_param('s', $username);
 $stmt->execute();

 $userDir = getUserDir($username);

    if (is_dir( $userDir) )
    {
    deleteTree($userDir);
}

}catch(Exception $e){
  logIt($e->getMessage());
}
   $conn->close();
 die('{"status":"success","result":"Successfully deleted."}');
            
          }
      }

    $conn->close();
 
die('{"error":"Failed to delete."}');
