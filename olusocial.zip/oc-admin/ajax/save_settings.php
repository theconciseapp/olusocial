<?php
/**
* Class and Function List:
* Function list:
* Classes list:
*/
if (!isset($_SESSION))
  {
    session_start();
  }
require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanChangeSettings())
  {
    die('{"error":"Permission denied."}');
  }

$result = array();

foreach ($_POST as $key    => $val)
  {
    //do sanitization
    $val    = htmlspecialchars($val);

    if ($key == "app_name" && !validUsername($val, true))
      {

        die('{"error":"App name should start with an alphabet. Alphabets and numbers only supported. Min: 2, Max: 20 characters."}');
      }
    else if ($key == "users_per_group" && $val > _MAX_GROUP_MEMBERS_)
      {
        die('{"error":"Max members per group is ' . _MAX_GROUP_MEMBERS_ . '."}');
      }
    else if ($key == "chat_request_speed" && ($val < 5 || !is_numeric($val)))
      {
        die('{"error":"Posts & drop-it message check speed must be greater or equal to 5 seconds"}');

      }
    else if ($key == "max_group_check" && ($val < 1 || $val > 10))
      {

        die('{"error":"Maximum number of groups to query:  Value Should be between 1 and 10"}');

      }
    $key_          = $key;
    $result[$key_]               = $val;

  }

$data          = json_encode($result);

$settings_file = _ADMIN_DIR_ . '/settings-files/settings.txt';

if (file_put_contents($settings_file, $data) !== false)
  {

    die('{"status":"success","result":"Saved successfully"}');
  }
else
  {

    die('{"error":"Could not save."}');
  }
