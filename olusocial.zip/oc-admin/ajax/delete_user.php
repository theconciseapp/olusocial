<?php
/**
* Class and Function List:
* Function list:
* Classes list:
*/
if (!isset($_SESSION))
  {
    session_start();
  }
header('Content-type:application/json;charset=utf-8');
  //clearstatcache();
if (empty($_POST['username']))
  {
    die('{"error":"Empty parameter."}');
  }

require ('../../oc-includes/bootstrap.php');
adminLoggedIn(false, 'die', 'json');

if (!adminCanDeleteUser())
  {
    die('{"error":"Permission denied."}');
  }

require "../../oc-includes/server.php";

$table    = _TABLE_USERS_;

$username = test_input(strtolower($_POST['username']));

if ($username == 'vf_superadmin')
  {
    die('{"error":"Sorry, you cannot delete this official account."}');
  }

$stmt = $conn->prepare("DELETE FROM $table WHERE username=? LIMIT 1");
  
   if( $stmt && $stmt->bind_param('s', $username) && $stmt->execute())
      {
    $stmt->close();
    $table = _TABLE_GROUPS_;

        try
          {

            $stmt  = $conn->prepare("UPDATE $table SET total_members=total_members-1 WHERE group_pin='gp_pofficials' LIMIT 1");

            if ($stmt && $stmt->execute())
              {
                $stmt->close();
              }
          }
        catch(Exception $e)
          {
            //ignore error
            
          }

        $conn->close();

        $userDir = getUserDir($username);

    if (!is_dir( $userDir) )
          {
            die('{"status":"success","result":"Deleted successfully."}');

          }
     else {
    deleteTree($userDir);
              die('{"status":"success","result":"Deleted successfully."}');
          }
  }

die('{"error":"Failed to delete. Err02"}');
