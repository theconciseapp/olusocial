<?php
/**
* Class and Function List:
* Function list:
* Classes list:
*/
if (!isset($_SESSION))
  {
    session_start();
  }

header('Content-type:application/json;charset=utf-8');

require ('../../oc-includes/bootstrap.php');
adminLoggedIn(false, 'die', 'json');

if (!adminCanAddUser() )
  {
    die('{"error":"Permission denied"}');
  }

if (empty($_POST['username']) || empty($_POST['email']) || empty($_POST['fullname']) || empty($_POST['phone']) || empty($_POST['password']))
  {
    die('{"error":"One or more fields are empty."}');
  }

$username = strtolower($_POST['username']);

$email    = test_input(strtolower($_POST['email']));

$fullname = test_input(strtolower($_POST['fullname']));
$phone    = test_input($_POST['phone']);
$password = $_POST['password'];

if (!validUsername($username, true))
  {
    die('{"error":"Username can contain alphanumerics, underscore and must start with a letter. Min: 4, Max: 30"}');
  }
else if (startsWith($username, 'gp_'))
  {
    die('{"error":"Username is not available. Try another."}');
  }
else if (!filter_var($email, FILTER_VALIDATE_EMAIL))
  {
    die('{"error":"Enter a valid email address."}');
  }
else if (!validName($fullname))
  {
    die('{"error":"Enter a good full name."}');
  }
else if (!preg_match("/^[0-9+() -]{4,50}$/i", $phone))
  {
    die('{"error":"Enter a valid phone number."}');
  }
else if (strlen($password) < 6 || strlen($password) > 50)
  {
    die('{"error":"Password too short or long."}');
  }
else if (!preg_match("/^[a-z0-9~@#%_+*?-]{6,50}/i", $password))
  {
    die('{"error":"Password can only contain Alphanumerics, ~@#%_+*?-"}');
  }

require "../../oc-includes/server.php";

$username = mysqli_real_escape_string($conn, $username);

$email    = mysqli_real_escape_string($conn, $email);
$fullname = mysqli_real_escape_string($conn, $fullname);

$phone    = mysqli_real_escape_string($conn, $phone);

$password = password_hash($password, PASSWORD_DEFAULT);

$table    = _TABLE_USERS_;

if ($query    = $conn->query("SELECT username, email FROM $table WHERE  ( username='$username' OR email='$email') LIMIT 1"))
  {

    if (mysqli_num_rows($query) > 0)
      {
        $row      = mysqli_fetch_assoc($query);
        if ($username == $row['username'])
          {

            $conn->close();

            die('{"error":"Username is already registered."}');
          }
        elseif ($email == $row['email'])
          {
            $conn->close();
            die('{"error":"Email is already registered."}');
          }
      }
  }
else
  {

    $conn->close();

    die('{"error":"Temporarily unavalable."}');
  }

$reg_on     = date('Y-m-d H:i:s');
$userstatus = '1';

$sql        = "INSERT INTO $table (username, email, fullname, phone, password,user_status, added_on) VALUES ('$username','$email','$fullname','$phone','$password','$userstatus','$reg_on')";

if ($conn->query($sql))
  {

    if ($conn->affected_rows == 1)
      {

        $udir       = getUserDir($username);

        if (makeUserDir($username))
          {

            $nmfile     = $udir . "/lastseen.txt";
            file_put_contents($nmfile, time());

            $table = _TABLE_GROUPS_;

            try
              {
                $stmt  = $conn->prepare("UPDATE $table SET total_members=total_members+1 WHERE group_pin='gp_pofficials' LIMIT 1");

                if ($stmt && $stmt->execute())
                  {
                    $stmt->close();
                  }
              }
            catch(Exception $e)
              {
                //ignore error
                
              }

            $conn->close();

            die('{"status":"success","result":"Added successfully."}');
          }
      }
  }
$conn->close();
die('{"error":"Unable to add user. Please try again."}');
