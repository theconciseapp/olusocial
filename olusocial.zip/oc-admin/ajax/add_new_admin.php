<?php
/**
* Class and Function List:
* Function list:
* - checkUserEmailExist()
* Classes list:
*/
if (!isset($_SESSION)) {
    session_start();
}

require ('../../oc-includes/bootstrap.php');
adminLoggedIn(false, 'die', 'json');

$admin_username = getAdminInfo('username');

if(!adminCanAddAdmin() )
  {
    die('{"error":"Sorry, you are not permitted to perform this task."}');
  }


if (empty($_POST['username']) || empty($_POST['email']) || empty($_POST['fullname']) || empty($_POST['phone']) || empty($_POST['password']) || empty($_POST['role'])) {
    die('{"error":"One or more fields are empty."}');
}

$username = strtolower( $_POST['username']);

$email    = test_input(strtolower($_POST['email']));

$fullname = test_input(strtolower($_POST['fullname']));

$phone    = test_input($_POST['phone']);
$role     = (int)$_POST['role'];
$password = $_POST['password'];

if (!validUsername($username, true)) {
    die('{"error":"Username can contain alphanumerics, underscore and must start with a letter. Min: 4, Max: 30"}');
}
else if (startsWith( $username, 'gp_')) {
    die('{"error":"Username is not available. Try another."}');
}
else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die('{"error":"Enter a valid email address."}');
}
else if (!validName($fullname)) {
    die('{"error":"Enter a good name. Min: 2"}');
}
else if (!preg_match("/^[0-9+() -]{4,50}$/i", $phone)) {
    die('{"error":"Enter a valid phone number"}');
}
else if (strlen($password) < 6 || strlen($password) > 50) {
    die('{"error":"Password length must be between 6 and 50"}');
}
else if (!validPassword($password)) {
    die('{"error":"Password can only contain: a-z 0-9 ~@#%_+*?-. Min: 6 chars."}');
}
else if ($role < 1) {
    die('{"error":"Role should be numeric"}');
}

require "../../oc-includes/server.php";

$username="vf_" . $username;

$username = mysqli_real_escape_string($conn, $username);

$email    = mysqli_real_escape_string($conn, $email);
$fullname = mysqli_real_escape_string($conn, $fullname);

$phone    = mysqli_real_escape_string($conn, $phone);

$password = password_hash($password, PASSWORD_DEFAULT);

$table    = _TABLE_ADMINS_;
$table2   = _TABLE_USERS_;

function checkUserEmailExist($conn, $table, $username, $email) {

    if (!$query    = $conn->query("SELECT username, email FROM $table WHERE  ( username='$username' OR email='$email') LIMIT 1")) {
        return 0;
    }

    if (mysqli_num_rows($query) < 1) {
        return 1;
    }

    $row = mysqli_fetch_assoc($query);

    if ($username == $row['username']) {
        return 2;
    }
    else if ($email == $row['email']) {
        return 3;
    }

}

$check  = checkUserEmailExist($conn, $table, $username, $email);
$check2 = checkUserEmailExist($conn, $table2, $username, $email);

if ($check == 2 || $check2 == 2) {
    $conn->close();
    die('{"error":"Username is already registered."}');
}
else if ($check == 3 || $check2 == 3) {

    $conn->close();
    die('{"error":"Email address is already registered."}');

}
else if ($check == 0 || $check2 == 0) {

    $conn->close();

    die('{"error":"Temporarily unavailable."}');

}

$reg_on = date('Y-m-d H:i:s');

$sql    = "INSERT INTO $table (username, email, fullname, phone, password, role, added_on) VALUES ('$username','$email','$fullname','$phone','$password','$role','$reg_on')";

if ($conn->query($sql) ) {

    if ($conn->affected_rows > 0) {

        $conn->query("INSERT INTO $table2(username, email, fullname, phone, password, role, user_status, added_on) VALUES ('$username','$email','$fullname','$phone','$password','1','1' , NOW() )");

        makeUserDir($username);
        $conn->close();

        die('{"status":"success","result":"Added successfully."}');

    }
}

$conn->close();

die('{"error":"Unable to add an admin. Try again."}');
