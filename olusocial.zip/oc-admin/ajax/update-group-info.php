<?php
/**
* Class and Function List:
* Function list:
* Classes list:
*/
if (!isset($_SESSION))
    {
    session_start();
    }

header('Content-type:application/json;charset=utf-8');

require ('../../oc-includes/bootstrap.php');
adminLoggedIn(false, 'die', 'json');

if (!adminCanAddUser())
    {
    die('{"error":"Permission denied"}');
    }

if (empty($_POST['group_pin']) || empty($_POST['group_admins']) || empty($_POST['group_title']) || empty($_POST['group_info']))
    {
    die('{"error":"Parameters missing."}');
    }

$gpin    = test_input($_POST['group_pin']);

$gadmins = test_input(str_replace(' ', '', $_POST['group_admins']));

$gadmins = trim(preg_replace("/,+/", ",", $gadmins) , ",");

if (!preg_match("/^[a-z0-9,_]{4,250}$/i", $gadmins))
    {

    die('{"error":"Admins has some unwanted characters or length."}');

    }

$gadmins = $gadmins . ',';

$gtitle  = test_input($_POST['group_title']);

$ginfo   = test_input($_POST['group_info']);

if (strlen($ginfo) > 600)
    {

    die('{"error":"Description too long. Max: 500 characters."}');

    }

require "../../oc-includes/server.php";
require "../../oc-ajax/group/group-functions.php";

$table = _TABLE_GROUPS_;

$stmt  = $conn->prepare("UPDATE {$table} SET group_title=?, group_info=?, group_admins=? WHERE group_pin=? LIMIT 1");

if ($stmt && $stmt->bind_param('ssss', $gtitle, $ginfo, $gadmins, $gpin) && $stmt->execute())
    {

    $stmt->close();
    $conn->close();
    $data = array();
    $data["status"]      = "success";
    $data["result"]      = "Successfully updated.";
    die(json_encode($data));
    }

$conn->close();
die('{"error":"No changes made."}');

