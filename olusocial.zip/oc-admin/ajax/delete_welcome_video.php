<?php
/**
* Class and Function List:
* Function list:
* Classes list:
*/
if (!isset($_SESSION))
  {
    session_start();
  }

require ('../../oc-includes/bootstrap.php');
adminLoggedIn(false, 'die');

if (!adminCanChangeSettings()){

    die('__PERMISSION_DENIED__');
}


$wvideo = _CHAT_FILES_DIR_ . '/welcome/0123456789.mp4';

if (!is_file( $wvideo ) )
  {
    die('__SUCCESS__');
  }
else if (unlink($wvideo))
  {
    die('__SUCCESS__');
  }
else{
   die('__FAILED__');
}
