<?php
/**
* Class and Function List:
* Function list:
* Classes list:
*/
if (!isset($_SESSION))
  {
    session_start();
  }
header('Content-type:application/json;charset=utf-8');

if (empty($_POST['username']))
  {
    die('{"error":"Empty parameter."}');
  }

require ('../../oc-includes/bootstrap.php');
adminLoggedIn(false, 'die', 'json');

if (!adminCanDeleteUser())
  {
    die('{"error":"Permission denied."}');
  }

$username = strtolower($_POST['username']);

if ($username == 'gp_pofficials')
  {

    die('{"error":"This group is super."}');

  }

require "../../oc-includes/server.php";
require '../../oc-ajax/group/group-functions.php';

$table = _TABLE_GROUPS_;

if ($stmt  = $conn->prepare("DELETE FROM $table WHERE group_pin=? LIMIT 1"))
  {
    $stmt->bind_param('s', $username);

    if ($stmt->execute())
      {

        $stmt->close();
        //$conn->close();
        $userDir = getGroupDir($username);

        $message = "remove-from-group|{$username}";
        $meta["hl"]         = "";

        if (!is_dir($userDir))
          {

            customGroupMessage($conn, $username, $message, $meta, "", "act");
            die('{"status":"success","result":"Deleted successfully."}');

          }
        else
          {

            deleteTree($userDir);

            customGroupMessage($conn, $username, $message, $meta, "", "act");
            die('{"status":"success","result":"Deleted successfully."}');
          }
      }
  }

die('{"error":"Failed to delete. Err02"}');
