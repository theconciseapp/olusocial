<?php
/**
* Class and Function List:
* Function list:
* Classes list:
*/
if (!isset($_SESSION))
    {
    session_start();
    }

require ('../../oc-includes/bootstrap.php');
adminLoggedIn(false, 'die', 'json');

if (!adminCanMessageUser())
    {
    die('{"error":"Permission denied."}');
    }

if (empty($_POST['username'])
//||empty($_POST['send_as'] )
 || empty($_POST['message']))
    {
    die('{"error":"One or more fields are empty."}');
    }

$admin_username = getAdminInfo('username');

$chat_to        = test_input($_POST['username']);

$send_as        = $admin_username."~";

if( !empty($_POST["send_as"] ) && validUsername($_POST['send_as'],true ) ){
 $send_as=test_input( strtolower( $_POST['send_as'] ) );

$userdir=getUserDir( $send_as );

if( strpos( $send_as, '_' ) === false && is_dir( $userdir) ){

  die('{"error":"Please use another &quot;send as&quot;"}');
 }

}


$msg            = htmlentities(trim($_POST['message']) , ENT_QUOTES);

if (strlen($msg) < 1)
    {

    die('{"error":"Cannot send empty message."}');

    }

$hl   = substr($msg, 0, 100);

$meta = array();
$meta["hl"]      = $hl;

if (startsWith($chat_to, 'gp_'))
    {
    //Group message
    require '../../oc-includes/server.php';
    require '../../oc-ajax/group/group-functions.php';

    if (customGroupMessage( $conn, $chat_to, $msg, $meta, "", $send_as . "~") === 1)
        {

        die('{"status":"success","result":"Sent successfully."}');
        }

    die('{"error":"Not sent."}');

    }
else
    {

    require_once ('../../oc-third-party/SleekDB/Store.php');

    if (inboxUser($chat_to, $msg, $meta, str_replace("~","",$send_as) ) )
        {
  die('{"status":"success","result":"Sent successfully."}');
        }
    else
        {
        die('{"error":"Not sent."}');
        }
    }
