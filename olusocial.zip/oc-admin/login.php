<?php if (!isset($_SESSION)) {
   session_start();
}

require('../oc-includes/bootstrap.php');
  $error=$username="";
if( $_SERVER["REQUEST_METHOD"] == "POST"){

if(empty( $_POST['username'] )||empty( $_POST['password'] ) ){
 $error="Invalid username or password.";
}
else{
 $username=test_input( strtolower($_POST['username']) );
 $password=$_POST['password'];
   
  if( !validUsername($username, true) && !filter_var($username, FILTER_VALIDATE_EMAIL)  ){
  $error='Invalid username or password.';
  }
else if( strlen($password)<6 ){
 $error='Invalid username or password.';
 }
else{

require "../oc-includes/server.php";

$username_=mysqli_real_escape_string($conn,$username);

$status='1';
 $table=_TABLE_ADMINS_;

$stmt= $conn->prepare("SELECT username, email, fullname, phone, role, password FROM $table WHERE ( username=? OR email=? ) LIMIT 1");

if(!$stmt||!$stmt->bind_param('ss',$username_,$username_) ||!$stmt->execute() ){

$conn->close();
  $error='Invalid username or password.';
 // if ( mysqli_num_rows( $query)<1) { 
 //$error='Invalid username or password.';
}
else{
  $res=$stmt->get_result();
  $stmt->close();
  $conn->close();

   $row=$res->fetch_assoc();
   $pwrd=$row['password'];

 if (!password_verify( $password, trim( $pwrd) ) ) {

  $error='Invalid username or password.';
}
else{
  adminLoggedIn(true);
 $_SESSION["ADMIN___USERNAME"]=strtolower($row['username'] );
$_SESSION["ADMIN___FULLNAME"]=strtolower($row['fullname'] );
$_SESSION["ADMIN___EMAIL"]=strtolower($row['email'] );
$_SESSION["ADMIN___PHONE"]=$row['phone'];
$_SESSION["ADMIN___ROLE"]=$row['role'];

 header("location:index.php");
exit;
    }
   }
  }
 }

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">


<link rel="stylesheet" href="assets/css/login.css?i=<?php echo randomString(3);?>">

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>  
 </head>
<body>

  <div class="container">
  
 <div class="form-container" style="margin-top: 80px;">

<div class="form-content" style="position: relative;">

 <div class="header" style="width: 100%;">
<div style="position: absolute; top: -35px; left: 0;  width: 100%; text-align: left;">
<img id="login-logo" src="<?php echo _SITE_URL_.'/oc-logo.png';?>" style="height: 50px; width: 50px; border: 0; border-radius: 100%;">
</div>
Login 
</div>

  <?php if( isset($_GET['fresh'] ) ){?>
<div class="form-text text-danger m-2">*This is a fresh install, make sure you change your admin password to a well secure password.</div>
<div class="m-2 mb-1 text-success" style="font-weight: bold;">
<div>Username: vf_superadmin</div>
<div>Password: 123456</div>
</div>

<?php }?>
<form action="<?php echo _ADMIN_URL_.'/login.php';?>" method="post">
 
<?php 
if(!empty( $error) ){
echo '<div class="text-danger mb-2"> <i class="fa fa-warning fa-lg"></i> 
'. $error.'</div>'; }?>

<div class="mb-2">
<label class="form-label"><i class="fa fa-user fa-lg"></i> Username or email</label> 	
	<input type="text" name="username" class="username form-control" value="<?php echo test_input($username);?>" placeholder="Username or email">	</div>
 	<div class="mb-2"> 
<label class="form-label">
<i class="fa fa-sign-in fa-lg"></i> Password</label>
<input type="password" class="password form-control" name="password" placeholder="Password">

</div>
	<div class="mb-2"> 	
	<button type="submit" class="submit-btn btn login-btn btn-sm btn-primary" name="login">Login</button>
</div>
<div class="mt-3">
<a href="forgot_password.php" class="link-secondary">Forgot password</a>
</div>
</form>
    
</div>
 </div>
  </div>




<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
.login-footer{
position: fixed;
bottom: 0;
left:0;
right:0;
}
</style>


 <div class="container-fluid login-footer" style="background: #ftf5f5; color: #2b2b2b; padding-bottom: 20px; padding-top: 10px; font-size: 12px;">


<button class="d-none btn btn-sm btn-warning s_br"><i class="fa fa-globe fa-lg"></i> Recommended browsers</button>

<div style="display: none; background: rgba(150,100,100,.5); border: 0; border-radius: 8px; padding: 10px;" class="browsers-supported">
For the best experience, we recommend using the latest version of <i class="fa fa-lg fa-chrome text-primary"> Chrome</i>, <i class="fa fa-lg fa-firefox text-primary"> Firefox</i>, <i class="fa fa-lg fa-opera text-primary"> Opera</i>, <i class="fa fa-lg fa-safari text-primary"> Safari</i>
on Desktop and mobile.
<br>
To check what browser version you are using, visit <a href="https://whatismybrowser.com" class="text-primary">What Is My Browser</a>

</div>

<br />
<br />

<div class="text-dark text-center">&copy; <?php echo date('Y'); echo ' ' . htmlspecialchars( $_SERVER['HTTP_HOST']);?>
</div>
</div>
<script>
$(function(){
$('body').on('click','.s_br',function(){
$('.browsers-supported').slideToggle();
  });

$('body').on('click','.dt-toggle',function(){
$(this).children('.dt').slideToggle();
});
});
</script>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>
</html>
