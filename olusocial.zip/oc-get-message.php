<?php header('Content-type:application/json;charset=utf-8');
 
if( empty( $_POST['username']) ){
 die('{"user_not_found":"User not found."}');

}

define('_NO_CONNECT_ERROR_EXIT_','True');

 require('oc-includes/bootstrap.php');

if( !verifyToken() ){
die('{"invalid_token":"Invalid token."}');
 }

$settings__=getSettings();

$req_speed=isset( $settings__["chat_request_speed"] )?$settings__["chat_request_speed"]:"10";

$max_gc=isset( $settings__["max_groups_check"])?$settings__["max_groups_check"]:"2";

 $aud=array();

if( empty( $_POST["gms_count"]) ){
 
   $aud=appUpgradeData();
}

$chat_status=isset( $settings__["enable_chat"]) ? $settings__["enable_chat"]:"YES";

require('oc-third-party/SleekDB/Store.php');

require('oc-includes/chat_functions.php');
require('oc-ajax/group/group-functions.php');
   
   updateLastSeen(); 
 die( json_encode( getMessage( $req_speed, $max_gc, $aud ) ) );
