<?php require '../oc-includes/bootstrap.php';

if( empty( $_POST['username'] ) ) {
 die('{"error":"52"}');
}

$chat_from=$_POST['username'];

if( !validUsername( $chat_from, true ) ){
  die('{"error":"52"}');
}

$settings__=getSettings();

$chat_status= isset( $settings__["enable_chat"])?$settings__["enable_chat"]:"YES";

$enable_vid_doc= isset( $settings__["enable_vid_doc"])?$settings__["enable_vid_doc"]:"YES";


if( $chat_status=='NO' ){
 die('{"error":"0"}'); //Chat disabled
}
else if( !verifyToken() ){
  die('{"error":"1"}'); //invalid token
 }

 require '../oc-includes/chat_functions.php';

  define('__ALLOW__','1');

if( empty( $_REQUEST['file_type'] ) ){
 die('{"error":"2"}'); //Unsupported file
}

$file_type=$_REQUEST['file_type'];

if( $file_type=='image'){
  include('upload-image.php');
}

else if($file_type=='video'){
 if( strpos( $chat_from, '_' ) === false  && $enable_vid_doc!='YES'){
   die('{"error":"54"}');
 }
  include('upload-video.php');
}

else if($file_type=='audio'){
  include('upload-audio.php');
}

else{
 if( strpos( $chat_from, '_' ) === false && $enable_vid_doc!='YES'){
   die('{"error":"54"}');
 }

 include('upload-documents.php');
}
