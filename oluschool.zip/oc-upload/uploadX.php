<?php /*

THIS IS AN EXAMPLE OF HOW CHAT FILES CAN BE UPLOADED TO ANOTHER SERVER FROM YOUR CURRENT SERVER. THIS WILL SAVE YOUR CURRENT SERVER BANDWIDTH AND STORAGE SPACE, SPEED.

SETUP YOUR SECOND SERVER TO RETURN SUCCESSFUL RESPONSE IN THIS FORMAT:

{"status":"success","file_size":"11429","file_folder":"images/2021/October/27","file_path":"http://localhost:8080/demo/oc-chat-files/images/2021/October/27/gp_ax3bu0yr-576764480396882.jpg"}

// Note:
//file_size- in bytes
// file_path- The full url path of the uploaded file in the second server

*/


$data = array(
'username'=>$_POST['username'],
'chat_to'=>$_POST['chat_to'],
'chat_id'=>$_POST['chat_id'],
'base64'=>$_POST['base64'],
'file_ext'=>$_POST['file_ext'],
'token'=>$_POST['token'],
'version'=>$_POST['version'],
'file_type'=>$_GET['file_type']
); 

$secondServerPath='http://localhost:8080/demo/oc-upload/uploader.php';

 $ch = curl_init();

curl_setopt($ch, CURLOPT_URL, $secondServerPath );
curl_setopt($ch, CURLOPT_POSTFIELDS, $data );
curl_setopt($ch, CURLOPT_TIMEOUT, 86400); // 1 Day Timeout
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60000);
curl_setopt($ch,CURLOPT_FAILONERROR,true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_REFERER, $_SERVER['HTTP_HOST']);

$response = curl_exec( $ch);

 if(curl_errno($ch) ) {
    $msg = '{"error":"00"}';
} else {
    $msg = $response;
}


//file_put_contents('test.php', $msg);

curl_close($ch);
 die( $msg);
