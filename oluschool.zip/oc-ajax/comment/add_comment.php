<?php header('Content-type:application/json;charset=utf-8');
 require('../../oc-includes/bootstrap.php');

 if( !verifyToken() ){
  die('{"error":"Invalid security token."}');
 }
else if( empty( $_POST['post_id'] ) 
||empty( $_POST['username'] ) 
||empty($_POST['group_pin'] ) 
||empty( $_POST['message'] ) 
|| empty( $_POST['version'] ) 
){ 
 die('{"error":"Missing parameters."}');
 }

$author=test_input( strtolower($_POST['username']) );

$post_id=test_input( $_POST['post_id'] );

$gpin=test_input( strtolower( $_POST['group_pin'] ) );

$message=htmlspecialchars( $_POST['message'], ENT_QUOTES & ~ENT_COMPAT, 'UTF-8');


$version=test_input($_POST['version']);

require('../../oc-includes/server.php');

require('comment-functions.php');
  
 $result=add_comment($conn, $gpin, $post_id, $author, $message, "", $version);

if($result ){
 $conn->close();
 die('{"status":"success","result":"' . $result.'"}');
}

$conn->close();

die('{"error":"Failed."}');
