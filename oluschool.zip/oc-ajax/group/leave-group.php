<?php header('Content-type:application/json;charset=utf-8');
 require('../../oc-includes/bootstrap.php');
 if( !verifyToken() ){
  die('{"error":"Token not valid."}');
 }
else if( empty($_POST['username'] ) 
|| empty($_POST['group_pin']) 
|| empty( $_POST['version'] ) ){ 
   die('{"error":"Missing parameters."}');
 }

$username=test_input(strtolower($_POST['username']) );

$gpin=test_input( strtolower($_POST['group_pin'] ) );

if( !validUsername( $gpin,true ) ){
 die('{"error":"Sorry, not allowed."}');
}

$app_version=test_input( $_POST['version'] );

$file=getGroupDir($username)."/groups.txt";

 if( $username==$gpin ){
 die('{"error":"You can\'t delete."}');
 }


require('../../oc-includes/server.php');
require('group-functions.php');

$group=is_group( $gpin);

$table=_TABLE_GROUPS_;
$table_messages=$table.'_messages';

$stmt= $conn->prepare("SELECT group_pin, group_admins, group_members, created_by, total_members FROM $table WHERE group_pin=? LIMIT 1");


if(!$stmt||!$stmt->bind_param('s',$gpin)||!$stmt->execute()){

$conn->close();

die('{"error":"Please try again."}');

}

 $res=$stmt->get_result();
 $stmt->close();

 if( $res->num_rows <1){
  $conn->close();

  die('{"status":"success","result":"Left group."}');

}

$row=$res->fetch_assoc();

 $cby= strtolower( $row["created_by"]);
 $total_members=(int)$row["total_members"];
 $members=$row["group_members"];
 $admins= $row["group_admins"];

$save_members=preg_replace("/\b{$username}\b,/u","", $members, 1, $replaced);

if( $group && $replaced<1 ){

 $conn->close();

 die('{"success":"success","result":"Left group."}');
 //Not a group member
}

if( $cby==$username){
 $save_admins=$admins;

 }else{

 $save_admins=preg_replace("/\b{$username}\b,/","", $admins);

 }

 if( $group ){
try{

 $stmt=  $conn->prepare("UPDATE $table SET group_members ='$save_members', group_admins = '$save_admins' , total_members=total_members-1 WHERE group_pin=? LIMIT 1");
 
 $stmt->bind_param('s',$gpin);
 $stmt->execute();
}catch(Exception $e){ 
//ignore error
 }

  }else{

try{

$stmt= $conn->prepare("UPDATE $table SET group_admins='$save_admins', total_members=total_members-1 WHERE group_pin=? LIMIT 1");

 $stmt->bind_param('s', $gpin);
 $stmt->execute();

 }catch(Exception $e){ 
//ignore error
 }


}

$gdir=getGroupDir( $gpin);

if( $stmt->affected_rows >0 ){

  $stmt->close();

 if( $group ){

$meta=array();

$msg='_'. str_replace( array('vf_','gp_'),'', ucfirst( $username) ) . ' left_';

$meta["hl"]=str_replace('_','',$msg);

 customGroupMessage( $conn, $gpin, $msg, $meta);

 }

 $conn->close();

die('{"status":"success","result":"Left group."}');

}

$conn->close();
die('{"error":"Failed to leave."}');
