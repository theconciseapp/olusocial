<?php header('Content-type:application/json;charset=utf-8');
require('../oc-includes/bootstrap.php');

if( !verifyToken() ){
  die('{"error":"Invalid token."}');
 }

 if( empty($_POST['username'] ) ||empty($_POST['friend_username']) || empty($_POST['version']) ){ 
   die('{"error":"Parameters missing."}' );
 }

$settings__=getSettings();

$enable_addcontact=isset($settings__["enable_add_contact"] )?$settings__["enable_add_contact"]:'YES';

if( $enable_addcontact!='YES' ){
  die('{"error":"Sorry, adding contact currently not allowed."}');

}

$userName=test_input( strtolower($_POST['username']) );
$friendUsername=test_input( strtolower($_POST['friend_username']) );

$app_version=test_input( strtolower($_POST['version']) );

 if( $userName==$friendUsername){
  die('{"error":"Sorry, you cannot add yourself."}');
 }
else if( $userName=='vf_private'){
die('{"error":"This is your private contact. No need to add."}');
}

 $group=false;

if( preg_match("/gp_/",$friendUsername) ){
 $group=true;
}

require "../oc-includes/server.php";

if( !$group){

$table=_TABLE_USERS_;

$stmt =$conn->prepare("SELECT username, email, fullname, phone FROM $table WHERE ( username=? OR email=? ) LIMIT 1");

if(!$stmt ||!$stmt->bind_param('ss', $friendUsername, $friendUsername) || !$stmt->execute() ){
  $conn->close();
 die('{"error":"Please try again."}');
}

$res=$stmt->get_result();

$stmt->close();
$conn->close();

if ( $res->num_rows<1 ) {
  die('{"error":"Contact not found."}');
}

$row=$res->fetch_assoc();

$fuser=$row['username'];
$email=$row['email'];
$fullname=$row['fullname'];
$phone=$row['phone'];

 $data=array("fuser"=>$fuser,"email"=>$email,"fullname"=>$fullname,"phone"=>$phone,"version"=>$app_version);

$dir=getUserDir($userName);
 
 if( is_dir( $dir ) ){

$contactsFile=$dir.'/contacts.txt';

  if( file_exists( $contactsFile) ){
 
//Check if this contact is already saved.

$contacts_data=file_get_contents( $contactsFile);

   if( preg_match('/"\\b'.$friendUsername.'\\b"/', $contacts_data ) ){

$data["status"]="success";
  die( json_encode($data) );

   }
}

if( file_put_contents($dir.'/contacts.txt', json_encode( $data ). "\n", FILE_APPEND) ){
   $data["status"]="success";
  die( json_encode( $data) );
  }
}
 die('{"error":"Failed to add contact."}');

}

die('{"error":"It\'s a group."}');
