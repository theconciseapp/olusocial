<?php header('Content-type:application/json;charset=utf-8');

if( empty( $_POST['version'] )
 || empty($_POST['data'] )
 || empty( $_POST['username'] ) ){

die('{"error":"Empty data.","invalid_groups":""}');

}

require('oc-includes/bootstrap.php');

 if( !verifyToken() ){
 die('{"invalid_token":"__INVALID_TOKEN__"}');

 }

$settings__=getSettings();

$chat_status=isset( $settings__["enable_chat"] ) ?$settings__["enable_chat"]:"YES";

if( $chat_status!='YES' ){
 
  die('{"chat_disabled":"Sending messages is temporarily not allowed."}');

}

define('_NO_CONNECT_ERROR_EXIT_','True');

require_once('oc-third-party/SleekDB/Store.php');

require('oc-ajax/group/group-functions.php');
 
require('oc-includes/chat_functions.php');


$version=test_input( $_POST['version'] );
 $chat_from=test_input( strtolower($_POST['username'] ) );


 $datas=  htmlspecialchars( trim( $_POST['data'] ), ENT_QUOTES & ~ENT_COMPAT, 'UTF-8');

$datas=explode("\n", $datas);

  $total=count( $datas ); //Total messages

if( $total<1 || $total>20) {

 die('{"error":"Message count less than 1 or too much."}');

}

 sendMessage( $datas, $chat_from, $version );
