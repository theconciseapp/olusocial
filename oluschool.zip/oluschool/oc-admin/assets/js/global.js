var lastTop;

function randomNumber(len,charSet) {
    charSet = charSet || '023456789';
    var randomString='';
    for (var i=0; i<len;i++) {
        var randomPoz=Math.floor(Math.random()*charSet.length);
        randomString+=charSet.substring(randomPoz,randomPoz+1);
    }
    return randomString;
}

function ucfirst(str) {
    return str.replace(/([a-z])/, function (match, value) {
        return value.toUpperCase();
    })
}


function validPassword(password){
  if(!password) return false;
  else if(password.match(/^[a-zA-Z0-9~@#%_+*?-]+$/) ) return true;
  else return false;
}

function validName(fullname){
 if(!fullname) return false;
else if(fullname.match(/^[a-zàáèöïÿŕëäśĺžźżçćčñńôêėřûîéìíòóùú]([.'-]?[a-z àáèöïÿŕëäśĺžźżçćčñńôêėřûîéìíòóùú]+)*$/i) )return true;
else return false;
}

function validUsername(username){
 if(!username) return false;
else if (username.match(/^([a-z]+)_?[a-z0-9]{3,29}$/i) ) return true;
else return false;
}

function displayData(data, options){

var sclass='sclass_' + randomNumber(10);
  var a=$.extend({
    'ddclass':'body',
    'scroll': false,
    'shadow':true,
    'header': true,
    'footer': true,
    'hheight': 40,
    'fheight': 40,
    'htitle': '', //header title
    'ftitle': '', //footer title
    'bmax_height': 50, //Content body max height
    'sc': sclass, //shadow class
    'zindex': 1,
    'id':'nothing',
    'sclose': true, //can close on shadow click
    'on_close': '',
    'sopacity':'0.5', //shadow opacity
  }, options);
  

 var container=$('<div class="clear-display-data" id="' + a.id + '" style="position: fixed; top:0; width: 100%; bottom:0; z-index: ' + (999999 + (+ a.zindex) ) + '; background: none;"></div>');

var shadow=$('<div class="display-data-shadow" style="position: absolute; width: 100%; height: 100%; background: #000; z-index: 1; opacity: ' + a.sopacity + '"></div>');
 
if( a.shadow){
 if(a.sclose){
 shadow.on('click',function(){
  closeDisplayData(a.id, a.on_close);
});
 }

container.append( shadow);
}

var contentBodyCont=$('<div style="position: absolute; z-index: 10; left: 50%; top: 50%; transform: translate(-50%, -50%); -webkit-transform: translate(-50%, -50%); width: 80%; max-width: 500px; background: #fff; border:0; border-radius: 3px; padding: 20px;"></div>');


var closeBtn=$('<i class="text-danger fa fa-lg fa-close" style="position: absolute; top: 5px; right: 2%;"></i>').click(function(){
  closeDisplayData(a.id,a.on_close);
});


var contentBody=$('<div style="overflow-y: auto; max-height: ' + a.bmax_height + 'vh;">' + data + '</div>');

var contentHeader=$('<div style="min-height: ' + a.hheight + 'px;">' + a.htitle + '</div>');

var contentFooter=$('<div style="min-height: ' + a.fheight + 'px;">' + a.ftitle + '</div>');

contentBodyCont.append(closeBtn)
    .append(contentBody);

 if( a.htitle){
 contentBodyCont.prepend(contentHeader);
}

 if( a.ftitle){
   contentBodyCont.append(contentFooter);
}
  container.append(contentBodyCont);
 $('body').prepend(container);

  if(!a.scroll) {
   disableScroll();
 }
}
  
function closeDisplayData(elem,callback){
 if(!elem){
    $('.clear-display-data').remove();
   }else{
   $('#' + elem).remove();
   if( callback){
  if(typeof callback==='string' ||callback instanceof String){ window[callback](); } 
      else { callback(); }
   }
}
 enableScroll();
 }



function disableScroll(){

var scrollPosition = [
  self.pageXOffset || document.documentElement.scrollLeft || document.body.scrollLeft,
  self.pageYOffset || document.documentElement.scrollTop  || document.body.scrollTop
];

var html = $('html'); // it would make more sense to apply this to body, but IE7 won't have that


if( html.css('overflow')=='hidden'){
   return;
}

html.data('scroll-position', scrollPosition);
html.data('previous-overflow', html.css('overflow') );
html.css('overflow', 'hidden');
window.scrollTo( scrollPosition[0], scrollPosition[1]);

}

function enableScroll(){
// un-lock scroll position
  if($('.clear-display-data').length) return;
var html = $('html');
var scrollPosition = html.data('scroll-position'); 
  if( !scrollPosition ) return;
html.css('overflow', html.data('previous-overflow'));
window.scrollTo( scrollPosition[0], scrollPosition[1]);
}


function stopScroll(elem,elem2){
  var v=0;
   if (elem2){
  if( elem2.search('.')!=-1 ) v=$(elem2).visibleHeight()-10;
    else v=+elem2;
 }

  elem=elem||'.main-container';
   lastTop =$(window).scrollTop();
  sessionStorage.setItem('lastTop',lastTop);
   $(elem).addClass('noscroll').css({top:-(lastTop-v)}); //lastTop-118
  }

function continueScroll(elem) {  
  elem=elem||'.main-container';                  
    $(elem).removeClass( 'noscroll' );

  var lastTo=+sessionStorage.getItem('lastTop')||lastTop;
      
      $(window).scrollTop( lastTo );       
 }          


var toastTimer;
function toast(data,c,callback){
  if(toastTimer) clearTimeout(toastTimer);
  var config=$.extend({
  pos:80,
  custom_class:'',
  hide: 3000,
  type: 'danger',
  align: 'center',
  font_size: '90%',
  width: '80%',
  text_color:'#ffffff',
  background:'',
  manual_close: false,
  z_index: 99999999
},c);
   
   var bg={
           danger: '#d9534f',
           success: 'seagreen',
           info: '#0065A3',
           warning:'orange'
          };
   if(config.background)  bg={
           danger: config.background,
           success: config.background,
           info: config.background,
           warning: config.background
          };
   /* info: background:#4b6cb7*/

 if(toastTimer) clearTimeout(toastTimer);
   $('.android_toast').hide();
    var mc="";
  if(config.manual_close){
   mc='<img onclick="' + (callback?'callback();':'') + 'clearTimeout(toastTimer);$(\'.android_toast\').fadeOut();" src="' + _SITE_URL_ + '/images/bg/close.png" style="width: 17px; position: absolute; top:-5px; left:-5px;">'; 
  }
    
  var div='<div class="dont_print DONT_PRINT android_toast ' + config.custom_class + '" style="background: ' + bg[config.type] +
       '; position: fixed; z-index: ' + config.z_index + ';left: 50%; opacity:.95; color:#fff; width: 50%;border:0;font-size:90%; border-radius: 7px;padding: 8px 20px; max-width: 550px; top: ' + config.pos + 
       '%; width: ' + config.width + '; -webkit-transform: translate(-50%,-' + config.pos + '%); transform:translate(-50%,-' + config.pos + '%); text-align: ' + config.align + 
        '; font-size: ' + config.font_size + '; color: ' + config.text_color + '">' + mc + data + '</div>';
  
  $('body').append(div);
 toastTimer=setTimeout(function(){
    $('.android_toast').fadeOut();
   clearTimeout(toastTimer);
   if(callback) callback();
  },config.hide);
}


function displayDatar(data, options){
  var osclass='dd_' + randomString(10);
  var a=$.extend({
    'ddclass':'body',
    'gs':true,
    'os':true,
    'osc': osclass,
    'oszindex': 150,
    'data_class':'.nothing',
    'osclose': false,
    'on_close': '',
    'type':0,
    'osopacity':'0.5',
    'title':''
  }, options);
  if($(a.data_class).length) return;
  
  //osclose if set to true, then user can also close div on overshadow click
  var osclose='';
   if(a.osclose) osclose=' onclick="closeDisplayData(\'' + a.data_class + '\',\'' + a.on_close + '\');"';
     
var mt_=$('.main_table');
var im_=$('.isMobile');
var is_mobile_=true;
 if( mt_.length && im_.is(':visible') ){
is_mobile_=false;
}

  var div='';
var myDiv = document.createElement("div");
 
//Set its unique ID.
var uid = 'div_id_' + randomString(6);
myDiv.id=uid;
  if(a.type)
  {
     div='<div class="center_div ' + a.data_class.replace('.','') + '" style="background:#fff;">';
     div+='<div class="center_header">' + (a.title?a.title:'') + '</div>';
     div+='<div class="center_text_div" style="width:100%; padding: 10px 15px;">';
     div+=data;
    div+='</div></div>';
 $(a.ddclass).prepend(div);
 }
  else {
$(a.ddclass).prepend(data);
}
  

  $(a.data_class).css('z-index',(a.oszindex+30) ).attr('data-overshadow','.' + a.osc).after('<div class="DONT_PRINT dont_print ' + a.osc + '" style="background: #000; position: fixed; z-index: ' + a.oszindex + '; top:0; left:0; right:0;  bottom:0; opacity: ' + a.osopacity + '; display:none;"' + osclose + '></div>');


  if(is_mobile_ && a.gs){
$('body').addClass('stop-scrolling');
$('.' + a.osc).bind('touchmove', function(e){
e.preventDefault();
 })

}

   if(a.os) $('.' + a.osc).show();

}

 function closeDisplayDatar(elem,callback){
var mt=$('.main_table');
var im=$('.isMobile');
var is_mobile_=true;

 if( mt.length && im.is(':visible') ){
is_mobile_=false;
   mt.css({'overflow-y':'auto'});
}
  var os=$(elem).data('overshadow');
   $(elem).remove();
  $(os).remove();

if(is_mobile_) {
  $('body').removeClass('stop-scrolling');
 }

   if(callback){
  if(typeof callback==='string' ||callback instanceof String){ window[callback](); } 
      else { callback(); }
   }
 }


function fallbackCopyTextToClipboard(text) {
  var textArea = document.createElement("textarea");
  textArea.value = text;
  
  // Avoid scrolling to bottom
  textArea.style.top = "0";
  textArea.style.left = "0";
  textArea.style.position = "fixed";

  document.body.appendChild(textArea);
  textArea.focus();
  textArea.select();

  try {
    var successful = document.execCommand('copy');
    var msg = successful ? 'successful' : 'unsuccessful';
    console.log('Fallback: Copying text command was ' + msg);
  } catch (err) {
    console.error('Fallback: Oops, unable to copy', err);
  }

  document.body.removeChild(textArea);
}

function copyToClipboard(text) {
  if (!navigator.clipboard) {
    fallbackCopyTextToClipboard(text);
    return;
  }
  navigator.clipboard.writeText(text).then(function() {
    console.log('Async: Copying to clipboard was successful!');
  }, function(err) {
    console.error('Async: Could not copy text: ', err);
  });
}





var escape = function (str) {
  return str
    .replace(/[\\]/g, '\\\\')
    .replace(/[\"]/g, '\\\"')
    .replace(/[\/]/g, '\\/')
    .replace(/[\b]/g, '\\b')
    .replace(/[\f]/g, '\\f')
    .replace(/[\n]/g, '\\n')
    .replace(/[\r]/g, '\\r')
    .replace(/[\t]/g, '\\t');
};
