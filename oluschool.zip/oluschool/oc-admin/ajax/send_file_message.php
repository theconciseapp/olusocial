<?php
/**
* Class and Function List:
* Function list:
* - uploadImage()
* Classes list:
*/
if (!isset($_SESSION))
    {
    session_start();
    }
header('Content-type:application/json;charset=utf-8');

require '../../oc-includes/bootstrap.php';

adminLoggedIn(false, 'die', 'json');

if (!adminCanMessageUser())
    {
    die('{"error":"Permission denied"}');
    }

/*
 ini_set('memory_limit','512M');
 ini_set('post_max_size','256M');
 ini_set('upload_max_filesize','256M');
 ini_set('max_execution_time', 300);
 ini_set('max_input_time', 300);
*/

$name = 'file'; //File <input type="file" name="file">
if (empty($_POST['chat_to'])
//|| empty($_POST['send_as'] )
 || empty($_FILES[$name]['type']))
    {
    die('{"error":"Some parameters are missing."}');
    }

/*
else if(!validUsername( $_POST['send_as'] ,true) ){
  die('{"error":"\"Send as\" not acceptable. Only alphanumerics supported."}');
 }
*/

else if (0 < $_FILES[$name]['error'])
    {
    die('{"error":"' . $_FILES[$name]['error'] . '"}');
    }

$file_size = $_FILES[$name]['size'];

if (($file_size / 1024) > 100000)
    {
    die('{"error":"File too large"}');
    }

$tmpFile          = $_FILES[$name]['tmp_name'];
$upload_file_name = test_input($_FILES[$name]["name"]);

$expl             = explode(".", strtolower($upload_file_name));

$name_ext         = end($expl);

$file_type        = finfo_file(finfo_open(FILEINFO_MIME_TYPE) , $tmpFile);

require '../../oc-includes/chat_functions.php';

$admin_username = getAdminInfo('username');

$send_as        = $admin_username;

//test_input( $_POST['send_as'] );
$group          = "";
if (!empty($_POST['is_group']))
    {
    $group          = "YES";
    }

$folder         = $ftype          = $ext            = $file_highlight = $preview_text   = "";

if (in_array($file_type, allowedImages()))
    {
    $ftype          = 'image';
    $folder         = "images";
    $ext            = 'jpg';
    $file_highlight = $upload_file_name;
    $preview_text   = 'Image File';
    }
else if (in_array($file_type, allowedVideos()) && $name_ext == 'mp4')
    {
    $ftype          = 'video';
    $folder         = "videos";
    $ext            = 'mp4';
    $file_highlight = $upload_file_name;
    $preview_text   = 'Video File';
    }
else if (in_array($file_type, allowedAudios()) && ($name_ext == 'mp3' || $name_ext == 'mp4'))
    {
    $ftype          = 'audio';
    $folder         = "audios";
    $ext            = 'mp3';

    $file_highlight = $upload_file_name;
    $preview_text   = 'Audio File';
    }

else if (!in_array($file_type, bannedDocuments()))
    {
    $ftype          = 'document';
    $folder         = "documents";
    $expl           = explode(".", $upload_file_name);
    $ext            = end($expl);

    $file_highlight = $upload_file_name;
    $preview_text   = 'Document File';
    }
else
    {
    die('{"error":"File not supported."}');
    }

if ($name_ext == 'htaccess')
    {
    die('{"error":"File not supported."}');

    }

$folder    = $folder . "/" . _CHAT_FILES_STRUCTURE_;

function uploadImage($name, $destination, $ftype     = "", $dir, $filename)
    {

    if ($ftype == 'image')
        {

        if (resizeImage($_FILES[$name]['tmp_name'], $destination, '500'))
            {

            $thumbDir  = $dir . '/thumbnails';

            if (make_dir($thumbDir))
                {
                $thumbpath = $thumbDir . '/' . $filename;
                createThumbnail($destination, $thumbpath, 10);
                }

            return '__SUCCESS__';

            }
        }
    else
        {
        if (move_uploaded_file($_FILES[$name]['tmp_name'], $destination))
            {
            return '__SUCCESS__';
            }

        }
    return '__ERROR__';
    }

$chat_id  = randomNumbers(15);

$chat_to  = test_input(strtolower($_POST['chat_to']));

$filename = $chat_to . '-' . $chat_id . '.' . $ext;

$dir      = _CHAT_FILES_DIR_ . "/{$folder}";

if (!make_dir($dir))
    {
    die('{"error":"Could not create directory."}');
    }

$file    = $dir . '/' . $filename;

$result  = uploadImage('file', $file, $ftype, $dir, $filename);

$sfpath  = _CHAT_FILES_PATH_ . "/{$folder}/{$filename}";

if (preg_match("/__SUCCESS__/", $result))
    {

    $meta    = array();
    $meta["hl"]         = $file_highlight;
    $meta["file"]         = $ftype;
    $meta["pt"]         = $preview_text;
    $meta["lfpath"]         = "";
    $meta["sfpath"]         = $sfpath;
    $meta["size"]         = $file_size;
    $meta["fx"]         = $ext;
    $meta["fol"]         = $folder;

    $message = "[file=::{$filename}::]";

    if (startsWith($chat_to, 'gp_'))
        {
        //Group message
        require '../../oc-includes/server.php';
        require '../../oc-ajax/group/group-functions.php';

        if (customGroupMessage($conn, $chat_to, $message, $meta, "", $send_as . "~") === 1)
            {
            die('{"status":"success","result":"Sent successfully."}');
            }

        }
    else
        {
        require_once ('../../SleekDB/Store.php');

        if (inboxUser($chat_to, $message, $meta, $send_as, $group))
            {

            die('{"status":"success","result":"Sent successfully."}');
            }

        }
    }

die('{"error":"Failed."}');
