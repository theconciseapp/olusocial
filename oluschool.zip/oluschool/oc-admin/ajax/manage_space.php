<?php
/**
* Class and Function List:
* Function list:
* - listFolderFiles()
* Classes list:
*/
if (!isset($_SESSION))
  {
    session_start();
  }

require ('../../oc-includes/bootstrap.php');
adminLoggedIn(false, 'die');

//clearstatcache();
function listFolderFiles($dir, $ml = 0)
  {
    if (empty($dir)) return "";
    $ml = $ml + 20;

    if (!is_dir($dir)) return "";

    $ffs = @scandir($dir);
    unset($ffs[array_search('.', $ffs, true) ]);
    unset($ffs[array_search('..', $ffs, true) ]);

    // prevent empty ordered elements
    if (count($ffs) < 1) return;

    $result  = "";
    $level   = str_replace(_CHAT_FILES_DIR_ . '/', '', $dir);

    foreach ($ffs as $ff)
      {

        if (substr($ff, 0, 1) === ".")
          {
          }
        else
          {

            $path    = str_replace(_CHAT_FILES_DIR_, '', $dir) . '/' . $ff;

            $load_to = preg_replace("/[^a-z0-9]+/i", "", ($level . $ff));

            if (is_dir($dir . '/' . $ff))
              {

                $result .= '<button class="load-dir btn btn-sm btn-warning mb-2 ml-2 del-' . $load_to . '" style="margin-left: ' . $ml . 'px;" data-margin-left="' . $ml . '" data-level="' . $level . '/' . $ff . '" data-load-to="' . $load_to . '">' . $ff . '</button> <span class="delete-fd fa fa-lg fa-trash text-danger del-' . $load_to . '" data-path="' . $path . '" data-name="' . $ff . '" data-type="folder" data-class="del-' . $load_to . '"></span><div class="load-to-' . $load_to . ' del-' . $load_to . '"></div>';

              }
            else
              {

                $result .= '<div style="margin-left: ' . $ml . 'px;" data-margin-left="' . $ml . '" class="del-' . $load_to . ' mb-2"> <a href="' . _CHAT_FILES_PATH_ . '/' . $level . '/' . $ff . '" class="link-success" target="_blank">' . ucfirst($ff) . '</a> <span class="delete-fd fa fa-trash fa-lg text-danger" data-path="' . $path . '" data-name="' . $ff . '" data-type="file" data-class="del-' . $load_to . '"></span></div>';

              }
          }
      }
    return '<div class="ml-3">' . $result . '</div>';

  }

if (!empty($_POST['load']))
  {

    $level = test_input($_POST['level']);
    $ml    = (!empty($_POST['margin_left']) ? (int)$_POST['margin_left'] : 0);

    die(listFolderFiles(_CHAT_FILES_DIR_ . "/$level", $ml));

  }
else if (!empty($_POST['delete']) && !empty($_POST['path']))
  {

    if (!adminCanManageSpace())
      {
        die('__PERMISSION_DENIED__');
      }

    $path = test_input($_POST['path']);
    $path = _CHAT_FILES_DIR_ . $path;

    if (is_file($path))
      {
        if (unlink($path))
          {
            die('__SUCCESS__');
          }
        else
          {
            die('__FAILED__');
          }
      }
    else if (is_dir($path))
      {
        if (deleteTree($path))
          {
            die('__SUCCESS__');
          }
        else
          {
            die('__FAILED__');
          }
      }

  }
else if (!empty($_POST['delete_db_messages']) && !empty($_POST['age']) && !empty($_POST["limit"]))
  {


if (!adminCanManageSpace())
      {
        die('__PERMISSION_DENIED__');
      }

    $age   = (int)$_POST["age"];
    $limit = (int)$_POST["limit"];

    require '../../oc-includes/server.php';
    $table    = _TABLE_GROUPS_ . '_messages';

    $msc      = microtime(true);

    if ($conn->query("DELETE FROM $table WHERE date_time < ( NOW() - INTERVAL {$age} DAY ) ORDER BY id DESC LIMIT $limit"))
      {
        $affected = $conn->affected_rows;
        $conn->close();

        $msc         = microtime(true) - $msc;
        $time_taken1 = round($msc, 3) . ' in seconds';
        $time_taken2 = (round($msc, 3) * 1000) . ' in milliseconds';

        die('<div class="alert alert-success mt-2">SUCCESS <i class="fa fa-check fa-lg"></i><br> Total affected: ' . $affected . '<br>Time taken(in s): ' . $time_taken1 . '<!--<br>Time taken(in ms): ' . $time_taken2 . '--></div>');
      }
    else
      {
        die('__FAILED__');
      }
  }

else if (!empty($_POST['delete_comments']) && !empty($_POST['age']) && !empty($_POST["limit"]))
  {

if (!adminCanManageSpace())
      {
        die('__PERMISSION_DENIED__');
      }

    $age   = (int)$_POST["age"];
    $limit = (int)$_POST["limit"];

    require '../../oc-includes/server.php';
    $table    = _TABLE_COMMENTS_;

    $msc      = microtime(true);

    if ($conn->query("DELETE FROM $table WHERE date_time < ( NOW() - INTERVAL {$age} DAY ) ORDER BY id DESC LIMIT $limit"))
      {
        $affected = $conn->affected_rows;
        $conn->close();

        $msc         = microtime(true) - $msc;
        $time_taken1 = round($msc, 3) . ' in seconds';
        $time_taken2 = (round($msc, 3) * 1000) . ' in milliseconds';

        die('<div class="alert alert-success mt-2">SUCCESS <i class="fa fa-check fa-lg"></i><br> Total affected: ' . $affected . '<br>Time taken(in s): ' . $time_taken1 . '<!--<br>Time taken(in ms): ' . $time_taken2 . '--></div>');
      }
    else
      {
        die('__FAILED__');
      }
  }

die('PARAMETERS NOT FOUND.');
