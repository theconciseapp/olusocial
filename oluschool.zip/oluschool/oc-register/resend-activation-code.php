<?php header('Content-type:application/json;charset=utf-8');

require('../oc-includes/bootstrap.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


if( empty($_POST['email'] ) ){
 die('{"error":"Invalid verification code."}');
}

 $email=$_POST['email'];

require "../oc-includes/server.php";

 $table=_TABLE_USERS_;

 $stmt=$conn->prepare("SELECT user_status FROM $table WHERE email=? LIMIT 1");

if(!$stmt ||!$stmt->bind_param('s',$email) ||!$stmt->execute()){
  $conn->close();
  die('{"error":"We could not verify at the moment."}');
}

 $res=$stmt->get_result();

if( $res->num_rows<1 ){
  $stmt->close();
  $conn->close();
  die('{"error":"Sorry, email not found."}');
}
  
 $row = $res->fetch_assoc();
  
  $userstatus=$row['user_status'];
  
if( $userstatus!="0"){
  $stmt->close();
  $conn->close();
die('{"error":"This account has already been activated."}');
}

if($token=createToken($conn, $email, 15 ) ){

 sendEmailVerificationCode( $email,$token);

}
 $stmt->close();
 $conn->close();
 die('{"status":"success","result":"Kindly check your email address inbox or spam."}');
