<?php
/**
* Class and Function List:
* Function list:
* - sendMessage()
* - layout_()
* - getMessage()
* - friendTyping()
* - markAsRead()
* - lastSeen()
* - updateLastSeen()
* - saveBase64Image()
* - resizeImagexxx()
* - resizeImage()
* - createThumbnail()
* - imageToBase64()
* Classes list:
*/
function sendMessage($msg_datas, $chat_from, $version     = "")
    {

    $server__    = '__FALSE__';

    $chat_time   = time();

    $success     = $message     = $local_id    = $chat_to     = $inv_groups  = $lock_status = "";

    foreach ($msg_datas AS $messageData)
        {

        $data        = stripslashes($messageData);
        $data        = json_decode($data);

        if ($data)
            {

            $chat_id     = $data->cid;
            $chat_to     = $data->ct;

            if (startsWith($chat_to, 'gp_'))
                {
                //Request a group chats
                if ($server__ == '__FALSE__')
                    {
                    //Connect to Database once
                    $server__    = require "oc-includes/server.php";

                    }

                if ($server__ == "success")
                    {

                    $gresult     = sendGroupMessage($conn, $messageData, $chat_id, $chat_to, $chat_from);

                    $success .= $gresult["result"];
                    $inv_groups .= $gresult["invalid_groups"];
                    $lock_status .= $gresult["lock_status"];
                    usleep(10000);
                    }
                }
            else
                {

                if (!empty($chat_to) && validChatId($chat_id))
                    {

                    $fdir       = getUserDir($chat_to); //recipient message directory
                    $bfile      = $fdir . "/secure__.php";

                    if (file_exists($bfile))
                        {

                        $flat_table = "messages";

                        $msgStore   = new \SleekDB\Store($flat_table, $fdir, ["timeout" => false, "auto_cache" => false]);

                        if ($msgStore->insert(['chat_id' => $chat_id, 'message' => $messageData, 'chat_from' => $chat_from, 'version' => $version, 'admin' => 0]))
                            {
                            $success .= "{$chat_id}|{$chat_to} ";
                            }
                        }
                    else
                        {
                        //Fake sent message if friend dir does not exist
                        $success .= "{$chat_id}|{$chat_to} ";
                        }
                    }
                }
            }
        }

    if (!empty($success))
        {
        die(json_encode(["status" => "success", "result" => trim($success) , "invalid_groups" => $inv_groups, "lock_status" => $lock_status]));
        }
    else
        {

        die('{"error":"Sending failed.","invalid_groups":"' . $inv_groups . '"}');
        }

    }

function layout_($udir, $chat_to)
    {
    $data = "";

    if (!is_dir($udir . "/messages") )
        {
        return "";
        }

    $flat_table = "messages";

    $msgStore   = new \SleekDB\Store($flat_table, $udir, ["timeout"            => false]);

    $datas_     = $msgStore->findAll(null, 50);

    if (!$datas_) return "";

    foreach ($datas_ AS $row)
        {
        $id        = $row["_id"];
        $result    = $row["message"];
        $chatid    = $row["chat_id"];
        $chat_from = $row["chat_from"];
        // $version=$row["version"];
        $admin_    = $row["admin"];
        $admin     = false;

        if ($admin_ == '1')
            {
            $admin     = true;
            }
        //mark delivered...
        $fdir      = getUserDir($chat_from);

        $file      = $fdir . "/delivered.txt";

        if ($admin)
            {
            //Admin messages does not require delivery report
            $data .= $result . "\n";
            $msgStore->deleteById($id);

            }
        else if (file_put_contents($file, $chat_to . "-" . $chatid . " ", FILE_APPEND))
            {
            $data .= $result . "\n";
            $msgStore->deleteById($id);
            }
        }
    return trim($data);
    }

function getMessage($req_speed           = "10", $max_gc              = "2", $app_upgrade_data    = null)
    {
    // sleep(6);
    $message_read_report = $friends_typing      = $delivery_report     = "";

    $chat_to             = test_input(strtolower($_POST['username']));

    $udir                = getUserDir($chat_to);

    $file                = $udir . "/delivered.txt";
    $file2               = $udir . "/message_read.txt";

    if (file_exists($file))
        {
        $delivery_report     = file_get_contents($file);
        unlink($file);
        }

    if (file_exists($file2))
        {

        $message_read_report = file_get_contents($file2);

        unlink($file2);
        }

    try
        {

        $getMessage = layout_($udir, $chat_to);

        }
    catch(Exception $e)
        {

        logIt($e->getMessage());

        }

    usleep(30000);
    //Fetch groups messages
    $group = groupMessage($chat_to);

    $getMessage .= $group["gmessage"];

    $last_gmsg_times = $group["last_gmsg_times"];

    $rgroup          = $group["invalid_groups"];
    $glock_status    = $group["glock_status"]; //Group lock status
    $mt              = $group["members_typing"];

    //MARK AS READ AND FETCH LAST SEEN OF FRIEND
    $lastSeen        = lastSeen($chat_to);

    //Check who is typing message
    //$friends_typing=trim( $mt . "\n". friendTyping( $udir ) );
    $mem             = "";
    // $mem= formatBytes( memory_get_peak_usage() );
    

    return (object)["messages"                => $getMessage, "last_group_msg_times"                => $last_gmsg_times, "invalid_groups"                => $rgroup, "glock_status"                => $glock_status, "delivery_report"                => $delivery_report, "message_read_report"                => $message_read_report, "friend_last_seen"                => $lastSeen, "typing"                => $friends_typing, "status"                => "success", "mini_settings"                => array(
        "request_interval"                => $req_speed,
        "max_groups_check"                => $max_gc
    ) , "current_time"                => time() , "app_upgrade_data"                => $app_upgrade_data, "memory_consumption"                => $mem];
    }

//Friends typing...
function friendTyping($udir)
    {

    $typ_file       = $udir . "/friends_typing.txt";

    $friends_typing = "";

    if (file_exists($typ_file))
        {

        $friends_typing = trim(file_get_contents($typ_file));

        //unlink( $typ_file );
        
        }
    return $friends_typing;
    }

//MARK FRIEND MESSAGE AS READ
function markAsRead()
    {
    if (empty($_POST['mark_as_read'])) return "";
    $mar      = test_input($_POST['mark_as_read']);

    $data_    = explode(' ', $mar);
    $feedback = "";

    foreach ($data_ as $data)
        {
        $friend   = strtok($data, '-');

        if (!startsWith($friend, 'gp_'))
            {
            $ids      = str_replace($friend . '-', '', $data);

            $fdir     = getUserDir($friend);

            $file     = $fdir . "/message_read.txt";

            if (is_dir($fdir))
                {
                if (file_put_contents($file, $ids . ' ', FILE_APPEND))
                    {

                    $feedback .= $data . " ";

                    }
                }
            else
                {
                //user directory not found, so fake it.
                $feedback .= $data . " ";
                }
            }
        }
    //feedback is necessary to indicate
    //that friend has been successfully been notified.
    return trim($feedback);
    }

//RETURN LAST SEEN OF FRIEND
function lastSeen($chat_to)
    {

    $data           = $last_seen      = "";
    $marked_as_read = markAsRead();

    if (!empty($_POST['check_lastseen']))
        {

        $friend         = test_input($_POST['check_lastseen']);

        $lsfile         = getUserDir($friend) . "/lastseen.txt";

        if (file_exists($lsfile))
            {

            $ls             = file_get_contents($lsfile);

            $last_seen      = $friend . '|' . trim($ls) . '|' . time();
            }

        }
    return $last_seen . '#' . $marked_as_read;
    }

//UPDATE USER LASTSEEN (i.e. update user online status) & IS TYPING TO
function updateLastSeen()
    {

    if (!empty($_POST['app_minimized']))
        {

        return "";
        }

    $chat_to = strtolower(test_input($_POST['username']));

    $dir     = getUserDir($chat_to);

    $lsfile  = "{$dir}/lastseen.txt";

    if (!empty($_POST['update_lastseen']) && is_dir($dir))
        {

        file_put_contents($lsfile, time());

        }

    /*
    
    if( empty($_POST['typing_to'] ) ){
    return;
    
    }
    
    $typing_to=strtolower( test_input($_POST['typing_to'] ) );
    
    if( $typing_to=='vf_private'){
    return;
    }
    
    $mtyping="";
    $tdir=getUserDir( $typing_to);
    
    if( startsWith( $typing_to,'gp_') ){
    
    $mtyping="|".$chat_to;
    $chat_to=$typing_to;
    $tdir=getGroupDir( $typing_to);
    }
    
    
    if(  !is_dir( $tdir) ) return;
    $file=$tdir . "/friends_typing.txt";
    
    $data=$chat_to . '|' . time() .$mtyping."\n";
    
    //Save only the latest typer
    file_put_contents( $file , $data, LOCK_EX);
    */

    }

function saveBase64Image($base64, $destination, $new_width     = 300)
    {
    $im            = imagecreatefromstring($base64);
    $source_width  = imagesx($im);
    $source_height = imagesy($im);
    $ratio         = $source_height / $source_width;

    $new_height    = $ratio * $new_width;

    $thumb         = imagecreatetruecolor($new_width, $new_height);

    $transparency  = imagecolorallocatealpha($thumb, 255, 255, 255, 127);
    imagefilledrectangle($thumb, 0, 0, $new_width, $new_height, $transparency);

    imagecopyresampled($thumb, $im, 0, 0, 0, 0, $new_width, $new_height, $source_width, $source_height);
    $result = imagejpeg($thumb, $destination, 100);
    imagedestroy($im);

    return $result;
    }

function resizeImagexxx($source, $dest, $new_width, $force_height = false)
    {
    list($width, $height)               = getimagesize($source);

    $ratio        = $height / $width;
    if ($width < $new_width) $new_width    = $width;

    $new_height   = $ratio * $new_width;

    if ($force_height) $new_height   = $force_height;

    $image_p      = imagecreatetruecolor($new_width, $new_height);
    $image        = imagecreatefromjpeg($source);
    imagecopyresampled($image_p, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
    $result = imagejpeg($image_p, $dest, 100);
    imagedestroy($image_p);
    return $result;
    }

function resizeImage($source, $dest, $new_width, $force_height = false)
    {
    list($width, $height)               = getimagesize($source);

    $ratio        = $height / $width;

    if ($width < $new_width)
        {
        $new_width    = $width;
        }

    $new_height   = $ratio * $new_width;

    if ($force_height)
        {
        $new_height   = $force_height;
        }

    $src          = imagecreatefromstring(file_get_contents($source));

    $image_p      = imagecreatetruecolor($new_width, $new_height);
    imagecopyresampled($image_p, $src, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
    $result = imagejpeg($image_p, $dest, 100);
    imagedestroy($image_p);
    return $result;
    }

function createThumbnail($filename, $destination, $width     = 100, $height    = 0)
    {
    resizeImage($filename, $destination, $width, $height);
    }

function imageToBase64($filename)
    {

    if (is_readable($filename))
        {
        $filetype  = pathinfo($filename, PATHINFO_EXTENSION);

        $imgbinary = file_get_contents($filename);
        return base64_encode($imgbinary);
        }
    else return "";
    }
