<?php
/**
* Class and Function List:
* Function list:
* Classes list:
*/
define('_HOST_', $_SERVER['HTTP_HOST']);

define('_SITE_VERSION_', '1.0');
define('_APP_NAME_', 'OluSocial');
define('_BRAND_NAME_', 'OluSocial');

define('_DEFINED_', true);
define('_PROTOCOL_', (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS'] == 'on')) ? 'https://' : 'http://');

define('_ROOT_', $_SERVER['DOCUMENT_ROOT']);
define('_ROOT_DIR_', _ROOT_); //same as _ROOT_
$project_dir___ = str_replace(_ROOT_DIR_, '', dirname(__DIR__));

if ($project_dir___ == '/')
    {
    $project_dir___ = '';
    }

define('_PROJECT_FOLDER_', $project_dir___);

define('_CHAT_DIR_', _ROOT_DIR_ . _PROJECT_FOLDER_);

define('_PROJECT_DIR_', _CHAT_DIR_); //Same as _CHAT_DIR_
define('_SITE_URL_', _PROTOCOL_ . _HOST_ . _PROJECT_FOLDER_);

define('_ADMIN_DIR_', _PROJECT_DIR_ . '/oc-admin');

define('_ADMIN_URL_', _SITE_URL_ . '/oc-admin');

define('_SETTINGS_DIR_', _ADMIN_DIR_ . '/settings-files');

define('_CHAT_USER_DIR_', _CHAT_DIR_ . '/oc-users');

define('_FLAT_DB_DIR_', _CHAT_USER_DIR_);

define('_CHAT_GROUP_DIR_', _CHAT_DIR_ . '/oc-groups');

define("_CHAT_FILES_DIR_", _CHAT_DIR_ . "/oc-chat-files");

define("_CHAT_FILES_PATH_", _SITE_URL_ . "/oc-chat-files");

define('_ERROR_DIR_', _CHAT_DIR_ . '/oc-includes/ERRORS');

define('_TIMEZONE_', 'africa/lagos');

define('_MAX_CHAT_FILES_SIZE_', 25);
//IN MEGABYTES
//Take note: 16MB is set in app, but since base64 is expected to have increase in size by 33%

define('_CONTACT_EMAIL_', 'site@site.com');
define('_MAX_GROUP_MEMBERS_', 50);

date_default_timezone_set(_TIMEZONE_);

if (!preg_match("/localhost/i", _HOST_))
    {
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
    }

include ('error_handler.php');

define('__TODAYS_DATE__', date('Y-m-d H:i:s'));
$cfs = date('Y') . '/' . date('F') . '/' . date('d'); //You may add hour date('h'); if users are large
define('_CHAT_FILES_STRUCTURE_', $cfs);

require_once 'functions.php';
