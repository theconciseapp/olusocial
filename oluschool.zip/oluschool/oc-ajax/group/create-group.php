<?php
/**
* Class and Function List:
* Function list:
* - generatePin()
* Classes list:
*/
header('Content-type:application/json;charset=utf-8');

require ('../../oc-includes/bootstrap.php');

if (!verifyToken()) {
    die('{"error":"Invalid token."}');
}

if (empty($_POST['username']) || empty($_POST['group_title']) || empty($_POST['group_info']) || empty($_POST['version']) || empty($_POST['group_type'])) {
    die('{"error":"Parameters missing."}');
}

$settings__    = getSettings();

$enable_cgroup = isset($settings__["enable_create_group"]) ? $settings__["enable_create_group"] : 'YES';

if ($enable_cgroup != 'YES') {
    die('{"error":"Sorry, you can\'t create a group at the moment."}');
}

$username = test_input(strtolower($_POST['username']));
$gtitle   = test_input($_POST['group_title']);
$ginfo    = test_input($_POST['group_info']);

$type     = (int)$_POST['group_type'];

$begin    = "u";

if ($type != 1 && $type != 2) {
    die('{"error":"Invalid group type."}');
}

if ($type == 2) {
    $begin       = "v";
}

$app_version = test_input(strtolower($_POST['version']));

require "../../oc-includes/server.php";
require "group-functions.php";

$table    = _TABLE_GROUPS_;

$chkCount = 0;

function generatePin($b) {
    global $chkCount;
    $gpin = "gp_" . randomGroupPin(7, $b);

    $chkCount++;

    $gdir = getGroupDir($gpin);

    if (!is_dir($gdir)) {
        return $gpin;
    }
    else if ($chkCount > 3) {
        die('{"error":"Please try again. ERR:ChkC"}');
    }
    else {
        sleep(1);
        return generatePin($b);
    }
}

$gpin = generatePin($begin);

$time = time();
$mem  = $username . ",";

$stmt = $conn->prepare("INSERT INTO {$table}( group_type, group_pin,group_title, group_info, group_admins, group_members, created_by, created_on) VALUES (?,?,?,?,?,?,?,'$time')");

if (!$stmt || !$stmt->bind_param('issssss', $type, $gpin, $gtitle, $ginfo, $mem, $mem, $username) || !$stmt->execute()) {

    $conn->close();
    die('{"error":"Could not create. ErrIns"}');

}

$stmt->close();

$lastmtime = "" . ((microtime(true) * 10000) - 1); //last msg time
$data      = array();

$data["fuser"]           = $gpin; //group pin
$data["fullname"]           = $gtitle; //group title
$data["group_info"]           = $ginfo;
$data["last_message_time"]           = $lastmtime;
$data["created_by"]           = $username;
$data["created_on"]           = $time;
$data["app_version"]           = $app_version;
$data["group_members"]           = $mem;
$data["joined"]           = $time;
$data["group_admins"]           = $mem;

$gdir      = getGroupDir($gpin);

if (!makeGroupDir($gpin)) {
    //Roll back, if group folder could not be created
    $stmt      = $conn->prepare("DELETE FROM $table WHERE group_pin=? LIMIT 1");

    if (!$stmt || !$stmt->bind_param('s', $gpin) || !$stmt->execute()) {

        logIt("Could not roll back at create-group.php");
    }

    $conn->close();
    die('{"error":"Could not create! Please try again."}');

}

file_put_contents($gdir . '/lastseen.txt', $time);
$meta = array();

if (is_group($gpin)) {
    $msg  = '_You created a new group and your group\'s pin is:_ ?lg' . strtoupper(str_replace('gp_', '', $gpin)) . '?lg';
}

else {
    $msg  = '_You created a new page and your page pin is:_ ?lg' . strtoupper(str_replace('gp_', '', $gpin)) . '?lg';
}

$meta["hl"]      = str_replace('_', '', $msg);

customGroupMessage($conn, $gpin, $msg, $meta);

$data["status"] = "success";
die(json_encode($data));
