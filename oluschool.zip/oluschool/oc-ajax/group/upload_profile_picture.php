<?php 
require '../../oc-includes/bootstrap.php';
if( !verifyToken() ){
  die('{"error":"Invalid token."}');
 }

if( empty($_POST['username'] )
||empty( $_POST['group_pin'] )
||empty($_POST['base64']) ){
 die('{"error":"Picture data not found."}');
}

require '../../oc-includes/chat_functions.php';
require '../../oc-includes/server.php';
require 'group-functions.php';


function uploadBase64Image($conn, $save_to, $file_data,$thumbpath, $username, $gpin){
$f = finfo_open();
$mime_type = finfo_buffer($f, $file_data, FILEINFO_MIME_TYPE);
$file_type = explode('/', $mime_type)[0];
$extension = explode('/', $mime_type)[1];

$acceptable_mimetypes = [
    'image/gif','image/jpeg','image/jpg','image/png'
];

if (in_array($mime_type, $acceptable_mimetypes) ) {

 if( saveBase64Image($file_data,$save_to,500) ){
createThumbnail($save_to, $thumbpath,50);

$meta=array();

$msg='_Group picture updated_';

$meta["hl"]=str_replace('_','', $msg);

 customGroupMessage($conn, $gpin, $msg, $meta,"", $username . "~" );

die('{"status":"success","result":"Updated successfully"}');

}
else die('{"error":"Upload failed."}');

}else {
   die('{"error":"Picture type not supported."}');
}
  die('{"error":"Failed to upload."}');
}

$username=test_input(strtolower($_POST['username']) );

$gpin=test_input( strtolower($_POST['group_pin']) );

 $base64=test_input($_POST['base64']);
 
$base64 = str_replace('data:image/jpeg;base64,', '', $base64);
 
$base64= base64_decode($base64);

 $dir=getGroupDir($gpin);

 if( !is_dir( $dir) ){
  die('{"error":"Failed to update. ErrGrp."}');
}

$file=$dir . '/profile_picture_full.jpg';
$thumb=$dir . '/profile_picture_small.jpg';


uploadBase64Image($conn, $file,$base64,$thumb,$username, $gpin);
