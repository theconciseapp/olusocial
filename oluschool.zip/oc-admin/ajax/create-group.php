<?php
/**
* Class and Function List:
* Function list:
* Classes list:
*/
if (!isset($_SESSION))
  {
    session_start();
  }

header('Content-type:application/json;charset=utf-8');

require ('../../oc-includes/bootstrap.php');
adminLoggedIn(false, 'die', 'json');

if (!adminCanAddUser())
  {
    die('{"error":"Permission denied"}');
  }

if (empty($_POST['group_setting']) || empty($_POST['group_pin']) || empty($_POST['group_title']) || empty($_POST['group_info']))
  {
    die('{"error":"Parameters missing."}');
  }

$admin_username = getAdminInfo('username');

$gpin           = test_input(strtolower($_POST['group_pin']));

if (!preg_match("/^[a-z0-9]{7}$/i", $gpin))
  {
    die('{"error":"Pin must contain exactly 8 alphanumeric characters. "}');
  }

$gsetting = test_input(strtolower($_POST['group_setting']));

$gtitle   = test_input($_POST['group_title']);

$ginfo    = test_input($_POST['group_info']);

if (strlen($ginfo) > 600)
  {

    die('{"error":"Description too long. Max: 500 characters."}');

  }

$gpin = "gp_" . $gsetting . $gpin;

$gdir = getGroupDir($gpin);

if ($gpin == 'gp_pofficials' || file_exists($gdir) || is_dir($gdir))
  {

    die('{"error":"Pin is already in use."}');

  }

require "../../oc-includes/server.php";
require "../../oc-ajax/group/group-functions.php";

$gtitle  = mysqli_real_escape_string($conn, $gtitle);

$ginfo   = mysqli_real_escape_string($conn, $ginfo);

$gpin    = mysqli_real_escape_string($conn, $gpin);

$gadmins = test_input(str_replace(' ', '', $_POST['group_admins']));

if (!empty($gadmins))
  {

    $gadmins = trim(preg_replace("/,+/", ",", $gadmins) , ",");

    if (!preg_match("/^[a-z0-9,_]{4,200}$/i", $gadmins))
      {
        die('{"error":"Admins has some unwanted characters or length."}');
      }
    $gadmins = $gadmins . ',';
  }

$table   = _TABLE_GROUPS_;

$time    = time();
$gadmins = "{$admin_username},{$gadmins}";

$gac     = explode(",", $gadmins);
$gac     = count($gac) - 1;

$iquery  = mysqli_query($conn, "INSERT INTO {$table}(group_pin,group_title, group_info, group_admins, group_members, total_members, created_by, created_on) VALUES ('$gpin','$gtitle','$ginfo','$gadmins','$gadmins','$gac','$admin_username','$time')");

if (!$iquery || mysqli_affected_rows($conn) < 1)
  {
    die('{"error":"Could not create. ErrIns"}');
  }

$lastmtime = "" . ((microtime(true) * 10000) - 1); //last msg time


if (!makeGroupDir($gpin, '755'))
  {
    //Reverse, if group folder could not be created
    mysqli_query($conn, "DELETE FROM $table WHERE group_pin='$gpin'");

    die('{"error":"Could not create! Please try again."}');
  }

file_put_contents($gdir . '/lastseen.txt', $time);
$data = array();
$data["status"]      = "success";
$data["result"]      = "Successfully created.";
die(json_encode($data));
