<?php
/**
* Class and Function List:
* Function list:
* Classes list:
*/
if (!isset($_SESSION))
    {
    session_start();
    }

header('Content-type:application/json;charset=utf-8');

require ('../../oc-includes/bootstrap.php');
adminLoggedIn(false, 'die', 'json');

if (empty($_POST['username']))
    {
    die('{"error":"Empty parameter."}');
    }

$user     = test_input( strtolower( $_POST['username']) );

$lsfile   = getUserDir($user) . "/lastseen.txt";

$lastseen = "";
if (file_exists($lsfile))
    {
    $lsdata   = file_get_contents($lsfile);
   
 if (!empty($lsdata))
        {
        $lastseen = date('M-d-Y h:ia', $lsdata);
        }
    }

require '../../oc-includes/server.php';
$table = _TABLE_USERS_;

$stmt= $conn->prepare("SELECT username, fullname, email, phone FROM $table WHERE username=? LIMIT 1");

if ($stmt  && $stmt->bind_param('s', $user) && $stmt->execute() )
    {
 $res=$stmt->get_result();
   $stmt->close();
   $conn->close();

    if ( $res->num_rows < 1)
        {
        die('{"error":"No record found."}');

    }

    $row      = $res->fetch_assoc();
    $row["lastseen"]          = $lastseen;

   die( json_encode($row) );
    }

 $conn->close();
die('{"error":"Could not fetch."}');
