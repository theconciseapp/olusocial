$.ajaxSetup({
  timeout: 20000 //Time in milliseconds
});


$(function(){

$('body').on('click','.main-header-button',function(){
    var this_=$(this);
 $('#search-box-item').val('');
  var page=this_.data('page');
var pageCont=this_.data('header-button-item');
   $('.main-header-button-selected').removeClass('main-header-button-selected');
   this_.addClass('main-header-button-selected');
   $('.header-page').addClass('d-none');
  $('#' + pageCont ).removeClass('d-none');
 //alert(page)
loadPage( page );
});



$('body').on('click','#search-button',function(e){
e.preventDefault();
var word=$.trim($('#search-box').val() );
if(!word || word.length<3){
 alert('Search term too short.');
return;
} 
   var this_=$(this);
var pageCont=this_.data('header-button-item');
var page=this_.data('page');
 
   $('.main-header-button').removeClass('main-header-button-selected');
 
this_.addClass('main-header-button-selected');

$('#search-box-item').val(word);

  $('.header-page').addClass('d-none');
   $('#' + pageCont ).removeClass('d-none');
 
 loadPage(page );
});
  
$('body').on('click','.admin_page_link',function(e){
//pagination
 e.preventDefault();
var this_=$(this);
var urlParam=this_.attr('href');

var param=$.trim( $('.is_param').text());
  buttonSpinner(this_,false,'pagination-loader');

var page=$('.main-header-button-selected').data('page');

 loadPage(page, urlParam);
});

$('body').on('click','.user-role',function(e){
e.preventDefault();
var this_=$(this);
var username=this_.data('username');
 var result= this_.data('role');

 displayData('<strong>' + ( username +"").toUpperCase() + ' Permissions:</strong><br><br>' +result);


});


$('body').on('click','.user-info', function(){
var this_=$(this);
var user=this_.data('username');
 if(!user){
  alert('User not found.');
 return;
}

 var ui=$('.user-info');
  buttonSpinner(this_);
  ui.prop('disabled',true);
$.ajax({
url: _ADMIN_URL_ + '/ajax/user_info.php',
type:'POST',
dataType:'json',
data: {
  username: user,
},

}).done(function(result){
  buttonSpinner( this_,true);
  ui.prop('disabled', false);
 
 if(result.username){
  var fuser=result.username;
  var fullname=result.fullname;
  var email=result.email;
  var phone= result.phone;
 var lastseen=result.lastseen;

var data='<div class="mb-2"><label class="form-label">Fullname</label><input type="text" class="form-control" value="' + fullname + '" readonly></div>';

data+='<div class="mb-2"><label class="form-label">Email address</label><input type="text" class="form-control" value="' + email + '" readonly></div>';

data+='<div class="mb-2"><label class="form-label">Phone number</label><input type="text" class="form-control" value="' + phone + '" readonly></div>';

data+='<div class="mb-2"><label class="form-label">Last seen</label><input type="text" class="form-control" value="' + lastseen + '" readonly></div>';

 displayData( data,{ id:'showing-user-info', htitle: '<i class="fa fa-user text-secondary"></i> ' + ucfirst(fullname) + ' info'});

}else if(result.error){
  toast(result.error);
}
else{
  toast('Unknown error occured.');
  }
}).fail(function(e, txt, xhr ){
  buttonSpinner( this_, true);
  ui.prop('disabled', false)

toast('Check your network connection. ' + xhr);
  });
});

$('body').on('click','.activate-user',function(e){
e.preventDefault();
var this_=$(this);
 var username=this_.data('username');
 
if(!username) {
 alert('Username not found.');
return;
}

$('.activate-user').prop('disabled', true);

buttonSpinner( this_);
$.ajax({
  url: _ADMIN_URL_ + '/ajax/activate_user.php',
  type:'POST',
  data: {
  'username': username,
 }
}).done(function( result ){
  buttonSpinner( this_,true);
$('.activate-user').prop('disabled', false);
  if( result.match(/__SUCCESS__/) ){
  this_.closest('.user-panel').remove();
 }else{
   toast('Failed.');
  }
}).fail(function(e){
  buttonSpinner( this_,true);
 $('.activate-user').prop('disabled', false);
  alert(JSON.stringify(e));
 });

});


$('body').on('click','.block-user',function(){
 var this_=$(this);
 var type=this_.data('type');
var fullname=this_.parent().parent().find('.user-fullname-text').text();

if(!confirm(type + ' ' + fullname + '\'s account?.')) return;
 

$('.block-user').prop('disabled',true);
 buttonSpinner(this_);

 setTimeout(function(){
 var user=this_.data('username');
$.ajax({
url: _ADMIN_URL_ + '/ajax/block_user.php',
type:'POST',
dataType:"json",
data: {username: user}
}).done(function(result){

$('.block-user').prop('disabled', false);
buttonSpinner(this_,true);

if(result.status){
this_.closest('.user-panel').remove();
  toast( result.result, {type:'success'});
} 
 else if(result.error){
  toast(result.error);
 }
else{
  toast('Unknown error occured.');
}
}).fail(function(e){
$('.block-user').prop('disabled', false)
 buttonSpinner(this_,true)
  toast('Check your internet connection.');
 });
},1000);

});


$('body').on('click','.delete-user',function(){
var this_=$(this);
var fullname=this_.parent().parent().find('.user-fullname-text').text();

if(!confirm('Delete ' + fullname + '\'s account?\n\nThis action is irreversible.')) return;
 
$('.delete-user').prop('disabled',true);
 buttonSpinner(this_);

 setTimeout(function(){
 var user=this_.data('username');
$.ajax({
url: 'ajax/delete_user.php',
type:'POST',
dataType:'json',
data: {username: user}
}).done(function(result){

$('.delete-user').prop('disabled', false);
buttonSpinner( this_,true);

 if(result.status ){
  this_.closest('.user-panel').remove();
 }else if(result.error){
   toast(result.error);
 }
else{
  toast('Failed to delete');
  }
}).fail(function(e){
$('.delete-user').prop('disabled', false)
 buttonSpinner(this_,true)
 toast('Check your internet connection.');
});
},1000);

});

$('body').on('click','.user-photo-icon',function(e){
 var this_=$(this);
 var src_=this_.attr('src');
if(!src_) {
 return toast('Image link not found.');
}
 var data='<div class="ufp-spinner text-center" style="height: 4rem;"><div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status"><span class="visually-hidden">Loading...</span></div></div><img class="user-full-photo d-none" src="">';

 displayData( data);

toDataURL( src_.replace('_small','_full'),function(dataUrl) {
  var ufp=$('.user-full-photo');
  ufp.attr('src', dataUrl);
 setTimeout(function(){
 $('.ufp-spinner').remove();
 ufp.removeClass('d-none');
},1000);
  });

});

$('body').on('click','#add-user-btn',function(){   

  try{

  var this_=$(this);
 var rdiv=$('#register-user-result');
 rdiv.empty();

   var username= $.trim($('#username1').val() );
    var email= $.trim($('#email1').val());
    var fullname= $.trim($('#fullname1').val());
    var phone=$.trim($('#phone1').val());
    var password=$.trim($('#password1').val());
        
    if(!username || username.length<4 || username.length>30) {
    return toast('Username too long or short.');

   }else if( !validUsername(username) ) {
   return toast('Invalid username. Alphanumerics, an underscore supported and must start with a letter.');
   }
  else if( !email || email.length<5 ) {
     return toast('Enter a valid email address.');    
   }
   else if(!fullname || fullname.length<2 || fullname.length>60) {
     return toast('Enter a valid full name.');
   }
else if(!phone || !phone.match(/^[0-9+() -]{4,50}$/)) {
     return toast('Enter a valid phone number.');    
  }
else if(!validName(fullname) ){
     return toast('Enter a good display name. Alphabets, .\'_ - supported and must start and end with a letter.</span>');    
    }
  
  else if(!password ||password.length<6) {
   return toast('Password should contain at least 6 characters.');    

  }
    else if(password.length>50) {
    return toast('Password too long. Max: 50.');    
    }    
    else if( !validPassword(password) ){
     return toast('Passwords can only contain the following characters: a-z 0-9 ~@#%_+*?-');
    }
    $('input,button').prop('disabled',true);
   buttonSpinner(this_);
 var elem=$('.add-user-form-container input');

    $.ajax({
      'url': _ADMIN_URL_ + '/ajax/add_new_user.php',
    type:'POST',
   dataType: 'json',
      'data':
      {
       "username":username,
       "email": email,
       "fullname": fullname,
       "phone": phone,
       "password": password,
      },
      type:'POST'
    }).done(function(result){
 // alert(result)
   buttonSpinner( this_, true);
   $('input,button').prop('disabled', false);
      
  if(result.error){
   rdiv.html('<span class="text-danger">' + result.error + '</span>');
}
 else if( result.status ){
  elem.val('');
   rdiv.html('<span class="text-success">' + result.result + '</span>');
 
   } else{
     rdiv.text('Unknown error occured.');
      }
            
    }).fail(function(e, txt, xhr){
      $('input,button').prop('disabled',false);
      buttonSpinner(this_,true);   
    toast('Check your internet connection and try again. ' + xhr);
// alert( JSON.stringify(e) );

    });
}catch(e){ alert(e); }
  
  });
  

$('body').on('click','#add-admin-btn',function(){   
    $('.input-error').empty();
    var this_=$(this);


   var username= $.trim($('#register-admin-username').val() );
    var email= $.trim($('#register-admin-email').val());
    var fullname= $.trim($('#register-admin-fullname').val());
    var phone=$.trim($('#register-admin-phone').val());
    var password=$.trim($('#register-admin-password').val());

var role=$.trim($('#register-admin-role').val() );

 var rdiv=$('#register-admin-result');
      
    if(!username || username.length<4 || username.length>30) {
    return toast('Username too long or short.');

   }else if( !validUsername(username) ) {
   return toast('Invalid username. Alphanumerics, an underscore supported and must start with a letter.');
   }
  else if( !email || email.length<5 ) {
    rdiv.html('<span class="text-danger">Enter a valid email address.</span>');
   return;
   }
   else if(!fullname || fullname.length<2 || fullname.length>80) {
     rdiv.html('<span class="text-danger">Fullname too short or long.</span>');
   return;
   }
    else if(!fullname.match(/^[a-zA-Z]+[a-zA-Z0-9.'_ -]+$/) ) {
    rdiv.html('<span class="text-danger">Enter valid full name.</span>');
    return;
    }      
  else if(!phone || !phone.match(/^[0-9+() -]{4,50}$/)) {
    rdiv.html('<span class="text-danger">Enter a valid phone number.</span>');
    return;
  }
  else if(!password ||password.length<6) {
   rdiv.html('<span class="text-danger">Password too short. Minimum 6 char.</span>');
   return;
  }
    else if(password.length>50) {
   rdiv.html('<span class="text-danger">Password too long. Maximum 50 char.</span>');
  return;
    }    
    else if(!password.match(/^[a-zA-Z0-9~@#%_+*?-]+$/) ){
   rdiv.html('<span class="text-danger">Passwords can only contain the following characters: a-z 0-9 ~@#%_+*?-</span>');
  return;
 }

    $('input, button').prop('disabled',true);
   buttonSpinner(this_);
 var elem=$('#add-admin-form-container input');

    $.ajax({
      'url': _ADMIN_URL_ + '/ajax/add_new_admin.php',
  type:'POST',
 dataType: 'json',
      'data': {
       "username":username,
       "email": email,
       "fullname": fullname,
       "phone": phone,
       "password": password,
       "role": role,
      },
      type:'POST'
    }).done(function( result){

   buttonSpinner( this_, true);
   $('input, button').prop('disabled', false);
      
  if(result.error){
   rdiv.html('<span class="text-danger">' + result.error + '</span>');
}
 else if( result.status ){
  elem.val('');
   rdiv.html('<span class="text-success">' + result.result + '</span>');
 
   } else{
     rdiv.text('Unknown error occured.');
      }
    }).fail(function(e, txt, xhr){
      $('input,button').prop('disabled',false);
      buttonSpinner(this_, true);   
    toast('Check your internet connection and try again. ' + xhr);
    });

  
  });
 

$('body').on('click','.delete-admin',function(e){
e.preventDefault();
var this_=$(this);
 var username=this_.data('username');
 
if(!username) {
 toast('Username not found.');
return;
}
if(!confirm('Delete ' + username + '?')){
 return;
}

$('.delete-admin').prop('disabled', true);

buttonSpinner( this_);

$.ajax({
  url: _ADMIN_URL_ + '/ajax/delete_admin.php',
  type:'POST',
 dataType:'json',
  data: {
  'username': username,
 }
}).done(function( result ){
  buttonSpinner( this_,true);
$('.delete-admin').prop('disabled', false);
 if( result.error ){
 return toast( result.error );
} else if( result.status){
  
this_.closest('.user-panel').remove();

 return toast( result.result,{type:'success'});
 }else{
   toast('Unknown error occured.');
  }
}).fail(function(e){
  buttonSpinner( this_,true);
 $('.activate-user').prop('disabled', false);
  toast('Check your internet connection.');
 });

});


$('body').on('click','#forgot-password-btn', function(){
   //send forgot password code
  var this_=$(this);
  var email=$.trim( $('#email-box').val() );
 if( email.length<5 ){
     return toast('Enter a valid email address.');
  }
   $('input,button').prop('disabled',true);
    buttonSpinner(this_);
  $.ajax({
    'url': _ADMIN_URL_ + '/ajax/forgot_password.php',
      'dataType':'json',
      'data':{
       "email":email,
      },
      type:'POST'
    }).done(function( result){
  // alert( JSON.stringify(result) );
   buttonSpinner(this_, true);
  $('input, button').prop('disabled',false);
  
   if( result.error){
    toast( result.error);
 }else if(result.status  ){
   toast( result.result, { type: 'success',hide:8000});
 $('#email-box').val('');
 }
   else{
    toast('Unknown error occured.');
  }
}).fail( function(e){
     buttonSpinner(this_, true);
    $('input,button').prop('disabled',false);
      toast('Check your internet connection.');
    });
 });
  
$('body').on('click','#reset-password-btn', function(){
   //reset password
 var this_=$(this);
  var password=$.trim( $('#password').val() );
 var email=$.trim($('#email').val());
 var token=$.trim( $('#token').val());

if(!email||!token){
 return toast('Expected parameters not found.');
}else
 if( password.length<6 ){
  return toast('Enter a secure password. At least 6 characters.');
  }
else if( password.length>50 ){
  return toast('Password too long. Maximum of 50 characters allowed.');
  }
   else if(!validPassword(password)) {
 return toast('Passwords can only contain the following characters: a-z 0-9 ~@#%_+*?-');
}

$('input,button').prop('disabled',true);
    buttonSpinner(this_);
  $.ajax({
    'url': _ADMIN_URL_ + '/ajax/reset_password.php',
      'dataType':'json',
      'data':{
       "email":email,
       "token": token,
       "password": password,
      },
      type:'POST'
    }).done(function( result){
  // alert( JSON.stringify(result) );
   if( result.error){
    toast( result.error);
 }else if(result.status  ){
   toast( result.result, { type: 'success'});
setTimeout(function(){
  location.href=_ADMIN_URL_ +'/login.php';
  },2000);
return;
 }
   else{
    toast('Unknown error occured.');
  }

buttonSpinner(this_,true);
 $('input,button').prop('disabled',false);
}).fail( function(e){
     buttonSpinner(this_, true);
    $('input,button').prop('disabled',false);
      toast('Check your internet connection.');
    });
  });


$('body').on('click','.site-log', function(){
var this_=$(this);
var type=this_.data('type');
var action_=this_.data('action');

if(action_=='clear' &&!confirm('Clear this log?')) return;

 var ui=$('.show-log');
var rdiv=$('#site-log' + type + '-result');

  buttonSpinner( this_ );
  ui.prop('disabled',true);

try{

$.ajax({
url: _ADMIN_URL_ + '/ajax/site-log.php',
type:'POST',
dataType:'json',
data: {
  "type": type,
 "action": action_
},

}).done(function(result){
 //alert( JSON.stringify(result))
  buttonSpinner( this_,true);
  ui.prop('disabled', false);
 
if( result.status){

 if( action_=='clear'){
   rdiv.empty();

return   toast('Cleared successfully!',{ type: 'success'});

}

 var data=(result.result.replace(/<!break>$/,'') ).split('<!break>');
 
var total= data.length;
for(var i=0; i<total; i++){

 rdiv.append('<div class="alert alert-danger">' + data[i] + '</div>');

}
}else if (result.error){
 toast( result.error);

}else{
  toast('Unknown error occured.');
}


}).fail(function(e, txt, xhr ){
  buttonSpinner( this_, true);
  ui.prop('disabled', false);
toast('Check your network connection. ' + xhr);
  });

}catch(e){
 toast(e)
}

});


});

function loadMain(url,container){
container=container||'#active-users-container';
 var search=$.trim( $('#search-box-item').val());
  $('.main-header-button:not(.no-delay)').prop('disabled',true);

loadingIndicator($(container));

 setTimeout( function(){
$.ajax({
url: url,
type:'GET',
 data:{
search: search
 }
}).done(function(result){
  $(container).html(result);
$('.main-header-button').prop('disabled', false);
 $('#pagination-loader').remove();
}).fail(function(e,txt,xhr){
 toast('Check your internet connection. ' + xhr);
 //alert(JSON.stringify(e));

$('.main-header-button').prop('disabled', false);
loadingIndicator( $(container),true);
$('#pagination-loader').remove();
  });
},1000);

}


function loadingIndicator(node,remove_){
 if(remove_){
node.children('.loading-indicator-container').remove();
return;
}
 if( node.children('.loading-indicator-container').length) return;
node.append('<div class="loading-indicator-container text-center"><div class="spinner-border text-primary" style="width: 4rem; height: 4rem;" role="status"><span class="visually-hidden">...</span></div></div>');

}


function loadPage(page, param){
 
param=param||'?';

if( page=="empty"){
return;
}
else  if( page && page.match(/^[a-zA-Z0-9_-]+$/) ){

   loadMain(_ADMIN_URL_ + '/ajax/' + page + '.php' + param,'#' + page+'-container');
  }
else return toast('Malformed page');
}



function sendMessage(node){
var user=node.data('username');
 var textbox=$('.message-textbox-' + user);
 
var res_=$('.message-result-' + user);
res_.empty();

var send_as=$.trim( $('#send-message-as').val());

var message=$.trim(textbox.val());

if(!send_as ||send_as.length<3||send_as.length>20){
return toast('"Send as" too short or long. Min: 3, Max: 20');
}
else if(!send_as.match(/^([a-z]+)_?[a-z0-9]+$/i) ){
return toast('"Send as" not acceptable. Alphanumerics and an underscore supported only and must start with an alphabet.',{hide: 10000});
 }
else if(!message||message.length>15000){
 return toast('Message too long or short.');
 }

localStorage.setItem('send_message_as',send_as);

message=sanitizeMessage( message );
//message=escape( message);

var group="";
if( $('#users-list-container #is-group').length){
 group="YES";
}

  buttonSpinner(node);
  node.prop('disabled',true);
$.ajax({
url: _ADMIN_URL_ + '/ajax/send_message.php',
type:'POST',
dataType:'json',
data: {
  username: user,
 send_as: send_as,
 message:message,
 is_group: group,
},

}).done(function(result){
  buttonSpinner(node,true);
  node.prop('disabled', false);
  if( result.error){
 toast(result.error);
} else if(result.status){
textbox.val('');
  toast(result.result, { type: 'success'});
}else{
 toast('Unknown error occured.');
}
 
}).fail(function(e){
  buttonSpinner(node, true);
  node.prop('disabled', false)
 toast('Check your internet connection.');
});

}

function sanitizeMessage(data,direct){
  if(direct) return data;
  return data
    .replace(/:/g,'&#58;')
    .replace(/[\r\n]{2,}/g,':nl:::nl::')
    .replace(/[\r\n]+/g,':nl::');
}


function messageUserForm(node ){
  node=$(node );
var user=node.data('username');

  tnode=$('.message-textbox-container-' + user);
if(tnode.length){
  tnode.slideToggle();
return;
}
 $('.message-textbox-container').remove();
 var boxContainer=$('<div></div>')
    .addClass('message-textbox-container container message-textbox-container-'+ user)
  .css('display','none');

var send_as=localStorage.getItem('send_message_as')||'admin';

 var nameBox=$('<div class="d-none mb-1">Send as: <input id="send-message-as" type="text" class="form-control" maxlength="20" value="' + send_as + '" /></div>');
 
var textarea=$('<div class="mb-1">Message: <textarea class="message-textbox message-textbox-' + user + ' form-control"></textarea></div>');

 var uploadBox=$('<div class="file-message-upload-box dropzone text-center" id="upload-file-message-widget" style="display: none;"> <div class="dz-message">Select file</div><input type="hidden" id="send-file-message-to" value="' + user + '">');
   
 var button=$('<button>Send</button>')
     .addClass('btn btn-sm btn-success btn-send-message mt-1')
     .attr('data-username',user)
    .on('click',function(){
   sendMessage($(this) );
 });

 var showUploadBoxBtn=$('<button onclick="javascript:$(\'.file-message-upload-box,.btn-send-message,.message-textbox\').toggle();" class="btn btn-sm btn-secondary mt-1" style="margin-left: 5px;">File</button>');

  boxContainer.append(nameBox)
    .append(textarea)
    .append(uploadBox)
    .append(button)
    .append(showUploadBoxBtn)
    .append(' <span class="message-result-' + user +'"></span>');
node.closest('.users-list-container').append(boxContainer);
   boxContainer.slideDown();
  var myDropzone = new Dropzone("div#upload-file-message-widget", { url: _ADMIN_URL_ + "/ajax/send_file_message.php"});
}


function buttonSpinner(node,done,custom_id){
  node.find('.button-spinner').remove();
if(done ) return;
node.append(' <span class="button-spinner" id="' + custom_id + '"><span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>'
+ '<span class="visually-hidden">Loading...</span></span>');
}



function imgError(image,size) {
    image.onerror = "";
    image.src = _ADMIN_URL_ + "/no-photo.png";
   if(size) $(image).width(size)
    return true;
}

function createAdminForm(this_){
 this_=$(this_);
 var cont=this_.next('.create-admin-container');
if( cont.length){ 
   cont.slideToggle();
return;
}
  var container=$('<div></div>')
.addClass('create-admin-container mt-2');

  var uForm=$('<div class="form-group"><input class="create-admin-box form-control" placeholder="Enter unique username"></div>');

  var roleForm=$('<div class="form-group"><select class="form-control"><option>3</option><option>2</option><option>1</option></select></div>');
 container.append(uForm).append(roleForm);
 this_.after(container);
}

 
function toDataURL(src, callback, outputFormat) {
  var img = new Image();
  img.crossOrigin = 'Anonymous';
  img.onload = function() {
    var canvas = document.createElement('CANVAS');
    var ctx = canvas.getContext('2d');
    var dataURL;
    canvas.height = this.naturalHeight;
    canvas.width = this.naturalWidth;
    ctx.drawImage(this, 0, 0);
    dataURL = canvas.toDataURL(outputFormat);
    callback(dataURL);
  };
  img.src = src;
  if (img.complete || img.complete === undefined) {
    img.src = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==";
    img.src = src;
  }
}


Dropzone.options.uploadFileMessageWidget = {
  paramName: 'file',
  maxFilesize: 100, // MB
  maxFiles: 1,
 // resizeWidth: 150,
  dictDefaultMessage: 'Select File',
 // acceptedFiles: 'image/*',
  init: function() {

 var group="";
if( $('#users-list-container #is-group').length){
 group="YES";
}
var user= $.trim( $('#send-file-message-to').val());
var send_as="admin"; //$.trim( $('#send-message-as').val() );

/*
if( !send_as.match(/^([a-z]+)_?[a-z0-9]+$/i) ){
return toast('"Send as" not acceptable. Alphanumerics and an underscore supported only and must start with an alphabet.',{hide: 10000});
}
*/

localStorage.setItem('send_message_as',send_as);

this.on("sending", function(file, xhr, formData) {
  formData.append("chat_to",user);
  formData.append("send_as",send_as);
  formData.append("is_group",group);
 });

this.on("complete", function(file) {
  this.removeFile(file);
});
  this.on('success', function(file, resp){
 
 if( resp.status ){
  
toast('Sent successfully.',{type:'success',pos:'50'});

 }else if(resp.error){
 toast(resp.error);
}
 });

  }
};
