<?php if (!isset($_SESSION)) {
   session_start();
}

require('../oc-includes/bootstrap.php'); adminLoggedIn();?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">


<link rel="stylesheet" href="assets/css/index.css?i=<?php echo randomString(3);?>">

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script>
var _ADMIN_URL_='<?php echo _ADMIN_URL_;?>';
</script>
</head>
<body>

<nav class="navbar fixed-top navbar-expand-sm navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"> <img src="<?php echo _SITE_URL_.'/oc-logo.png';?>" class="logo"> <?php echo _BRAND_NAME_;?> </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" aria-current="page" href="<?php echo _ADMIN_URL_;?>">Home</a>

<a class="nav-link" href="<?php echo _ADMIN_URL_.'/logout.php';?>">Logout</a>
     
      </div>
    </div>
  </div>
</nav>

<div class="container-fluid p-md-5">

  <div class="row">
   <div class="col-12 col-md-6">

<div class="mb-2">
<label class="form-label"><b>Welcome message</b></label>

<div class="form-text">Set a welcome message for newly registered users (Max: 100 words). To include user's name in your message, enter "[user::]" without quotes. E.g Welcome [user::], will result to Welcome Caroline.</div>

<textarea class="form-control" id="welcome-message-box" row="3"><?php 
 $wmessage=_CHAT_FILES_DIR_.'/welcome/welcome.txt';
 if( is_readable( $wmessage) ){
 echo @file_get_contents( $wmessage);
}?></textarea>

</div>

<button id="welcome-message-btn" class="btn btn-sm btn-primary mt-1">Save</button>

<div id="save-welcome-message-result" class="pt-2"></div>

<hr />

<form action="upload_welcome_video.php" method="post" enctype="multipart/form-data">
<div class="mb-3">

<label class="form-label"><b>Upload welcome video</b></label>
<div class="form-text">Short video message for newly registered user ( Max: 10MB )</div>
<input type="file" name="video" class="form-control" accept="video/*">
</div>

<input type="submit" class="btn btn-sm btn-primary" value="Upload">

<?php 
$wvideo=_CHAT_FILES_DIR_.'/welcome/0123456789.mp4';
 $dnone="d-none";
 if( is_file( $wvideo) ){
  $dnone="";
}
echo'<button id="delete-welcome-video" class="btn btn-sm btn-warning '.$dnone.'"><i class="fa fa-lg fa-trash"></i> Delete</button>';
 ?>
</form>
<hr />

<div class="row">
     <div class="col-9">
<div>
<h5>App/Site settings</h5>
</div>
   </div><div class="col-3">
   <button class="edit-btn" onclick="$('#app-settings-container').slideToggle();"> <i class="fa fa-pencil fa-lg text-primary"></i></button>
   </div>
    </div>

<div id="app-settings-container" class="container p-3" style="background: #f5f5f5; border: 0; border-radius: 3px; display: none;">

<?php  $sJson=getSettings(); 

$enable_chat=isset( $sJson["enable_chat"] )? $sJson["enable_chat"]:"YES";
$req_speed=isset( $sJson["chat_request_speed"] )? $sJson["chat_request_speed"]:"10";

$enable_addcontact=isset( $sJson["enable_add_contact"] )?$sJson["enable_add_contact"]:"YES";

$enable_cgroup=isset( $sJson["enable_create_group"] )?$sJson["enable_create_group"]:"YES";

$enable_jgroup=isset( $sJson["enable_join_group"] )?$sJson["enable_join_group"]:"YES";

$mgc=isset( $sJson["max_groups_check"] )?$sJson["max_groups_check"]:"3";

$users_pgroup=isset( $sJson["users_per_group"] )?$sJson["users_per_group"]:"100";

$enable_vid_doc=isset( $sJson["enable_vid_doc"] )?$sJson["enable_vid_doc"]:"YES";
 $enable_registration=isset( $sJson["enable_registration"] )?$sJson["enable_registration"]:"YES";
$enable_login=isset( $sJson["enable_login"] )?$sJson["enable_login"]:"YES";
$enable_reg_captcha=isset( $sJson["enable_registration_captcha"] )?$sJson["enable_registration_captcha"]:"NO";
$enable_login_captcha=isset( $sJson["enable_login_captcha"] )?$sJson["enable_login_captcha"]:"NO";

$enable_email_ver=isset( $sJson["enable_email_verification"] )?$sJson["enable_email_verification"]:"NO";
$enable_mactivation=isset( $sJson["enable_manual_activation"] )?$sJson["enable_manual_activation"]:"NO";

$users_pp=isset( $sJson["users_per_page"] )?$sJson["users_per_page"]:"20";

$app_name=isset( $sJson["app_name"] )?$sJson["app_name"]:"vf_olusocial";
?>

<div class="p-3">

<form id="settings-form">
<div class="mb-2">
<label class="form-label">
Enable drop-it messages
</label>
<div class="form-text">Enable this if you want users to drop messages for themselves.</div>
<select class="form-control" id="enable_chat" name="enable_chat">
<option<?php echo ($enable_chat=='YES'?' selected':'');?>>YES</option>
<option<?php echo ($enable_chat=='NO'?' selected':'');?>>NO</option>
</select>
</div>

<div class="mb-2">
<label class="form-label">
Allow users drop videos and documents to eachother.
</label>
<div class="form-text">
Video files and documents from users could eat up your server's space & bandwidth faster, hence this option. 
</div>
<select class="form-control" id="enable-vid_doc" name="enable_vid_doc">
<option<?php echo ($enable_vid_doc=='YES'?' selected':'');?>>YES</option>
<option<?php echo ( $enable_vid_doc=='NO'?' selected':'');?>>NO</option>
</select>
</div>


<div class="mb-2">
<label class="form-label">Posts and 
Drop-it messages check speed (in seconds. Minimum: 5)</label>
<div class="form-text d-none text-danger">
Alert: Use this to change speed of drop-it messages delivery/seen or other interactions. It may crash your server if set to a lower value. ( This does not affect comments ) 
</div>

<input type="number" maxlength="3" class="form-control" id="chat_request_speed" name="chat_request_speed" value="<?php echo $req_speed;?>">
</div>



<div class="mb-2">
<label class="form-label">
Users can add contact
</label>

<select class="form-control" id="enable-add-contact" name="enable_add_contact">
<option<?php echo ($enable_addcontact=='YES'?' selected':'');?>>YES</option>
<option<?php echo ($enable_addcontact=='NO'?' selected':'');?>>NO</option>
</select>
</div>

<div class="mb-2">
<label class="form-label">
Allow users create groups
</label>

<select class="form-control" id="enable_create_group" name="enable_create_group">
<option<?php echo ($enable_cgroup=='YES'?' selected':'');?>>YES</option>
<option<?php echo ($enable_cgroup=='NO'?' selected':'');?>>NO</option>
</select>
</div>

<div class="mb-2">
<label class="form-label">
Allow users to join groups
</label>

<select class="form-control" id="enable_join_group" name="enable_join_group">
<option<?php echo ($enable_jgroup=='YES'?' selected':'');?>>YES</option>
<option<?php echo ($enable_jgroup=='NO'?' selected':'');?>>NO</option>
</select>
</div>


<div class="mb-2">
<label class="form-label">
Max number of groups or pages to query from database at a time from the app.
</label>
<div class="form-text">
Recommended: 3. If you have fewer user base, you can increase this value.
</div>

<select class="form-control" id="max-groups-check" name="max_groups_check">
<option<?php echo ($mgc=='1'?' selected':'');?>>1</option>
<option<?php echo ($mgc=='2'?' selected':'');?>>2</option>
<option<?php echo ($mgc=='3'?' selected':'');?>>3</option>
<option<?php echo ($mgc=='5'?' selected':'');?>>5</option>
<option<?php echo ($mgc=='7'?' selected':'');?>>7</option>
<option<?php echo ( $mgc=='10'?' selected':'');?>>10</option>

</select>
</div>


<div class="mb-2">
<label class="form-label">
Maximum number of participants per group
</label>
<div class="form-text">
Maximum: <?php echo _MAX_GROUP_MEMBERS_;?>
</div>
<input type="number" maxlength="3" class="form-control" id="users_per_group" name="users_per_group" value="<?php echo $users_pgroup;?>">
</div>


<div class="mb-2">
<label class="form-label">
Enable user registration
</label>

<select class="form-control" id="enable_registration" name="enable_registration">
<option<?php echo ($enable_registration=='YES'?' selected':'');?>>YES</option>
<option<?php echo ( $enable_registration=='NO'?' selected':'');?>>NO</option>
</select>
</div>


<div class="mb-2">
<label class="form-label">
Enable user login
</label>

<select class="form-control" id="enable_login" name="enable_login">
<option<?php echo ($enable_login=='YES'?' selected':'');?>>YES</option>
<option<?php echo ($enable_login=='NO'?' selected':'' );?>>NO</option>
</select>
</div>

<div class="mb-2">
<label class="form-label">
Enable registration captcha
</label>

<select class="form-control" id="enable_registration_captcha" name="enable_registration_captcha">
<option<?php echo ($enable_reg_captcha=='YES'?' selected':'');?>>YES</option>
<option<?php echo ($enable_reg_captcha=='NO'?' selected':'' );?>>NO</option>
</select>
</div>

<div class="mb-2">
<label class="form-label">
Enable login captcha
</label>

<select class="form-control" id="enable_login_captcha" name="enable_login_captcha">
<option<?php echo ($enable_login_captcha=='YES'?' selected':'');?>>YES</option>
<option<?php echo ($enable_login_captcha=='NO'?' selected':'' );?>>NO</option>
</select>
</div>

<div class="mb-2">
<label class="form-label">
Verify email address of newly registered users. If disabled, users will be automatically activated
</label>

<select class="form-control" id="enable_registration_captcha" name="enable_email_verification">
<option<?php echo ($enable_email_ver=='YES'?' selected':'');?>>YES</option>
<option<?php echo ($enable_email_ver=='NO'?' selected':'' );?>>NO</option>
</select>
</div>

<div class="mb-2">
<label class="form-label">
Activate newly registered users manually
</label>
<div class="form-text">
If you choose to activate manually, user's email address will not be verified.
</div>

<select class="form-control" id="enable-manual-activation" name="enable_manual_activation">
<option<?php echo ($enable_mactivation=='YES'?' selected':'');?>>YES</option>
<option<?php echo ($enable_mactivation=='NO'?' selected':'' );?>>NO</option>
</select>
</div>


<div class="mb-2">
<label class="form-label">
Total number of users to show per page in admin panel
</label>

<select class="form-control" id="users_per_page" name="users_per_page">
<option<?php echo ($users_pp=='10'?' selected':'');?>>10</option>
<option<?php echo ( $users_pp=='20'?' selected':'');?>>20</option>
<option<?php echo ( $users_pp=='40'?' selected':'');?>>40</option>
<option<?php echo ( $users_pp=='100'?' selected':'');?>>100</option>

</select>
</div>

<div class="mb-2">
<label class="form-label">
Site/App name
</label>
<div class="form-text">
Alphabets & numbers only (no space ), and must start with an alphabet. Recommended: Start app name with vf_ to indicate as verified. Max: 20
</div>
<input class="form-control" id="app_name" name="app_name" value="<?php echo $app_name;?>">
</div>

</form>

<button id="save-settings-btn" class="btn btn-sm btn-primary mt-1">Save</button>

</div>
</div>
<hr />
</div>


<div class="col-12 col-md-6">

<div class="row">
     <div class="col-9">
       <div class="">
<h5>SMTP Mail setup</h5>
</div>
   </div><div class="col-3">
   <button class="edit-btn" onclick="$('#smtp-setup-container').slideToggle();"> <i class="fa fa-pencil fa-lg text-primary"></i></button>
   </div>
    </div>
   
<div id="smtp-setup-container" class="stmp-setup-container p-3" style="display: none;">

<?php $emailer_file=_ADMIN_DIR_.'/settings-files/emailer-config.txt';
  $emailer_info="";

 if( file_exists( $emailer_file) ){
 $emailer_info="".( file_get_contents($emailer_file ) );
}

 $ei=json_decode( $emailer_info);

$email_channel=isset( $ei->email_channel)?$ei->email_channel:"";
$email_host=isset( $ei->email_host)?$ei->email_host:"";
$email_auth=isset( $ei->email_authentication)?$ei->email_authentication:"";
$email_username=isset( $ei->email_username)?$ei->email_username:"";
$email_password=isset( $ei->email_password)?$ei->email_password:"";
$email_port=isset( $ei->email_port)?$ei->email_port:"";
$email_encryption=isset( $ei->email_encryption)?$ei->email_encryption:"";
$email_from=isset( $ei->email_from)?$ei->email_from:"";
$email_alias=isset( $ei->email_alias)?$ei->email_alias:"";
?>

<form id="stmp-setup-form">

<div class="mb-2">

<label class="form-label">Channel</label>
<div class="form-text">
If you set to "default", you may leave other fields as it is.
</div>
<select class="form-control" id="email-channel" name="email_channel">
<option value="phpmailer"<?php echo ($email_channel=='phpmailer'?' selected':'');?>>PHPMAILER</option>
<option value="default"<?php echo ($email_channel=='default'?' selected':'');?>>DEFAULT</option>
</select>
</div>

<div class="mb-2">

<label class="form-label">SMTP Host</label>

<input class="form-control" id="email-host" name="email_host" value="<?php echo $email_host;?>">
</div>


<div class="mb-2">

<label class="form-label">SMTP Authentication</label>

<select class="form-control" id="email-authentication" name="email_authentication">
<option value="true"<?php echo ($email_auth=='true'?' selected':'');?>>TRUE</option>
<option value=""<?php echo ($email_auth==''?' selected':'');?>>FALSE</option>
</select>
</div>

<div class="mb-2">

<label class="form-label">SMTP Username</label>
<div class="form-text">
The username to connect to your SMTP server.</div>

<input class="form-control" id="email-username" name="email_username" value="<?php echo $email_username;?>">
</div>

<div class="mb-2">
<label class="form-label">SMTP Password</label>
<div class="form-text">
The password to connect to your SMTP server.
</div>

<input class="form-control" type="password" id="email-password" name="email_password" value="">

</div>

<div class="mb-2">

<label class="form-label">Type of encryption</label>

<div class="form-text">
The encryption to be used when sending an email (TLS/SSL. TLS is recommended).
</div>

<select class="form-control" id="email-encryption" name="email_encryption">
<option value="tls"<?php echo ($email_encryption=='tls'?' selected':'');?>>TLS</option>
<option value="ssl"<?php echo ($email_encryption=='ssl'?' selected':'');?>>SSL</option>
</select>
</div>

<div class="mb-2">

<label class="form-label">SMTP Port</label>
<div class="form-text">
The port to be used when sending an email (587/465). If you choose TLS the port should be set to 587. For SSL use port 465 instead.
</div>

<input class="form-control" id="email-port" name="email_port" value="<?php echo $email_port;?>">

</div>


<div class="mb-2">

<label class="form-label">From email</label>
<div class="form-text">
Some email providers requires you set sender email. You may enter your business email address.
</div>
<input class="form-control" id="email-from" name="email_from" value="<?php echo $email_from;?>">
</div>

<div class="mb-2">
<label class="form-label">From alias</label>

<input class="form-control" id="email-alias" name="email_alias" value="<?php echo $email_alias;?>">

</div>
</form>

<button id="save-emailer-config-btn" class="btn btn-sm btn-primary mt-1">Save</button>
</div>

<hr>

<div class="row">
     <div class="col-9">
       <div class="">
<h5>Change email address</h5>
</div>
   </div><div class="col-3">
   <button class="edit-btn" onclick="$('#change-email-container').slideToggle();"> <i class="fa fa-pencil fa-lg text-primary"></i></button>
   </div>
    </div>

<div id="change-email-container" class="mb-3" style="display: none;">

<label class="form-label"><b>New email address</b></label>
 <input type="text" class="form-control" id="change-email-box" placeholder="Enter new email" value="<?php echo test_input( getAdminInfo("email") );?>">

<input type="hidden" id="old-email" value="<?php echo test_input( getAdminInfo("email") );?>" />
<br>
<button id="change-email-btn" class="btn btn-sm btn-primary mt-2">Change</button>

<div id="change-email-result" class="pt-2"></div>
</div>
<hr />

<div class="row">
     <div class="col-9">
       <div class="">
<h5>Change password</h5>
</div>
   </div><div class="col-3">
   <button class="edit-btn" onclick="$('#change-password-container').slideToggle();"> <i class="fa fa-pencil fa-lg text-primary"></i></button>
   </div>
    </div>


<div id="change-password-container" class="change-password-container mb-5" style="display: none;">

<div class="mb-2">
<label class="d-block mt-2">Old password</label>
 <input type="text" class="form-control mb-2" id="old-password-box" placeholder="Enter old password">
</div>

<div class="mb-3">
<label class="form-label">New password</label>
 <input type="text" class="form-control mb-2" id="change-password-box" placeholder="Enter new password">
</div>

<button id="change-password-btn" class="btn btn-sm btn-primary mt-1">Change</button>

<div id="change-password-result" class="pt-2"></div>
</div>

<hr>

<div class="row">
     <div class="col-9">
       <div class="">
<h5>App upgrade data</h5>
</div>
   </div><div class="col-3">
   <button class="edit-btn" onclick="$('#app-upgrade-data-container').slideToggle();"> <i class="fa fa-pencil fa-lg text-primary"></i></button>
   </div>
    </div>

<div id="app-upgrade-data-container" class="app-upgrade-data-container mb-5" style="display: none;">

<div class="form-text">Alter these only if you want to prompt users to upgrade to latest version of your app. Version code must be incremental i.e must be greater than the previous version code.</div>

<?php $sJson=appUpgradeData(); 

$vcode=isset( $sJson["version_code"] )? $sJson["version_code"]:"1.0";

$vinfo=isset( $sJson["version_info"] )? $sJson["version_info"]:"New version info";

$vurl=isset( $sJson["version_url"] )? $sJson["version_url"]:"https://link to new app";
?>

<div class="mb-2">
<label class="d-block mt-2">New version code (Number only)</label>
 <input type="number" class="form-control mb-2" id="upgrade-version-code" placeholder="New version code" value="<?php echo $vcode;?>">
</div>

<div class="mb-3">
<label class="form-label">New version info</label>
<div class="form-text">Enter what changes in the old version or new features introduced.</div>

 <textarea class="form-control mb-2" id="upgrade-version-info" placeholder="New version info"><?php echo str_replace(":nl::","\n",$vinfo);?></textarea>
</div>

<div class="mb-2">
<label class="d-block mt-2">Download location</label>
<duv class="form-text">Url of where new version of app can be downloaded</div>

 <input type="url" class="form-control mb-2" id="upgrade-version-location" placeholder="Download location" value="<?php echo $vurl;?>">
</div>


<button id="upgrade-version-btn" class="btn btn-sm btn-primary mt-1">Save</button>


</div>
</div>
</div>
<div class="mb-5"></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/dropzone@5.7.1/dist/dropzone.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.7.1/dropzone.min.js"></script>

<script src="assets/js/global.js?i=1"></script>
<script src="assets/js/index.js?i=1"></script>
<script src="assets/js/settings.js?i=<?php echo randomString(3);?>"></script>

</body>
</html>
